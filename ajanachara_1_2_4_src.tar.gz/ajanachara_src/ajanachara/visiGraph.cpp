// started 2001-11-11

#include <veStd.h>
#include <veGeoObj.h>
#include <veMath.h>
#include <veUtils.h>

#include "visiGraph.h"
#include <GL/gl.h>

#ifdef _HAVE_LIBZ
# include <zlib.h>
#endif

using namespace std;
using namespace ve;

//--- class vgrVertex ---------------------------------------------- /*FOLD00*/

vgrVertex::vgrVertex(const vector<bool> & connections ) {
    vEdge.reserve(connections.size());
    vEdge=connections;
    val=0.0f;
}

unsigned int vgrVertex::neighbors() const {
    unsigned int n=0;
    for(unsigned int i=0; i<vEdge.size(); i++)
        if(vEdge[i]) n++;
    return n;
}

unsigned int vgrVertex::neighbors2(const visiGraph & graph) const {
    unsigned int i,j;
    vector<bool> tmpValue;
    tmpValue.assign(graph.size(),false);
    for(i=0; i<vEdge.size(); i++) if(vEdge[i])
        for(j=0; j<graph.size(); j++)
            if(graph[i].edge(j)&&!vEdge[j]) tmpValue[j]=true;
    unsigned int n=0;
    for(i=0; i<tmpValue.size(); i++) if(tmpValue[i]) n++;
    return n;
}

float vgrVertex::clustering(const visiGraph & graph ) const {
    float nbh=neighbors();
    if(nbh<=0.0f) return -1.0f;
    float f=0.0f;
    for(unsigned int i=0; i<vEdge.size(); i++) if(vEdge[i])
        for(unsigned int j=0; j<vEdge.size(); j++)
            if(vEdge[j]&&graph[i].edge(j)) f++;
    return f/(nbh*(nbh-1));
}

void vgrVertex::revelation1(float * f, const visiGraph & graph) const {
    if(val<0.0f) return;
    unsigned int id=0;
    const unsigned int & szX=graph.sizeX();
    const unsigned int & szY=graph.sizeY();
    for(unsigned int k=0; k<graph.size(); k++) {
        if(vEdge[k]) f[k]=1;  // first order isovist
        else  f[k]=0;
        if(&graph[k]==this) id=k;
    }
    unsigned int k;
    if(id>=szX) if(vEdge[id-szX]) for(k=0; k<graph.size(); k++)
        if(graph[id-szX].edge(k)) if(!f[k]) f[k]=2;
    if(id<szX*szY-szX) if(vEdge[id+szX]) for(k=0; k<graph.size(); k++)
        if(graph[id+szX].edge(k)) if(!f[k]) f[k]=2;
    if(id%szX>0) if(vEdge[id-1]) for(k=0; k<graph.size(); k++)
        if(graph[id-1].edge(k)) if(!f[k]) f[k]=2;
    if(id%szX<szX-1) if(vEdge[id+1]) for(k=0; k<graph.size(); k++)
        if(graph[id+1].edge(k)) if(!f[k]) f[k]=2;
}

unsigned int vgrVertex::nRevelation( const visiGraph & graph) const {
    if(val<0.0f) return 0;
    float tmpValue[graph.size()];
    revelation1(tmpValue,graph);
    unsigned int n=0;
    for(unsigned int k=0; k<graph.size(); k++)
        if(tmpValue[k]==2.0f) n++;
    return n;
}


unsigned int vgrVertex::perimeterLength(const visiGraph & graph,
                                        unsigned int id) const {
    if(val<0.0f) return 0;
    unsigned int l=0;
    const unsigned int & szX=graph.sizeX();
    const unsigned & szY=graph.sizeY();
    for(unsigned int k=0; k<graph.size(); k++) if(vEdge[k]) {
        l++;
        if(k<szX) continue;
        if(!vEdge[k-szX]&&(k-szX!=id)) continue;
        if(k>=szX*szY-szX) continue;
        if(!vEdge[k+szX]&&(k+szX!=id)) continue;
        if(k%szX==0) continue;
        if(!vEdge[k-1]&&(k-1!=id)) continue;
        if(k%szX==szX-1) continue;
        if(!vEdge[k+1]&&(k+1!=id)) continue;
        l--;
    }
    return l;
}

void vgrVertex::perimeterOpenness(unsigned int & open, unsigned int & close,
                                  const visiGraph & graph, unsigned int id) const {
    open=close=0;
    if(val<0.0f) return;
    const unsigned int & szX=graph.sizeX();
    const unsigned int & szY=graph.sizeY();

    for(unsigned int k=0; k<graph.size(); k++) if(vEdge[k]) {
        if(k<szX) close++;
        else if(!vEdge[k-szX]&&(k-szX!=id)) {
            if(graph[k].edge(k-szX)) open++;
            else close++;
        }
        if(k>=szX*szY-szX) close++;
        else if(!vEdge[k+szX]&&(k+szX!=id)) {
            if(graph[k].edge(k+szX)) open++;
            else  close++;
        }
        if(k%szX==0) close++;
        else if(!vEdge[k-1]&&(k-1!=id)) {
            if(graph[k].edge(k-1)) open++;
            else  close++;
        }
        if(k%szX==szX-1) close++;
        else if(!vEdge[k+1]&&(k+1!=id)) {
            if(graph[k].edge(k+1)) open++;
            else  close++;
        }
    }
}

void vgrVertex::PCA(vec3f & vPriComp0, vec3f & vPriComp1,
                    float & minExtend0, float & maxExtend0,
                    float & minExtend1, float & maxExtend1,
                    const visiGraph & graph, unsigned int id) const {
    if(val<0.0f) return;
    vector<vec3f> coord;
    vec3f standPoint(id%graph.sizeX(),id/graph.sizeX());
    //cout << endl; P(standPoint);
    coord.push_back(standPoint); // add to graph
    vec3f centroid=standPoint;
    unsigned int k;
    for(k=0; k<graph.size(); k++)
        if(vEdge[k]) {
            coord.push_back(vec3f(k%graph.sizeX(),k/graph.sizeX()));
            centroid.translate(k%graph.sizeX(),k/graph.sizeX());
        }
    centroid*=(1.0f/coord.size());
    //P(centroid);

    // covariance matrix:
    float a,b,d;  //c=b, symmetric matrix
    a=b=d=0;
    for(k=0; k<coord.size(); k++) {
        a+=(coord[k][X]-centroid[X])*(coord[k][X]-centroid[X]);
        b+=(coord[k][X]-centroid[X])*(coord[k][Y]-centroid[Y]);
        d+=(coord[k][Y]-centroid[Y])*(coord[k][Y]-centroid[Y]);
    }
    a*=(1.0f/coord.size());
    b*=(1.0f/coord.size());
    d*=(1.0f/coord.size());
    // eigen values:
    float eig0=0.5f*(a+d) + sqrt(b*b-a*d+0.25f*(a+d)*(a+d));
    float eig1=0.5f*(a+d) - sqrt(b*b-a*d+0.25f*(a+d)*(a+d));
    // eigen vectors:
    //PP(eig0,eig1);
#ifdef __WIN32
    if((eig0==eig1)||_isnan(eig0)||_isnan(eig1)) {
#else
    if((eig0==eig1)||isnan(eig0)||isnan(eig1)) {
#endif
        vPriComp0.set(1,0);
        vPriComp1.set(0,1);
    }
    else {
        float eigMatrix[4]= { a-eig0, b, b, d-eig0 };
        if(eigMatrix[1]!=eigMatrix[3])
            vPriComp0.set(1,(eigMatrix[2]-eigMatrix[0])/(eigMatrix[1]-eigMatrix[3]));
        else if(eigMatrix[0]!=eigMatrix[2])
            vPriComp0.set((eigMatrix[3]-eigMatrix[1])/(eigMatrix[0]-eigMatrix[2]),1);
        else vPriComp0.set(eigMatrix[1],-eigMatrix[0]);
        vPriComp0.normalize();
        vPriComp1.set(-vPriComp0[Y],vPriComp0[X]);
    }
    //PP(vPriComp0,vPriComp1);
    // now seek maximum extend in optimized coordinate system:
    minExtend0=maxExtend0=vPriComp0*(coord[0]-standPoint);
    minExtend1=maxExtend1=vPriComp1*(coord[0]-standPoint);
    for(k=1; k<coord.size(); k++) {
        float tmp=vPriComp0*(coord[k]-standPoint);
        if(tmp<minExtend0) minExtend0=tmp;
        else if(tmp>maxExtend0) maxExtend0=tmp;
        tmp=vPriComp1*(coord[k]-standPoint);
        if(tmp<minExtend1) minExtend1=tmp;
        else if(tmp>maxExtend1) maxExtend1=tmp;
    }
    //PP(minExtend0,maxExtend0);
    //PP(minExtend1,maxExtend1);
}

void vgrVertex::isovist(vector<vec3f> & vPolygon, const vec3f & center, const vector<triangle> & vBoundary,
                        float resolution, float tolerance) const {
    if(val<0.0f) return;

    const unsigned int nRays=(unsigned int)(360.0f/resolution);
    unsigned int k;
    for(k=0; k<nRays; k++) {
        vec3f dir;
        dir.setPolar((float)k*360.0f/(float)nRays);
        dir.translate(center);
        line ray(center,dir);
        float minDistSqr=0;
        for(unsigned int l=0; l<vBoundary.size(); l++) {
            vec3f * pIntersect=ray.intersects(vBoundary[l],true);
            if(pIntersect) {
                float currDistSqr=center.sqrDistTo(*pIntersect);
                if((currDistSqr<minDistSqr)||!minDistSqr) minDistSqr=currDistSqr;
                delete pIntersect;
            }
        }
        dir.setPolar((float)k*360.0f/(float)nRays,0,sqrt(minDistSqr));
        dir.translate(center);
        if((vPolygon.size()>1)&&(tolerance>0.0f)) { // optimize number of vertices:
            float deltaAngle=dAngle(vPolygon[vPolygon.size()-2].angleToXY(dir),
                                    vPolygon[vPolygon.size()-2].angleToXY(vPolygon[vPolygon.size()-1]));
            if((deltaAngle<tolerance)||(deltaAngle>360.0f-tolerance)) {
                vPolygon.pop_back();
            }
        }
        vPolygon.push_back(dir);
    }
    if(!tolerance) return;
    float deltaAngle=dAngle(vPolygon[vPolygon.size()-2].angleToXY(vPolygon[0]),
                            vPolygon[vPolygon.size()-2].angleToXY(vPolygon[vPolygon.size()-1]));
    if((deltaAngle<tolerance)||(deltaAngle>360.0f-tolerance)) {
        vPolygon.pop_back();
    }
    deltaAngle=dAngle(vPolygon[vPolygon.size()-1].angleToXY(vPolygon[1]),
                      vPolygon[vPolygon.size()-1].angleToXY(vPolygon[0]));
    if((deltaAngle<tolerance)||(deltaAngle>360.0f-tolerance))
        vPolygon.erase((vector<vec3f>::iterator)&vPolygon[0]);
}

float vgrVertex::visRatio(float distance, const vec3f & pos,
                          const vector<triangle> & vBoundary,
                          float resolution) const {
    if(val<0.0f) return 0;

    const unsigned int nRays=(unsigned int)(360.0f/resolution);
    unsigned int nVisible=0;
    for(unsigned int k=0; k<nRays; k++) {
        vec3f dir;
        dir.setPolar((float)k*360.0f/(float)nRays,0,distance);
        dir.translate(pos);
        line ln(pos,dir);
        if(!visiGraph::isIntersection(vBoundary,ln,false)) nVisible++;
    }
    return float(nVisible)/float(nRays);
}


string vgrVertex::labels(const string & sep) {
    return "X"+sep
        +"Y"+sep
        +"neighbors"+sep
        +"neighbors2"+sep
        +"clustering"+sep
        +"revelation"+sep
        +"perimeter"+sep
        +"open"+sep
        +"close"+sep
        +"pc0angle"+sep
        +"pc0minExt"+sep
        +"pc0maxExt"+sep
        +"pc1minExt"+sep
        +"pc1maxExt"+sep
        +"boundingProp"+sep
        +"nVertices"+sep
        +"visRatio2"+sep
        +"visRatio4"+sep
        +"visRatio6"+sep
        +"visRatio8";
}

string vgrVertex::measurands(const visiGraph & graph,
                             unsigned int id, const vec3f & pos, const string & sep) const {
    unsigned int open, close;
    perimeterOpenness(open,close,graph,id);
    vec3f pc0, pc1;
    float minExt0, maxExt0, minExt1, maxExt1;
    PCA(pc0,pc1, minExt0,maxExt0, minExt1,maxExt1, graph,id);
    vector<vec3f> vPolygon;
    isovist(vPolygon,pos,graph.boundary(),2,.2);

    return i2s(id%graph.sizeX())+sep
        +i2s(id/graph.sizeX())+sep
        +i2s(neighbors())+sep
        +i2s(neighbors2(graph))+sep
        +f2s(clustering(graph))+sep
        +i2s(nRevelation(graph))+sep
        +i2s(perimeterLength(graph,id))+sep
        +i2s(open)+sep
        +i2s(close)+sep
        +f2s(datan(pc0[Y]/pc0[X]))+sep
        +f2s(minExt0)+sep
        +f2s(maxExt0)+sep
        +f2s(minExt1)+sep
        +f2s(maxExt1)+sep
        +f2s((maxExt0-minExt0)/(maxExt1-minExt1))+sep
        +i2s(vPolygon.size())+sep
        +f2s(visRatio(2.0f,pos,graph.boundary(),2))+sep
        +f2s(visRatio(4.0f,pos,graph.boundary(),2))+sep
        +f2s(visRatio(6.0f,pos,graph.boundary(),2))+sep
        +f2s(visRatio(8.0f,pos,graph.boundary(),2));
}

//--- class visiGraph ---------------------------------------------- /*FOLD00*/

visiGraph::visiGraph() {
    isDisplayed=true;
    periResolution=5;
    periAngleTolerance=5;
    clear();
}

visiGraph::visiGraph(ve::xmlIni & ini) {
    isDisplayed=true;

    ini.focusOn("visibilityGraphAnalysis");
    ini.read(orig[Z],"heightOverGround",1.6);
    ini.read(res,"graphResolution",0.5);
    ini.read(orig[X],"originX",0.0);
    ini.read(orig[Y],"originY",0.0);
    ini.read(m_ignoreTransp,"ignoreTranspWalls",true);
    ini.read(periResolution,"periResolution",5.0f);
    ini.read(periAngleTolerance,"periAngleTolerance",5.0f);
    ini.focusOff();

    clear();
}

visiGraph::~visiGraph() {
    clear();
}

void visiGraph::clear() {
    vVertex.clear();
    graph.clear();
    vBoundary.clear();
    vPermeability.clear();
    szX=0;
    szY=0;
    status=VGR_STATE_NONE;
    boundaryModelName="";
    graphFileName="";
    progrVal=-1.0f;
    step=0;
    m_ignoreTransp=true;
}

void visiGraph::draw() {
    if(!isDisplayed) return;
    unsigned int i,j;
    switch(status) {
    case VGR_STATE_NONE:
    case VGR_STATE_COMPUTE:
    case VGR_STATE_CLUSTERING:
    case VGR_STATE_NBH2:
    case VGR_STATE_NVTX:
        return;
    case VGR_STATE_POSITION:
        szX=(unsigned int)((maxCoord[X]-minCoord[X])/res+1);
        szY=(unsigned int)((maxCoord[Y]-minCoord[Y])/res+1);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glColor4f(1.0,0.5,0.5,0.5);
        glBegin(GL_QUADS);
        for(j=0; j<szY; j++) for(i=0; i<szX; i++) {
            glVertex3f(orig[X] + minCoord[X]+i*res -res*0.45f,orig[Y] + minCoord[Y]+j*res -res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X] + minCoord[X]+i*res +res*0.45f,orig[Y] + minCoord[Y]+j*res -res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X] + minCoord[X]+i*res +res*0.45f,orig[Y] + minCoord[Y]+j*res +res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X] + minCoord[X]+i*res -res*0.45f,orig[Y] + minCoord[Y]+j*res +res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
        }
        glEnd();
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        return;
    case VGR_STATE_ADDREMOVE:
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBegin(GL_QUADS);
        for(j=0; j<szY; j++) for(i=0; i<szX; i++) {
            if(graph[i+szX*j].value()>0.0f) glColor4f(0,1,0,0.5);
            else glColor4f(1,0,0,0.5);
            glVertex3f(orig[X]+i*res -res*0.45f,orig[Y]+j*res -res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X]+i*res +res*0.45f,orig[Y]+j*res -res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X]+i*res +res*0.45f,orig[Y]+j*res +res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
            glVertex3f(orig[X]+i*res -res*0.45f,orig[Y]+j*res +res*0.45f,(minCoord[Z]+maxCoord[Z])*0.5f);
        }
        glEnd();
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        return;
    case VGR_STATE_PCA:
        glBegin(GL_LINES);
        glColor3f(1,0,0);
        glVertex3f(orig[X]+standPoint[X]*res,
                   orig[Y]+standPoint[Y]*res,orig[Z]);
        glVertex3f(orig[X]+(standPoint[X]+vEig[0][X]*maxExtend0)*res,
                   orig[Y]+(standPoint[Y]+vEig[0][Y]*maxExtend0)*res,orig[Z]);
        glVertex3f(orig[X]+standPoint[X]*res,
                   orig[Y]+standPoint[Y]*res,orig[Z]);
        glVertex3f(orig[X]+(standPoint[X]+vEig[0][X]*minExtend0)*res,
                   orig[Y]+(standPoint[Y]+vEig[0][Y]*minExtend0)*res,orig[Z]);
        glColor3f(0,1,0);
        glVertex3f(orig[X]+standPoint[X]*res,
                   orig[Y]+standPoint[Y]*res,orig[Z]);
        glVertex3f(orig[X]+(standPoint[X]+vEig[1][X]*maxExtend1)*res,
                   orig[Y]+(standPoint[Y]+vEig[1][Y]*maxExtend1)*res,orig[Z]);
        glVertex3f(orig[X]+standPoint[X]*res,
                   orig[Y]+standPoint[Y]*res,orig[Z]);
        glVertex3f(orig[X]+(standPoint[X]+vEig[1][X]*minExtend1)*res,
                   orig[Y]+(standPoint[Y]+vEig[1][Y]*minExtend1)*res,orig[Z]);
        glEnd();
        break;
    case VGR_STATE_PERIMETER:
    case VGR_STATE_PROFILE:
        if(!vPolyBoundary.size()) break;
        glBegin(GL_LINE_STRIP);
        glColor3f(0,0,1);
        for(i=0; i<vPolyBoundary.size(); i++)
            glVertex3f(vPolyBoundary[i][X],vPolyBoundary[i][Y],orig[Z]);
        glVertex3f(vPolyBoundary[0][X],vPolyBoundary[0][Y],orig[Z]);
        glEnd();
        glBegin(GL_QUADS);
        glColor3f(1,1,0);
        for(i=0; i<vPolyBoundary.size(); i++) {
            glVertex3f(vPolyBoundary[i][X] -res*0.2f,vPolyBoundary[i][Y] -res*0.2f,orig[Z]);
            glVertex3f(vPolyBoundary[i][X] +res*0.2f,vPolyBoundary[i][Y] -res*0.2f,orig[Z]);
            glVertex3f(vPolyBoundary[i][X] +res*0.2f,vPolyBoundary[i][Y] +res*0.2f,orig[Z]);
            glVertex3f(vPolyBoundary[i][X] -res*0.2f,vPolyBoundary[i][Y] +res*0.2f,orig[Z]);
        }
        glEnd();
        break;
    default:
        break;
    }
    glBegin(GL_QUADS);
    for(j=0; j<szY; j++) for(i=0; i<szX; i++) if(graph[i+szX*j].value()>=0.0f) {
        float color=float(graph[i+szX*j].value()-valueMin)/float(valueMax-valueMin);
        glColor3f(color,color,color);
        glVertex3f(orig[X]+i*res -res*0.5f,orig[Y]+j*res -res*0.5f,orig[Z]);
        glVertex3f(orig[X]+i*res +res*0.5f,orig[Y]+j*res -res*0.5f,orig[Z]);
        glVertex3f(orig[X]+i*res +res*0.5f,orig[Y]+j*res +res*0.5f,orig[Z]);
        glVertex3f(orig[X]+i*res -res*0.5f,orig[Y]+j*res +res*0.5f,orig[Z]);
    }
    glEnd();
}

vec3f * visiGraph::intersection(const std::vector<triangle> & vTr, const line & ln, bool isRay ) {
    float minDist=0;
    vec3f * pNearest=NULL;
    for(unsigned int i=0; i<vTr.size(); i++) {
        vec3f * pTest=ln.intersects(vTr[i],isRay);
        if(pTest) {
            if(!pNearest) {
                pNearest=pTest;
                minDist=ln[0].distTo(*pNearest);
                continue;
            }
            float currDist=ln[0].distTo(*pTest);
            if(currDist<minDist) {
                minDist=currDist;
                delete pNearest;
                pNearest=pTest;
            }
        }
    }
    return pNearest;
}

bool visiGraph::isIntersection(const std::vector<triangle> & vTr, const line & ln, bool isRay ) {
    vec3f * pTest=NULL;
    for(unsigned int i=0; i<vTr.size(); i++) {
        pTest=ln.intersects(vTr[i],isRay);
        if(pTest) {
            delete pTest;
            return true;
        }
    }
    return false;
}

bool visiGraph::intersects(const ve::line & ray, unsigned int & i, unsigned int & j) {
    for(j=0; j<szY; j++) for(i=0; i<szX; i++) {
        triangle tr1(orig[X]+i*res -res*0.5f,orig[Y]+j*res -res*0.5f,orig[Z],
                     orig[X]+i*res +res*0.5f,orig[Y]+j*res -res*0.5f,orig[Z],
                     orig[X]+i*res +res*0.5f,orig[Y]+j*res +res*0.5f,orig[Z]);
        triangle tr2(orig[X]+i*res -res*0.5f,orig[Y]+j*res -res*0.5f,orig[Z],
                     orig[X]+i*res +res*0.5f,orig[Y]+j*res +res*0.5f,orig[Z],
                     orig[X]+i*res -res*0.5f,orig[Y]+j*res +res*0.5f,orig[Z]);
        vec3f * pTest=ray.intersects(tr1);
        if(!pTest) pTest=ray.intersects(tr2);
        if(pTest) {
            m_lastIntersection=*pTest;
            delete pTest;
            return true;
        }
    }
    return false;
}

void visiGraph::nextStep() {
    unsigned int i,j;
    switch(status) {
    case VGR_STATE_POSITION:
        orig[X]+=minCoord[X];
        orig[Y]+=minCoord[Y];
        vVertex.reserve(szX*szY);
        for(j=0; j<szY; j++) for(i=0; i<szX; i++) {
            line ln(orig[X]+i*res,orig[Y]+j*res,maxCoord[Z],
                    orig[X]+i*res,orig[Y]+j*res,minCoord[Z]);
            vec3f * pTest=intersection(vPermeability,ln,true);
            graph.push_back(vgrVertex(szX*szY));
            if(pTest) {
                graph[graph.size()-1].value()=1.0f;
                delete pTest;
            }
            else graph[graph.size()-1].value()=-1.0f;
            vVertex.push_back(vec3f(orig[X]+i*res,orig[Y]+j*res,orig[Z]));
        }
        msg="Please edit vertices and afterwards press OK.";
        status++;
        break;
    case VGR_STATE_ADDREMOVE:
        for(i=0;i<vVertex.size();i++) if(graph[i].value()>0.0f) {
            line ln(vVertex[i][X],vVertex[i][Y],maxCoord[Z],
                    vVertex[i][X],vVertex[i][Y],minCoord[Z]);
            vec3f * pTest=intersection(vPermeability,ln,true);
            if(pTest) {
                vVertex[i][Z]=(*pTest)[Z]+orig[Z];
                delete pTest;
            }
        }
        status++;
        msg="computing graph...";
        progrVal=0.0f;
        break;
    case VGR_STATE_COMPUTE: {
        if(step<graph.size()-1) {
            if(graph[step].value()>0.0f) {
                for(j=step+1; j<graph.size(); j++) if(graph[j].value()>0.0f) {
                    line ln(vVertex[step],vVertex[j]);
                    if(!isIntersection(vBoundary,ln,false)) {
                        graph[step].edge()[j]=true;
                        graph[j].edge()[step]=true;
                    }
                }
            }
            step++;
            progrVal=float(step+1)/float(vVertex.size());
        }
        else {
            computeNeighborhood();
            msg="computing graph done.";
            status=VGR_STATE_COMPUTATION_DONE;
        }
        break;
    }
    case VGR_STATE_COMPUTATION_DONE:
        progrVal=-1.0f;
        step=0;
        status=VGR_STATE_READY;
        break;
    case VGR_STATE_CLUSTERING:
        if(step<graph.size()) {
            if(graph[step].value()>=0.0f)
                graph[step].value()=graph[step].clustering(*this);
            step++;
            progrVal=float(step+1)/float(graph.size());
        }
        else {
            updateRange();
            msg="Clustering coefficient, min="+f2s(valueMin)+", max="+f2s(valueMax);
            status=VGR_STATE_COMPUTATION_DONE;
        }
        break;
    case VGR_STATE_NBH2: {
        for(unsigned int i=0; i<10; i++) if(step<graph.size()) {
            if(graph[step].value()>=0.0f)
                graph[step].value()=graph[step].neighbors2(*this);
            step++;
            progrVal=float(step+1)/float(graph.size());
        }
        else {
            updateRange();
            msg="Second order neighborhood size, min="+i2s((int)valueMin)+", max="+i2s((int)valueMax);
            status=VGR_STATE_COMPUTATION_DONE;
        }
        break;
    }
    case VGR_STATE_NVTX: {
        for(unsigned int i=0; i<10; i++) if(step<graph.size()) {
            if(graph[step].value()>=0.0f) {
                vec3f pos(orig[X]+(step%szX)*res,orig[Y]+(step/szX)*res,orig[Z]);
                vector<vec3f> vPolygon;
                graph[step].isovist(vPolygon,pos,boundary(),2,.2);
                graph[step].value()=vPolygon.size();
            }
            step++;
            progrVal=float(step+1)/float(graph.size());
        }
        else {
            updateRange();
            msg="Isovist polygon n vertices, min="+i2s((int)valueMin)+", max="+i2s((int)valueMax);
            status=VGR_STATE_COMPUTATION_DONE;
        }
        break;
    }
    default:
        break;
    }
}

void visiGraph::switchCell(const line & ray) {
    if(!VGR_STATE_ADDREMOVE) return;
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    graph[i+szX*j].value()=(graph[i+szX*j].value()>0.0f) ? -1 : 1;
    msg="vertex ("+i2s(i)+','+i2s(j)+") flipped.";
}

void visiGraph::generate(const ve::geoGroup & permeability) {
    clear();
    permeability.triangles(vPermeability);
    minCoord=permeability.minCoord();
    maxCoord=permeability.maxCoord();
    minCoord[Z]-=1.0f;
    maxCoord[Z]+=1.0f;
    szX=(unsigned int)((maxCoord[X]-minCoord[X])/res+1);
    szY=(unsigned int)((maxCoord[Y]-minCoord[Y])/res+1);
    status=VGR_STATE_POSITION;
}


void visiGraph::boundaryModel(const ve::geoGroup & boundary, const string & name) {
    if(name.size()) boundaryModelName=name;
    vBoundary.clear();
    if(m_ignoreTransp) {
        // currently non-recursive, descends only 1 step!
        for(unsigned int j=0; j<boundary.nChildren(); j++) {
            // interpret all transparency as completely transparent
            if(boundary.children()[j]->color()[3]>=1.0f)
                boundary.children()[j]->triangles(vBoundary);
        }
    }
    else boundary.triangles(vBoundary);
}

string visiGraph::str() const {
    if(status<VGR_STATE_READY) return "visibility graph not ready.\n";
    string s;
    for(unsigned int i=0; i<graph.size(); i++) {
        for(unsigned int j=0; j<graph[i].size(); j++) {
            if(graph[i].edge(j)) s+="1 ";
            else s+="0 ";
        }
        s[s.size()-1]='\n';
    }
    return s;
}

int visiGraph::save(const string & fileName) {
    if(status<VGR_STATE_READY) return 1;
    graphFileName=fileName;
#ifdef _HAVE_LIBZ
    string hdr="% Visibility graph generated by "+cmdLine::name()+" v"+cmdLine::version()
        +" (c) "+cmdLine::date()+" by "+cmdLine::author()+'\n';
    hdr+="% model: "+boundaryModelName+" originX: "+f2s(orig[X])
        +" originY: "+f2s(orig[Y])+" resolution: "+f2s(res)+" height: "+f2s(orig[Z])+" sizeX: "+i2s(szX)+" sizeY: "+i2s(szY)+'\n';
    gzFile fp=gzopen(fileName.c_str(),"wb");
    if (!fp) return 1;
    gzwrite(fp,(void*)hdr.c_str(),hdr.size());
    gzwrite(fp,(void*)str().c_str(),str().size());
    gzclose(fp);
#else
    return 1;
#endif
    return 0;
}

int visiGraph::load(const string & fileName) {
    bool fileIsValid=false;
#ifdef _HAVE_LIBZ
    gzFile fp=gzopen(fileName.c_str(),"rb");
    if (!fp) {
        msg="Loading graph \""+fileName+"\" failed.";
        return 1;
    }
    graph.clear();
    vBoundary.clear();

    unsigned int bufSz=4096; // initial size. should hopefully be enough for all headers
    char * buffer= new char[bufSz];
    while(!gzeof(fp)) { // main reading loop
        if(!fileIsValid) gzgets(fp,buffer,bufSz);
        else gzread(fp,buffer,bufSz);
        if(buffer[0]) {
            if(!fileIsValid&&((buffer[0]=='%')||(buffer[0]=='#'))) {
                vector<string> word;
                split(&buffer[1],word);
                if((word[0]=="model:")&&(word.size()>9)) {
                    boundaryModelName=word[1];
                    orig[X]=s2f(word[3]);
                    orig[Y]=s2f(word[5]);
                    res    =s2f(word[7]);
                    orig[Z] =s2f(word[9]);
                    szX=s2i(word[11]);
                    szY=s2i(word[13]);
                    bufSz=szX*szY*2;
                    delete [] buffer;
                    buffer= new char[bufSz];
                    fileIsValid=true;
                }
            }
            else if(fileIsValid) {
                vector<bool> vBool;
                vBool.assign(szX*szY,false);
                for(unsigned int i=0; i<szX*szY; i++)
                    if(buffer[i*2]=='1') vBool[i]=true;
                graph.push_back(vBool);
            }
        }
    }
    delete [] buffer;
    gzclose(fp);
#endif
    if (!fileIsValid) {
        msg="Interpreting graph \""+fileName+"\" failed.";
        status=VGR_STATE_NONE;
        return 1;
    }

    graphFileName=fileName;
    msg="Visibility graph \""+graphFileName+"\" loaded.";
    status=VGR_STATE_COMPUTATION_DONE;
    return 0;
}

int visiGraph::saveAnalysis(const string & fileName) const {
    if(status<VGR_STATE_READY) return 1;
    ofstream file(fileName.c_str(), std::ios::out );
    if (!file.good()) return 1;
    for(unsigned int i=0; i<szY; i++) {
        for(unsigned int j=szX; j>0; j--)
            file << graph[i*szX+j-1].value() << ' ';
        file << '\n';
    }
    file.close();
    return 0;
}

void visiGraph::updateRange() {
    bool firstTime=true;
    for(unsigned int i=0; i<graph.size(); i++) if(graph[i].value()>=0.0f) {
        if(firstTime) {
            valueMin=valueMax=graph[i].value();
            firstTime=false;
        }
        else if(graph[i].value()<valueMin) valueMin=graph[i].value();
        else if(graph[i].value()>valueMax) valueMax=graph[i].value();
    }
}

void visiGraph::computeNeighborhood() {
    for(unsigned int i=0; i<graph.size(); i++) if(graph[i].value()>=0.0f) {
        graph[i].value()=graph[i].neighbors();
        if(graph[i].value()<=0.0f) graph[i].value()=-1.0f;
    }
    updateRange();
    msg="Neighborhood size, min="+i2s((int)valueMin)+", max="+i2s((int)valueMax);
    status=VGR_STATE_READY;
}

float visiGraph::value(const ve::line & ray) {
    if(status<VGR_STATE_READY) return -1;
    unsigned int i,j;
    if(!intersects(ray,i,j)) return -1;
    return graph[i+szX*j].value();
}

float visiGraph::value(float x, float y) {
    ve::line ray(vec3f(x,y,maxCoord[Z]+10.0f),vec3f(x,y,minCoord[Z]-10.0f));
    return value(ray);
}

void visiGraph::showIsovist(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    for(unsigned int k=0; k<graph.size(); k++)
        if(graph[k].value()>=0.0f) graph[k].value()=graph[i+szX*j].edge(k);
    graph[i+szX*j].value()=1.5;
    valueMin=0.0f;
    valueMax=1.5f;
    msg="Isovist vertex ("+i2s(i)+','+i2s(j)+")";
}

void visiGraph::showIsovist2(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    unsigned int k;
    for(k=0; k<graph.size(); k++)
        if(graph[k].value()>=0.0f) graph[k].value()= graph[i+szX*j].edge(k) ? 0.5f : 0.0f;
    for(k=0; k<graph.size(); k++)
        if(graph[k].value()==0.5f) for(unsigned int l=0; l<graph.size(); l++)
            if((graph[l].value()==0.0f)&&graph[k].edge(l))
                graph[l].value()= 1.0f;
    graph[i+szX*j].value()=1.5;
    valueMin=0.0f;
    valueMax=1.5f;
    msg="Second order isovist vertex ("+i2s(i)+','+i2s(j)+")";
}

void visiGraph::showRevelation1(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(graph[i+szX*j].value()<0.0f) return;
    float tmpValue[graph.size()];
    graph[i+szX*j].revelation1(tmpValue,*this);
    for(unsigned int k=0; k<graph.size(); k++)
        if(graph[k].value()>=0.0f) graph[k].value()=tmpValue[k];
    valueMin=0.0f;
    valueMax=2.0f;
    msg="Revelation 1 step vertex ("+i2s(i)+','+i2s(j)+")";
}

void visiGraph::computeRevelation1() {
    for(unsigned int j=0; j<szY; j++) for(unsigned int i=0; i<szX; i++)
        if(graph[i+szX*j].value()>=0.0f)
            graph[i+szX*j].value()=graph[i+szX*j].nRevelation(*this);
    updateRange();
    msg="Revelation 1 step, min="+f2s(valueMin)+", max="+f2s(valueMax);
    status=VGR_STATE_READY;
}

void visiGraph::renderView(const ve::line & ray, ve::xmlIni ini) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(!ini.subTag("zMesh")) return;
    if(!ini.subTag("camera")) return;

    ini.subTag("zMesh")->setAttribute("url",boundaryModelName);
    ini.subTag("camera")->setAttribute("pos",(vec6f(orig[X]+i*res,orig[Y]+j*res,orig[Z])).str());
    string imgName;
    ini.read(imgName,"imgFileName");
    string suffix=imgName.substr(imgName.rfind("."));
    if(graphFileName!="") imgName=graphFileName;
    if(imgName.rfind("/")<imgName.size())
        imgName=imgName.substr(imgName.rfind("/")+1);
    imgName=imgName.substr(0,imgName.find("."))+'_'+i2s(i)+'_'+i2s(j)+suffix;
    if(ini.subTag("string","imgFileName"))
        ini.subTag("string","imgFileName")->content(imgName);
    ini.save("render.ini");
    fileIo::exec("imgen","render.ini",cmdLine::dir());

    msg="View from vertex ("+i2s(i)+','+i2s(j)+") rendered as \""+imgName +"\".";
    status=VGR_STATE_READY;
}

void visiGraph::showClustering(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(graph[i+szX*j].value()<0.0f) return;
    graph[i+szX*j].clustering(*this);
    for(unsigned int k=0; k<graph[i+szX*j].size(); k++) {
        if(graph[k].value()>0.0f) graph[k].value()=0.0f;
        if(graph[i+szX*j].edge(k))
            for(unsigned int l=0; l<graph[i+szX*j].size(); l++)
                if(graph[i+szX*j].edge(l)&&graph[k].edge(l)) graph[k].value()++;
    }

    valueMin=0.0f;
    valueMax=graph[i+szX*j].neighbors();
    msg="Clustering vertex ("+i2s(i)+','+i2s(j)+")";
}

void visiGraph::showPerimeter(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(graph[i+szX*j].value()<0.0f) return;
    unsigned int id=i+szX*j;
    // calculate on graph:
    unsigned int k;
    for(k=0; k<graph.size(); k++) if(graph[id].edge(k)) {
        graph[k].value()=1.0f;
        if(k<szX) continue;
        if(!graph[id].edge(k-szX)&&(k-szX!=id)) continue;
        if(k>=szX*szY-szX) continue;
        if(!graph[id].edge(k+szX)&&(k+szX!=id)) continue;
        if(k%szX==0) continue;
        if(!graph[id].edge(k-1)&&(k-1!=id)) continue;
        if(k%szX==szX-1) continue;
        if(!graph[id].edge(k+1)&&(k+1!=id)) continue;
        graph[k].value()=0.0f;
    }
    else if(graph[k].value()>0.0f) graph[k].value()=0.0f;
    graph[id].value()=1.5f;

    valueMin=0.0f;
    valueMax=1.5f;

    // create bounding polygon:
    vec3f center(orig[X]+i*res,orig[Y]+j*res,orig[Z]);
    vPolyBoundary.clear();
    graph[i+szX*j].isovist(vPolyBoundary,center,vBoundary,periResolution,periAngleTolerance);
    msg="Isovist perimeter vertex ("+i2s(i)+','+i2s(j)+"), nVertices="+i2s(vPolyBoundary.size());
}

void visiGraph::computePerimeterLength() {
    for(unsigned int i=0; i<graph.size(); i++) {
        if(graph[i].value()<0.0f) continue;
        graph[i].value()=graph[i].perimeterLength(*this,i);
    }
    updateRange();
    msg="Isovist perimeter length, min="+i2s((int)valueMin)+", max="+i2s((int)valueMax);
    status=VGR_STATE_READY;
}

void visiGraph::computePerimeterDivArea() {
    for(unsigned int i=0; i<szX*szY; i++) {
        if(graph[i].value()<0.0f) continue;
        graph[i].value()=graph[i].perimeterLength(*this,i);
        graph[i].value()*=graph[i].value()/graph[i].neighbors();
    }
    updateRange();
    msg="Isovist perimeter� / area, min="+f2s(valueMin)+", max="+f2s(valueMax);
    status=VGR_STATE_READY;
}

void visiGraph::computePerimeterOpenness() {
    for(unsigned int i=0; i<szX*szY; i++) {
        if(graph[i].value()<0.0f) continue;

        unsigned int open, close;
        graph[i].perimeterOpenness(open,close,*this,i);
        graph[i].value()=(float)open/((float)close+(float)open);
    }
    updateRange();
    msg="Isovist perimeter openness ratio, min="+f2s(valueMin)+", max="+f2s(valueMax);
    status=VGR_STATE_READY;
}

string visiGraph::measurands(const ve::line & ray) {
    unsigned int i,j;
    if(status<VGR_STATE_READY) return "";
    if(!intersects(ray,i,j)) return "";
    if(graph[i+szX*j].value()<0.0f) return "";
    unsigned int id=i+szX*j;
    vec3f center(orig[X]+i*res,orig[Y]+j*res,orig[Z]);

    string s;
    static bool firstTime=true;
    if(firstTime) {
        s+="\n%% "+vgrVertex::labels()+'\n';
        firstTime=false;
    }
    s+=graph[id].measurands(*this,id,center)+'\n';
    return s;
}

string visiGraph::profile(const ve::line & ray, float resolution) {
    unsigned int i,j;
    if(status<VGR_STATE_READY) return "";
    if(!intersects(ray,i,j)) return "";
    if(graph[i+szX*j].value()<0.0f) return "";

    // create bounding polygon:
    vec3f center(orig[X]+i*res,orig[Y]+j*res,orig[Z]);
    vPolyBoundary.clear();
    graph[i+szX*j].isovist(vPolyBoundary,center,vBoundary,resolution,0.0f);
    msg="Isovist perimeter vertex ("+i2s(i)+','+i2s(j)+"), nVertices="+i2s(vPolyBoundary.size());

    string sep(" ");
    string s(i2s(i)+sep+i2s(j));
    for(unsigned int k=0; k<vPolyBoundary.size(); k++)
        s+=sep+f2s(center.distTo(vPolyBoundary[k]));
    s+='\n';
    return s;
}

void visiGraph::showPCA(const ve::line & ray) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(graph[i+szX*j].value()<0.0f) return;
    standPoint.set(i,j);

    graph[i+szX*j].PCA(vEig[0],vEig[1], minExtend0, maxExtend0,
                       minExtend1,maxExtend1, *this,i+szX*j);

    for(unsigned int k=0; k<graph.size(); k++)
        if(graph[k].value()>=0.0f) graph[k].value()=graph[i+szX*j].edge(k);
    graph[i+szX*j].value()=1.5;
    valueMin=0.0f;
    valueMax=1.5f;
    msg="Isovist principal components vertex ("+i2s(i)+','+i2s(j)+")";
}

void visiGraph::showCircum(const ve::line & ray, float radius) {
    unsigned int i,j;
    if(!intersects(ray,i,j)) return;
    if(graph[i+szX*j].value()<0.0f) return;

    standPoint.set(i,j);
    for(unsigned int k=0; k<graph.size(); k++)
        if(graph[k].value()>=0.0f) {
            vec3f testPoint(k%szX,k/szX);
            float dist=standPoint.distTo(testPoint);
            if(fabs(dist*res-radius)<res*0.5f) {
                if(graph[i+szX*j].edge(k)) graph[k].value()=1;
                else graph[k].value()=0.5f;
            }
            else graph[k].value()=0;
        }
    graph[i+szX*j].value()=1.5;
    valueMin=0.0f;
    valueMax=1.5f;

    vec3f pos(orig[X]+i*res,orig[Y]+j*res,orig[Z]);
    float visibility=graph[i+szX*j].visRatio(radius,pos, vBoundary,periResolution);
    msg="Visibility ratio at distance "+f2s(radius)+"m, vertex ("+i2s(i)+','+i2s(j)+") = "+f2s(visibility);
}

void visiGraph::calcVisRatio(float radius) {
    // first calculate maximum number of possible vertices:
    float nVertices=0.0f;
    unsigned int szLine=(unsigned int)(radius*2.0f/res)+3;
    unsigned char * matrix=new unsigned char[szLine*szLine];
    memset(matrix,0,szLine*szLine);
    vec3f center(radius/res+1,radius/res+1);
    for(unsigned int k=0; k<szLine*szLine; ++k) {
        vec3f testPoint(k%szLine,k/szLine);
        float dist=center.distTo(testPoint);
        if(fabs(dist*res-radius)<res*0.5f) ++nVertices;
    }
    delete[] matrix;
    // now calculate on actual graph:
    for(unsigned int j=0; j<szY; ++j) for(unsigned int i=0; i<szX; ++i)
        if(graph[i+szX*j].value()>=0.0f) {
            center.set(i,j,0);
            float nVerticesConnected=0;
            for(unsigned int k=0; k<graph.size(); k++)
                if(graph[k].value()>=0.0f) {
                    vec3f testPoint(k%szX,k/szX);
                    float dist=center.distTo(testPoint);
                    if(fabs(dist*res-radius)<res*0.5f) {
                        if(graph[i+szX*j].edge(k)) ++nVerticesConnected;
                    }
                }
            graph[i+szX*j].value()=nVerticesConnected/nVertices;
        }
    // finish visualization:
    updateRange();
    msg="Visibility ratio at distance "+f2s(radius)+", min="
        +f2s(valueMin)+", max="+f2s(valueMax);
    status=VGR_STATE_READY;
}

void visiGraph::calcMinDist() {
    unsigned int k;
    bool isBorder;
    for(unsigned int i=0; i<graph.size(); ++i) {
        if(graph[i].value()<0.0f) continue;
        float minDistSqr=HUGE_VALF;
        vec3f center(i%szX,i/szX);
        for(k=0; k<graph.size(); k++) if(graph[i].edge(k)) {
            isBorder=false;
            if(k<szX) isBorder=true;
            if(!graph[i].edge(k-szX)&&(k-szX!=i)) isBorder=true;
            if(k>=szX*szY-szX) isBorder=true;
            if(!graph[i].edge(k+szX)&&(k+szX!=i)) isBorder=true;
            if(k%szX==0) isBorder=true;
            if(!graph[i].edge(k-1)&&(k-1!=i)) isBorder=true;
            if(k%szX==szX-1) isBorder=true;
            if(!graph[i].edge(k+1)&&(k+1!=i)) isBorder=true;
            if(isBorder) {
                vec3f testPoint(k%szX,k/szX);
                float currDistSqr=center.sqrDistTo(testPoint);
                minDistSqr=min(minDistSqr,currDistSqr);
            }
        }
        graph[i].value()=sqrt(minDistSqr)*res;
    }
    // finish visualization:
    updateRange();
    msg="minimum wall distance, min="+f2s(valueMin)+", max="+f2s(valueMax);
    status=VGR_STATE_READY;
}
