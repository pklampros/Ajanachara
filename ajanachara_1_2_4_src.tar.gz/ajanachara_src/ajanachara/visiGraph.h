#ifndef _VISIGRAPH_H
#define _VISIGRAPH_H

#include <veStd.h>
#include <veGeoObj.h>
#include <veMath.h>

//--- class vgrVertex ----------------------------------------------- /*FOLD00*/
class visiGraph;
/// a class for representing view graph vertices
class vgrVertex {
public:
    /// default constructor
    vgrVertex(unsigned int nEdgesMax=0 )
    { vEdge.assign(nEdgesMax,false); val=0.0f; };
    /// constructor taking a vector of bool connections
    vgrVertex(const std::vector<bool> & connections );
    /// returns a reference of the characteristic value
    float & value() { return val; };
    /// returns the current characteristic value
    float value() const { return val; };
    /// allows access to connections to other vertices
    std::vector<bool> & edge() { return vEdge; };
    /// returns connection i to other vertices
    bool edge(unsigned int i) const { return vEdge[i]; };
    /// returns number of edges
    unsigned int size() const { return vEdge.size(); };

    /// returns all measurand labels
    static std::string labels(const std::string & sep=" ");
    /// computes and returns all measurands
    std::string measurands(const visiGraph & graph, unsigned int id, const ve::vec3f & pos,
                           const std::string & sep=" ") const;
    /// returns neighborhood size
    unsigned int neighbors() const;
    /// returns second order neighborhood size
    unsigned int neighbors2(const visiGraph & graph ) const;
    /// returns clustering coefficient
    float clustering(const visiGraph & graph ) const;
    /// computes revealed vertices by 1 step and stores it in f
    void revelation1(float * f, const visiGraph & graph) const;
    /// returns number of revealed vertices by 1 step
    unsigned int nRevelation(const visiGraph & graph) const;
    /// returns perimeter length
    unsigned int perimeterLength( const visiGraph & graph, unsigned int id) const;
    /// stores number of open and closed isovist boundaries in open and close
    void perimeterOpenness( unsigned int & open, unsigned int & close,
                           const visiGraph & graph, unsigned int id) const;
    /// computes principal components and extend in principal axes
    void PCA(ve::vec3f & vPriComp0, ve::vec3f & vPriComp1,
             float & minExtend0, float & maxExtend0,
             float & minExtend1, float & maxExtend1,
             const visiGraph & graph, unsigned int id) const;
    /// computes a polygonal isovist and stores control vertices in vPolygon
    /** \param vPolygon will be filled with the result
     \param center is the position for the isovist's center
     \param vBoundary holds the model geometry
     \param resolution defines the delta angle between the casted rays.
     \param tolerance defines the delta angle between ajacent vertices that is collapsed */
    void isovist(std::vector<ve::vec3f> & vPolygon, const ve::vec3f & center,
                 const std::vector<ve::triangle> & vBoundary,
                 float resolution, float tolerance) const;
    /// returns the ratio between visibly parts and invisible parts at a given fistance.
    /** \param position is the physical coordinates of the testpoint.
     \param vBoundary holds the model geometry.
     \param resolution defines the delta angle between the casted rays. */
    float visRatio(float distance, const ve::vec3f & pos,
                   const std::vector<ve::triangle> & vBoundary,
                   float resolution) const;
protected:
    /// stores characteristic value
    float val;
    /// stores connections to other vertices
    std::vector<bool> vEdge;
};

//--- class visiGraph ----------------------------------------------- /*FOLD00*/
enum { VGR_STATE_NONE=0,
       VGR_STATE_POSITION,
       VGR_STATE_ADDREMOVE,
       VGR_STATE_COMPUTE,
       VGR_STATE_CLUSTERING,
       VGR_STATE_NBH2,
       VGR_STATE_NVTX,
       VGR_STATE_COMPUTATION_DONE,
       VGR_STATE_READY,
       VGR_STATE_ISOVIST1,
       VGR_STATE_ISOVIST2,
       VGR_STATE_REVELATION1,
       VGR_STATE_VIEWRENDER,
       VGR_STATE_PERIMETER,
       VGR_STATE_CLUSTERING1,
       VGR_STATE_MEASURANDS,
       VGR_STATE_PCA,
       VGR_STATE_CIRCUM2,
       VGR_STATE_CIRCUM4,
       VGR_STATE_PROFILE
};

/// a class for visibility graph analysis
class visiGraph : public ve::geoObj {
public:
    /// default constructor
    visiGraph();
    /// constructor interpreting an initialization file
    visiGraph(ve::xmlIni & ini);
    /// destructor
    virtual ~visiGraph();
    /// draws object
    virtual void draw();
    /// resets graph to initial state
    void clear();
    /// starts an interactive generation process
    void generate(const ve::geoGroup & permeability);
    /// sets boundary model in the interactive process
    void boundaryModel(const ve::geoGroup & boundary, const std::string & name="");
    /// returns boundary model geometry
    const std::vector<ve::triangle> & boundary() const { return vBoundary; };
    /// returns graph resolution
    float resolution() const { return res; };
    /// allows access to graph resolution
    float & resolution() { return res; };
    /// sets graph origin
    void origin(float newX, float newY, float newZ ) { orig.set(newX,newY,newZ); };
    /// returns graph origin
    const ve::vec3f & origin() const { return orig; };
    /// allows modification of graph origin
    ve::vec3f & origin() { return orig; };
    /// returns whether transparent walls are ignored during graph calculation
    bool ignoreTranspWalls() const { return m_ignoreTransp; };
    /// allows to change whether transparent walls are ignored during graph calculation
    bool & ignoreTranspWalls() { return m_ignoreTransp; };
    /// returns state
    unsigned int state() const { return status; };
    /// sets state
    void state(unsigned int newState) { status=newState; };
    /// switches to next step, make computation or switch state
    void nextStep();
    /// returns reference to graph vertex n
    const vgrVertex & operator[](unsigned int n) const { return graph[n]; };
    /// adds or removes a cell from the view graph;
    void switchCell(const ve::line & ray);
    /// returns graph as string
    std::string str() const;
    /// returns boundary model name
    const std::string & modelName() const { return boundaryModelName; };
    /// loads visibility graph
    int load(const std::string & fileName);
    /// saves visibility graph
    int save(const std::string & fileName);
    /// saves current analysis
    int saveAnalysis(const std::string & fileName) const;
    /// returns current message
    std::string message() { std::string s=msg; msg=""; return s; };
    /// returns current progress value.
    /** The progress in long computations can be displayed this way.
     Values normally lie between 0.0 and 1.0. A Value < 0.0 indicates
     that now progress info is currently available. */
    float progress() const { return progrVal; };
    /// returns whether graph is currently displayed
    bool isShown() const { return isDisplayed; };
    /// sets whether graph is currently displayed
    void isShown(bool yesno) { isDisplayed=yesno; };
    /// returns graph's X size
    unsigned int sizeX() const { return szX; };
    /// returns graph's Y size
    unsigned int sizeY() const { return szY; };
    /// returns graph's size
    unsigned int size() const { return graph.size(); };
    /// returns value under the mouse pointer
    float value(const ve::line & ray);
    /// returns value at physical coordinate x|y
    float value(float x, float y);
    /// returns all measurands under the mouse pointer
    std::string measurands(const ve::line & ray);
    /// returns the isovist profile as polar distances
    std::string profile(const ve::line & ray, float resolution=1.0f);

    /// computes neighborhood size
    void computeNeighborhood();
    /// computes revelation by 1 step in every cardinal direction and stores it in value
    void computeRevelation1();
    /// shows a first order isovist
    void showIsovist(const ve::line & ray);
    /// shows a second order isovist
    void showIsovist2(const ve::line & ray);
    /// shows revelation by 1 step in every cardinal direction
    void showRevelation1(const ve::line & ray);
    /// renders view from picked position via external programs imgen (from scenegen) and povray
    void renderView(const ve::line & ray, ve::xmlIni ini);
    /// shows clustering from one vertex
    void showClustering(const ve::line & ray);
    /// shows the perimeter around a vertex
    void showPerimeter(const ve::line & ray);
    /// computes the perimeter length for all vertices
    void computePerimeterLength();
    /// computes the isovist perimeter length / area for all vertices
    void computePerimeterDivArea();
    /// computes the ratio between open and closed isovist perimeter boundaries for all vertices
    void computePerimeterOpenness();
    /// shows principal components of a first order isovist
    void showPCA(const ve::line & ray);
    /// shows visible and invisible vertices at distance radius
    void showCircum(const ve::line & ray, float radius);
    /// calculates ratio of visible and invisible vertices at distance radius
    void calcVisRatio(float radius);
    /// calculates minimum wall distance
    void calcMinDist();
    /// tests for an intersection between a line and a triangle array.
    /**
     \param vTr is a reference to the triangle array that is tested
     \param isRay (optional) defines whether the line is
     treated as as infinite ray starting from pt[0]. */
    static bool isIntersection(const std::vector<ve::triangle> & vTr, const ve::line & ln, bool isRay );
    /// returns intersection point between a line and a triangle array.
    /**
     \param vTr is a reference to the triangle array that is tested
     \param isRay (optional) defines whether the line is
     treated as as infinite ray starting from pt[0].
     \return NULL or intersection point. The memory of this vec
     has to be deallocated by the user! */
    static ve::vec3f * intersection(const std::vector<ve::triangle> & vTr, const ve::line & ln, bool isRay=true );

    /// returns last intersection coordinate
    const ve::vec3f & lastIntersection() { return m_lastIntersection; };
protected:
    /// tests for an intersection between a line and the graph.
    /**
     \param ray the line to be tested
     \param i graph X coordinate of intersection
     \param j graph X coordinate of intersection
     \return true in case of an intersection, otherwise false */
    bool intersects(const ve::line & ray, unsigned int & i, unsigned int & j);
    /// updates valueMin and valueMax
    void updateRange();

    /// stores origin of graph
    ve::vec3f orig;
    /// stores x size
    unsigned int szX;
    /// stores y size
    unsigned int szY;
    /// stores graph resolution
    float res;
    /// stores whether transparent walls are ignored during graph calculation
    bool m_ignoreTransp;
    /// stores perimeter resolution
    float periResolution;
    /// stores perimeter angle tolerance
    /** vertices with smaller angle differences may be discarded. */
    float periAngleTolerance;
    /// stores graph
    std::vector<vgrVertex> graph;

    /// stores state of view graph
    unsigned int status;
    /// counter variable for non-blocking operations
    unsigned int step;
    /// stores boundary geometry
    std::vector<ve::triangle> vBoundary;
    /// stores permeability geometry
    std::vector<ve::triangle> vPermeability;
    /// stores current minimum value
    float valueMin;
    /// stores current maximum value
    float valueMax;
    /// stores minimum coordinate
    ve::vec3f minCoord;
    /// stores maximum coordinate
    ve::vec3f maxCoord;
    /// stores last intersection vertex
    ve::vec3f m_lastIntersection;
    /// stores current message
    std::string msg;
    /// stores current progress value
    float progrVal;
    /// stores graph file name
    std::string graphFileName;
    /// stores boundary model name
    std::string boundaryModelName;

    /// stores graph vertices
    std::vector<ve::vec3f> vVertex;
    /// stores whether graph is currently displayed
    bool isDisplayed;

    // values for showing the PCA, probably temporary:
    /// current analysed vertex
    ve::vec3f standPoint;
    /// center of gravity of viewshed
    ve::vec3f centroid;
    /// eigenvectors of PCA of viewshed
    ve::vec3f vEig[2];
    /// maximum extends of viewshed from standPoint in eigenvector coordinates
    float minExtend0, maxExtend0, minExtend1, maxExtend1;

    /// stores boundary vertices
    std::vector<ve::vec3f> vPolyBoundary;
};


#endif // _VISIGRAPH_H
