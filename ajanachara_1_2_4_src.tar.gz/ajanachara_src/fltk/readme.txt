put here a recent copy of FLTK (www.fltk.org). Tested with FLTK 1.1.6.
