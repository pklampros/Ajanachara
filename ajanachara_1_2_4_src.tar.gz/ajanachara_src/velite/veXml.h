#ifndef _VE_XML_H
#define _VE_XML_H
/** @file veXml.h
 \brief contains the classes ve::xml and ve::xmlIni.

 Header dependencies:\n
 important note: please do not introduce additional dependencies
 except to the c/c++ stdlib. If you have to, please consult gf,
 otherwise you may unintentionally brake a lot of code.

 veLib Copyright 2003 - 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author  gf & jmw
 $Revision: 2.0 $
 */


#include "veStd.h"
#include "veStrUtils.h"


// veLib standard namespace - look into veStd.h for more documentation
namespace ve {

//--- class ve::xml documentation ---------------------------------- /*fold00*/
/// basic XML class.
/**
 This class implements the basic tree-like structure of XML
 and provides methods for accessing all different kind of data,
 file input-output and searching and parsing.
 A typical xml statement consists of a tag, some attributes,
 a content, and may contain substatements:\n
 \n
 \verbatim
 <tag attributeName1="attributeValue1" attributeName2="attributeValue2">
   content, may be arbitrary long
   <substatement1/>
   <substatement2/>
   ...
 </tag>
 \endverbatim

 \author  gf
 $Revision: 2.0 $
 */

//--- class ve::xml declaration ------------------------------------ /*fold00*/
class xml {
public:
    /// standard constructor
    xml();
    /// initializing constructor
    xml(const std::string & tag, const std::string & id="", const std::string & content="");
    /// copy constructor
    xml(const ve::xml &source);

    /// destructor
    virtual ~xml();
    /// copy operator=
    ve::xml &operator=(const ve::xml & source);
    /// returns attribute value as string. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(const std::string & name, const std::string & defStr="") const;
    /// returns attribute value as string. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(const char * name, const std::string & defStr="") const { return getAttribute(std::string(name),defStr); };
    /// returns value of attribute n as string. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(unsigned int n, const std::string & defStr="") const;
    /// returns name of attribute n as string. If attribute n does not exist, an empty string is returned.
    virtual std::string attributeName(unsigned int n) const;
    /// sets a string attribute value. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, const std::string & value);
    /// sets a char * attribute value. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, const char * value) { setAttribute(name,std::string(value)); };
    /// sets a int attribute value. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, int value) { setAttribute(name,ve::i2s(value)); };
    /// sets a float attribute value. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, float value) { setAttribute(name,ve::f2s(value)); };
    /// sets a bool attribute value. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, bool value, bool asText=false) { setAttribute(name,ve::b2s(value,asText)); };
    /// remove attribute
    virtual int dropAttribute(const std::string & name);
    /// adds child statement either as pointer reference or as new copy, which will be only deleted via the parent
    virtual void addChild(xml * xmlSt, int asCopy=0 );
    /// adds a copy of xmlSt as new child statement, its scope is identical to its parent's scope
    virtual void addChild(const xml & xmlSt);
    /// drops child statement. If delByParent, the memory is actually freed.
    virtual int dropChild(xml * xmlSt);
    /// returns address of parent statement or NULL if toplevel
    virtual xml * parent() const { return pParent; };
    /// sets tag name
    virtual void tag(const std::string & name) { tagStr=name; };
    /// returns tag name
    virtual const std::string & tag() const { return tagStr; };
    /// sets content
    virtual void content(const std::string & cont) { contentStr=cont; };
    /// returns content, content is editable.
    virtual std::string & content() { return contentStr; };
    /// returns content, const.
    virtual const std::string & content() const { return contentStr; };
    /// returns number of children statements
    unsigned int nChildren() const { return static_cast<unsigned int>(vChildren.size()); };
    /// returns number of attributes
    unsigned int nAttributes() const { return static_cast<unsigned int>(attr.size()/2); };
    /// returns the nth child statement or NULL
    virtual ve::xml * child(unsigned int number);
    /// returns the nth child statement or NULL, const
    virtual const ve::xml * child(unsigned int number) const;
    /// returns a specified child statement or NULL
    virtual ve::xml * child(const std::string & tagName, const std::string & id="");
    /// returns a preformatted xml string
    virtual std::string str(unsigned int nTabs=0) const;
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found
    virtual ve::xml * subTag(const std::string & tagName, const std::string & id="");
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found, const
    virtual const ve::xml * subTag(const std::string & tagName, const std::string & id="") const;
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found
    virtual ve::xml * subTag(const std::string & tagName, unsigned int id);
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found, const
    virtual const ve::xml * subTag(const std::string & tagName, unsigned int id) const;
    /// returns a pointer to a subtag with a suitable attribute and value, or NULL if none is found
    virtual ve::xml * subTagAttribute(const std::string & attribute, const std::string & value);

    /// clears all existing information.
    virtual void clear();
    /// loads xml from disk, previous information is cleared.
    /** \param filename url of the file to be loaded
     \return number of detected errors. */
    virtual int load(const std::string & filename);
    /// interprets xmlString as xml, previous information is cleared.
    void interpret(const std::string & xmlString);
    /// writes xml to disk.
    int save(const std::string filename) const;
    /// encodes special characters in xml
    static std::string encode(std::string source);
    /// translates encoded special characters from XML to ascii
    static std::string decode(std::string source);

protected:
    /// converts preparsed tokens to an xml
    void parse(const std::vector<std::string> &token);
    /// stores xml tag
    std::string tagStr;
    /// stores xml attributes, keys have even indizes, values odd indizes.
	std::vector<std::string> attr;
    /// content of the xml statement
    std::string contentStr;
    /// stores pointers to subordinate statements
	std::vector<xml *> vChildren;
    /// stores pointer to superordinate statement
    ve::xml * pParent;
    /// stores whether statement should be deleted when parent gets deleted
    int delByParent;
};
} // namespace ve

/// just a good friend of xml, performs output in a C++ standard stream.
std::ostream & operator<<(std::ostream & os, const ve::xml & xs);

//--- class ve::xmlIni documentation ------------------------------- /*fold00*/
namespace ve {
/** \brief A class for reading variable values from XML inifiles.
 This class complements the basic xml class with convenient
 parsing functions for basic data types. It is a good way for reading
 initialization information and for transfering information between
 programs in temporary files.

 brief usage:
 xml.load("filename.xml") loads the content of the xml file filename.xml
 into memory. After that the content of this file is parsable using the
 read methods.\n
 All the read methods share a similar interface:
 The first argument is a reference of the variable where the data will be stored.
 The second argument is a char * or a c++ string which contains the id of
 the searched statement. An optional third argument contains a standard
 value, which is assigned if a suitable statement is not found.

 <b> Example</b>\n
 \code
 <xml_code_snippet>
 <int id="trials"> 5 </int>
 <string id="mail_address">agbu\@tuebingen.mpg.de</string>
 </xml_code_snippet>

 // c code snippet for reading that data:
 int numTrials=0;   // these vars will give storage for our read data
 string replyTo;

 ve::xmlIni myIniFile;                        // create an xml file object
 myIniFile.load("../info/test.xml");     // open a certain file for reading
 myIniFile.read(numTrials,"trials",3);   // this method call searches for an
 // xml statement of type int with the
 // attribute id="trials", and stores
 // the found data in numTrials. For
 // stability an optional default
 // initialization should be provided.
 myIniFile.read(replyTo,"mail_address"); // dito, only with a string
 \endcode

 \author  gf & jmw
 $Revision: 2.0 $ */

//--- class ve::xmlIni declaration --------------------------------- /*fold00*/

class xmlIni : public ve::xml {
public:
    /// standard constructor
    xmlIni() : ve::xml() { focus=(ve::xml*)this; };
    /// constructor taking int argument
    xmlIni(const std::string & id, int content);
    /// constructor taking float argument
    xmlIni(const std::string & id, float content);
    /// constructor taking std::string argument
    xmlIni(const std::string & id, const std::string & content);
    /// constructor taking float vector
    xmlIni(const std::string & id, std::vector<float> vContent);
    /// constructor taking int vector
    xmlIni(const std::string & id, std::vector<int> vContent);
    /// constructor taking vector of vector of int
    xmlIni(const std::string & id, std::vector<std::vector <int> > vvContent);
    /// constructor taking vector of vector of float
    xmlIni(const std::string & id, std::vector<std::vector <float> > vvContent);
    /// copy constructor
    xmlIni(const ve::xmlIni & source);
    /// copy constructor with an xml as source
    xmlIni(const ve::xml &source);
    /// loads xml inifile from disk
    /** in addition to xml::load, xml <include url="xyz"/> statements are resolved.
     \param filename url of the file to be loaded
     \return number of detected errors. */
    virtual int load(const std::string & filename);

    /// copy operator=
    xmlIni & operator=(const xmlIni & source);
    /// reads  an int value, if not found in file assign default value
    int read(int & pInt, const std::string & id, int defValue=0 ) const;
    /// reads an unsigned int value, if not found in file default value is assigned
    int read(unsigned int & uInt, const std::string & id, unsigned int defValue=0 ) const;
    /// reads  a float value, if not found in file assign default value
    int read(float & fl, const std::string & id, float defValue=0.0f ) const;
    /// reads  a bool value, if not found in file assign default value
    int read(bool & yesno, const std::string & id, bool defValue=false ) const;
    /// reads  a c string value, if not found in file assign default value
    int read(char * & pChar, const std::string & id, char *defValue="" ) const;
    /// reads  a c++ string value, if not found in file assign default value
    int read(std::string & str, const std::string & id, std::string defValue="" ) const;
    /// reads  a 2 dimensional int vector
    int read(std::vector< std::vector<int> > & vvInt, const std::string & id ) const;
    /// reads  a 1 dimensional int vector
    int read(std::vector<int> & vInt, const std::string & id ) const;
    /// reads n values into a 1 dimensional int array. If not enough values can be extracted, defValue is assigned.
    int read(int * pInt, unsigned int n, const std::string & id, int defValue=0 ) const;
    /// reads  a 2 dimensional float vector
    int read(std::vector< std::vector<float> > & vvFloat, const std::string & id ) const;
    /// reads  a 1 dimensional float vector
    int read(std::vector<float> & vFloat, const std::string & id ) const;
    /// reads n values into a 1 dimensional float array. If not enough values can be extracted, defValue is assigned.
    int read(float * pFloat, unsigned int n, const std::string & id, float defValue=0.0 ) const;
    /// reads  a char array vector
    int read(std::vector<char*> & vStr, const std::string & id ) const;
    /// reads  a string vector
    int read(std::vector< std::string > & vStr, const std::string & id ) const;
    /// tries to restrict search to the given tag, if successful 0 is returned, otherwise ve::ERR_NOT_FOUND
    int focusOn(const std::string & tagName, const std::string & id="");
    /// tries to restrict search to the given tag, if successful 0 is returned, otherwise ve::ERR_NOT_FOUND
    int focusOn(const std::string & tagName, unsigned int id);
    /// releases restriction of search
    void focusOff() { focus=(xml*)this; };
    /// returns number of children statements, using current focus
    unsigned int nChildren() const { return focus->xml::nChildren(); };
    /// returns a pointer to the nth child statement or NULL
    virtual xml * child(unsigned int number) { return focus->xml::child(number); };
    /// returns a pointer to the nth child statement or NULL, const
    virtual const xml * child(unsigned int number) const { return focus->xml::child(number); };
    /// returns a pointer to a specified child statement or NULL
    virtual xml * child(std::string tagName, std::string id="") { return focus->xml::child(tagName,id); };
    /// returns the number of attributes, using current focus
    unsigned int nAttributes() const {
        return focus->xml::nAttributes(); };
    /// sets a string attribute value, using current focus. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, const std::string & value) {
        focus->xml::setAttribute(name,value); };
    /// sets a char * attribute value, using current focus. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, const char * value) { setAttribute(name,std::string(value)); };
    /// sets a int attribute value, using current focus. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, int value) { setAttribute(name,ve::i2s(value)); };
    /// sets a float attribute value, using current focus. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, float value) { setAttribute(name,ve::f2s(value)); };
    /// sets a bool attribute value, using current focus. If it does not exist, a new attribute is added
    virtual void setAttribute(const std::string & name, bool value, bool asText=false) { setAttribute(name,ve::b2s(value,asText)); };
    /// returns an attribute value as string. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(const std::string & name, const std::string & defStr="") const {
        return focus->xml::getAttribute(name,defStr); };
    /// returns an attribute value as string. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(const char * name, const std::string & defStr="") const {
        return focus->xml::getAttribute(std::string(name),defStr); };
    /// returns an value of attribute n as string, using current focus. If it does not exist, defStr is returned.
    virtual const std::string & getAttribute(unsigned int n, const std::string & defStr="") const {
        return focus->xml::getAttribute(n,defStr); };
    /// returns a preformatted xml string
    virtual std::string str(unsigned int nTabs=0) const {
        return focus->xml::str(nTabs); };
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found
    virtual ve::xml * subTag(const std::string & tagName, const std::string & id="") {
        return focus->xml::subTag(tagName,id); };
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found, const
    virtual const ve::xml * subTag(const std::string & tagName, const std::string & id="") const {
        return focus->xml::subTag(tagName,id); };
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found
    virtual ve::xml * subTag(const std::string & tagName, unsigned int id) {
        return focus->xml::subTag(tagName,id); };
    /// returns a pointer to a subtag with suitable tag and id, or NULL if none is found, const
    virtual const ve::xml * subTag(const std::string & tagName, unsigned int id) const {
        return focus->xml::subTag(tagName,id); };
protected:
    /// stores current search restriction or NULL if none
    ve::xml * focus;
};
} // namespace ve

/* #[ cvs history log : *///---------------------------------------- /*FOLD00*/
/*
 * $Log: veXml.h,v $
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.93  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.92  2004/10/04 09:38:43  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.91  2004/08/22 20:06:32  gf
 * very crappy include implementation improved. Please take mare care on
 * potential security/bug issues next time!
 *
 * Revision 1.90  2004/08/12 08:59:57  weyel
 * xml files may now contain include statements, a simple text replace
 * is performed.
 *
 * Revision 1.89  2004/08/04 12:17:54  gf
 * copyright update
 *
 * Revision 1.88  2004/08/03 12:57:47  weyel
 * - fileIo::unifyPath() added do deal with slashes in filepaths
 * - collisionTriangle::altitude() added, returns height over a surface
 * - slight adaptations in some other files
 * - added deviceNetworkUDP, still based on SDLNet but will be
 *   changed to BSD sockets soon
 *
 * Revision 1.87  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.86  2004/04/20 10:16:45  gf
 * - 3ds loader now interprets transparency
 * - better compatibility to X3D, but translation not yet finished!
 *
 * Revision 1.85  2004/02/27 16:53:52  gf
 * - dataContainer completely remodeled
 * - xmlIni::subTag() methods added
 * - update() interface for devices unified
 * - deviceGraphicsX3D::followObject() bug fixed
 *
 * Revision 1.84  2004/02/24 13:33:33  gf
 * - ve::vec (veMath.h) renamed to ve::vec3f
 * - VEEC_XYZ (veTypes.h) error codes renamed to ve::ERR_XYZ
 *
 * Revision 1.83  2004/01/23 11:20:24  gf
 * - inifile xml syntax unified
 * - veDeviceGraphics3dPf temporarily moved to modules
 *
 * Revision 1.82  2004/01/20 16:40:52  gf
 * ve::xml renamed to ve::xmlIni, ve::xmlStatement renamed to ve::xml
 *
 * Revision 1.81  2004/01/19 10:21:57  gf
 * - namespace ve now consequently used in more classes
 * - veImg.h/.cpp renamed to veImage.h/.cpp
 *
 * Revision 1.80  2003/10/28 14:34:58  gf
 * docu updated
 *
 * Revision 1.79  2003/07/25 10:59:25  gf
 * copyright update
 *
 * Revision 1.78  2003/06/23 14:57:12  weyel
 * made it compile with new talk version
 *
 * Revision 1.77  2003/05/30 08:32:06  gf
 * added more documentation
 *
 * Revision 1.76  2003/05/21 09:15:23  mvdh
 * fixed several doxygen errors and warnings
 *
 * Revision 1.75  2003/04/22 17:16:31  gf
 * veXml::setAttribute() methods now take care of focus
 *
 * Revision 1.74  2003/03/31 16:19:52  gf
 * namespace ve added. Should be consequently used instead of VE_ etc.
 *
 * Revision 1.73  2003/03/26 15:31:25  gf
 * - unnecessary declarations of istrstream and ostrstream removed
 * - NO std::bloat in .cpp files please, seriously ;-)!
 *
 * Revision 1.72  2003/03/25 21:33:33  mvdh
 * doxygenify most standard doc++ statements
 *
 * Revision 1.71  2003/03/25 17:29:01  mvdh
 * major changes in most files - cebit version from MvdH now in action - please watch out for eventual errors and conflicts - now windows and linux support
 */
/* #] history : */

#endif
