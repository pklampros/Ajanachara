#ifndef _VE_GEOOBJ_H
#define _VE_GEOOBJ_H
/** @file veGeoObj.h
 \brief Contains geometry primitives classes.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author  gf
 $Revision: 2.9 $
 */

#include "veStd.h"
#include "veXml.h"
#include "veMath.h"

namespace ve {
// forward declarations:
class plugin;
class geoGroup;
class geoObj;

//--- class ve::ioFileHandler -------------------------------------- /*fold00*/
/// a small auxilliary class that allows the writing of plugin file handlers
class ioFileHandler {
public:
    /// constructor that just registers a loader function
    /** use a static object to register the file handler function at start up.
     The function has to be of type geoObj* loadXYZ(const std::string & filename).*/
    ioFileHandler(geoObj*(*loadFunc)(const std::string &), const std::string & suffix) {
        vLoadFunc.push_back(loadFunc); vSuffix.push_back(suffix); };
    /// tries to load a file using previously registered loader functions
    /** \param filename path to the file to be loaded, type will be identified by suffix
     \return pointer to loaded model or 0. */
    static ve::geoObj * load(const std::string & filename);
protected:
    /// vector to store registered loader functions
    static std::vector<ve::geoObj* (*)(const std::string &)> vLoadFunc;
    /// vector to store registered file suffixes
    static std::vector<std::string> vSuffix;
};


//--- class ve::ioVrml --------------------------------------------- /*fold00*/
/// a class for VRML input/output
class ioVrml {
public:
    /// converts vrml geometry from a file to x3d.
    /** \param filename the file to be converted,
     \param xs reference of ve::xml object that is filled with the geometry information,
     \return 0 in case of success. */
    static int toX3d (const std::string & filename, ve::xml & xs);
    /// interprets VRML file as geoObjects.
    /** Currently solely IndexedFaceSet, ElevationGrid, Material, and Transform nodes are interpreted.
     This static method first converts the VRML file into X3D, then the X3D geometry definition is interpreted.
     \param filename the file to be loaded,
     \param vObj is filled with interpreted geoObj.
     \return 0 in case of success. */
    static int toGeo(const std::string & filename, std::vector<ve::geoObj*> & vObj);
    /// converts a vector of vertices from vrml coordinate system to veLib coordinate system
    static void vrml2ve(std::vector<ve::vec3f> & vCoord);
};


//--- class ve::ioX3d ---------------------------------------------- /*fold00*/
/// a class for X3d input/output
class ioX3d {
public:
    /// interprets X3D file as geoObjects.
    /** Currently solely IndexedFaceSet, ElevationGrid, Material, and Transform nodes are interpreted.
     \param xs has to be passed as reference, because USE attributes have to be substituted.
     \param vObj is filled with interpreted geoObj.
     \return 0 in case of success. */
    static int toGeo(const std::string & filename, std::vector<ve::geoObj*> & vObj);
    /// interprets x3d defined geometry as geoObjects.
    /** Currently solely IndexedFaceSet, ElevationGrid, Material, and Transform nodes are interpreted.
     \param filename the file to be loaded,
     \param vObj is filled with interpreted geoObj.
     \return 0 in case of success. */
    static int toGeo(ve::xml & xs, std::vector<ve::geoObj*> & vObj);

    /// tries to interprets xs as X3D node
    static int interpretNode(ve::xml & xs, std::vector<ve::geoObj*> & vObj, ve::matStack4f & m );
    /// interprets a single X3D defined transform node
    /** \param xs the xml statement to be parsed
     \param vrml2ve defines whether the transformation shall be translated from VRML to the veLib coordinate system
     \return a matrix containing all transformations. */
    static ve::mat4f interpretTransform(const ve::xml & xs, bool vrml2ve=true);
};


//--- class ve::geoObj --------------------------------------------- /*fold00*/
/// base class for all derived geometry objects.
/** This class defines the shared methods of all geometry objects.
 It also defines the interface for drawing and graphics initialization. */
class geoObj {
public:
    /// default constructor, optional argument is user definable class id.
    geoObj(unsigned int newId=0);
    /// copy constructor
    geoObj(const ve::geoObj & source);
    /// destructor
    virtual ~geoObj();

    /// sets the parent object
    virtual void parent(ve::geoGroup * glO) { m_pParent=glO; };
    /// returns a pointer to the parent object
    virtual ve::geoGroup * parent() { return m_pParent; };
    /// returns number of direct children
    virtual unsigned int nChildren() const { return 0; };
    /// returns state
    /** The codes used are the generic veLib errorCodes . */
    unsigned int state() const { return m_state; };

    /// returns color
    const ve::vec4f & color () const { return m_color; };
    /// allows access to color
    ve::vec4f & color () { return m_color; };
    /// returns transparency state
    bool isTransparent() const { return m_isTransp; };

    /// returns automatically generated unique id
    int id() const { return m_id; };
    /// sets user definable id
    void classId(unsigned int newId) { m_classId=newId; };
    /// returns user definable id
    unsigned int classId() const { return m_classId; };
    /// returns name
    const std::string & name() const { return m_name; };
    /// sets name
    void name( const std::string & s ) { m_name=s; };
    /// returns user data
    const void * userData() const { return m_pUserData; };
    /// allows access to user data
    void * userData() { return m_pUserData; };

    /// transforms this object by multiplying it with matrix m, interface definition.
    virtual void transform(const ve::mat4f & m) { ; };

    /// draws object, interface definition.
    virtual void draw() { ; };
    /// performs geometry calculations, interface definition.
    virtual void initGeometry() { ; };
    /// performs graphics initializations, interface definition.
    virtual void initGraphics() { ; };
    /// performs graphics cleanups, interface definition.
    virtual void closeGraphics() { ; };

    /// computes the bounding geometry.
    /** interface definition, not for realtime! */
    virtual void calcBounding() { ; };
    /// tests for intersection with the bounding geometry
    /** \param fr the frustum to be tested
     \param pos (optional) additional translation of the object
     \return true if the bounding geometry is intersected, otherwise false. */
    virtual bool testBounding(const ve::frustum & fr,
                              const ve::vec6f & pos=ve::vec6f(0,0,0)) const;
    /// returns the bounding sphere
    virtual const ve::sphere & boundingSphere() const { return m_bndSphere; };
    /// draws bounding geometry, mainly for debug purposes
    virtual void drawBounding();

    /// fills tr with triangles, interface definition
    virtual void triangles(std::vector<ve::triangle> & ) const { ; };
    /// puts all vertices in vVertices, interface definition.
    virtual void vertices(std::vector<ve::vec3f> & ) const { ; };
    /// returns geometry as VRML, interface definition.
    virtual std::string vrml(unsigned int nTabs=0) const { return ""; };
    /// returns an xml statement, containing all data, interface definition.
    virtual ve::xml xml() const;

    /// sets the current time
    /** this static method allows to set a global time for the rendering
     of time-dependent objects such as animated billboards or characters.
     The idea is to call the method once per frame, as done by deviceGraphicsX3D.
     \param tNow the current time stamp in seconds*/
    static void setCurrTime(double tNow) { s_tNow=tNow; };
    /// sets the current camera position
    /** this static method allows to set a global camera for the rendering
     of view-dependent objects such as billboards. Since the method takes a
     pointer, it has to be called normally only once at the beginning of the program
     execution, as done by deviceGraphicsX3D.
     \param pCamera pointer to the camera sixdof. Use 0 to disable view-dependent rendering.*/
    static void setCamera(ve::vec6f * pCamera) { s_pCamera=pCamera; };

    /// pointer to an eventual plugin
    ve::plugin *m_plugin;
protected:
    // stores transformation matrix.
    //ve::mat4f m_mat;
    /// stores bounding sphere
    ve::sphere m_bndSphere;
    /// pointer to parent glObj
    ve::geoGroup * m_pParent;
    /// pointer to user data
    void * m_pUserData;

    /// stores color
    ve::vec4f m_color;
    /// stores whether object is transparent
    bool m_isTransp;
    /// stores state
    unsigned int m_state;

    /// stores automatically generated unique number
    int m_id;
    /// stores user definable id
    unsigned int m_classId;
    /// stores name
    std::string m_name;

    /// stores current time
    static double s_tNow;
    /// stores pointer to current scene camera
    static ve::vec6f * s_pCamera;
private:
    /// for giving each object a unique number
    static int s_counter;
};

//--- class ve::geoGroup ------------------------------------------- /*fold00*/
class geoMesh;
/// base class for organizing ve::geoObjects in a tree-like structure.
/** This class makes use of the ve::io classes to load and interpret X3D, VRML and 3ds files. */
class geoGroup : public ve::geoObj {
public:
    /// default constructor, optional argument is user definable class id
    geoGroup(unsigned int newId=0) : ve::geoObj(newId) {
        m_cleanupChildren=false; m_isIdentity=true; };
    /// constructor loading a model from a file.
    /** \param filename must contain the filename plus path,
     \param newId (optional) is a user definable class id. */
    geoGroup(const std::string & filename, unsigned int newId=0 );
    /// destructor
    virtual ~geoGroup();
    /// draws object.
    /** calls draw methods of children. */
    virtual void draw();
    /// performs OpenGL initializations.
    /** calls initGraphics() of all children. */
    virtual void initGraphics();
    /// regionalizes this group in a boxtree structure.
    /** The boxtree structure is similar to a quadtree or octree, but
     assigns objects intersected by the clipping plane to the best sector if possible.
     That means, it may be suboptimal for carefully modeled scenes, but tolerant for others.*/
    void regionalize(unsigned int currRecursion=0);
    
    /// returns transformation matrix m
    const ve::mat4f & transform() const { return m_mat; };
    /// transforms this object by multiplying it with matrix m.
    /** beware of scalings or shears! */
    virtual void transform(const ve::mat4f & m) {
        m_mat=m*m_mat; m_isIdentity=false; };
    /// sets transformation to matrix m.
    /** beware of scalings or shears! */
    virtual void setTransform(const ve::mat4f & m) {
        m_mat=m; m_isIdentity=false; };
    /// sets transformation to vec6f sixdof.
    virtual void setTransform(const ve::vec6f & sixdof) {
        ve::mat4f m(sixdof); m_mat=m; m_isIdentity=false; };
    virtual void resetTransform() {
        m_mat.identity(); m_isIdentity=true; };

    /// adds a child glObj
    virtual void addChild(ve::geoObj * geoObject);
    /// removes a child glObj
    virtual void dropChild(ve::geoObj * geoObject);
    /// returns number of direct children
    virtual unsigned int nChildren() const { return static_cast<unsigned int>(vChildren.size()); };
    /// allows read access to children vector, always empty
    const std::vector<ve::geoObj*> & children() const { return vChildren; };

    /// computes the bounding sphere, not for realtime!
    virtual void calcBounding();
    /// computes and returns the minimum coordinates
    const ve::vec3f minCoord() const;
    /// computes and returns the maximum coordinates
    const ve::vec3f maxCoord() const;

    /// fills tr with triangles of all children
    virtual void triangles(std::vector<ve::triangle> & tr) const;
    /// puts all vertices in vVertices.
    virtual void vertices(std::vector<ve::vec3f> & vVertices) const;
    /// returns geometry as VRML
    virtual std::string vrml(unsigned int nTabs=0) const;
protected:
    /// vector for pointers to geoObj children
    std::vector<ve::geoObj*> vChildren;
    /// stores whether this group has been loaded from a file.
    bool m_cleanupChildren;
    /// stores current transformation
    ve::mat4f m_mat;
    /// stores whether current transformation is for sure an identity matrix
    bool m_isIdentity;
};

//--- class ve::geoMesh -------------------------------------------- /*fold00*/

/// a class for generic indexedFaceSet objects.
class geoMesh : public geoObj {
public:
    /// default constructor, empty mesh.
    geoMesh();
    /// copy constructor
    geoMesh(const ve::geoMesh& source);
    /// constructor interpreting an X3D defined IndexedFaceSet node.
    geoMesh(const ve::xml & xs);

    /// draws object
    virtual void draw();
    /// initializes GL, uploads textures to OpenGL.
    virtual void initGraphics();

    /// transforms this object by multiplying it with matrix m, not for realtime!.
    virtual void transform(const ve::mat4f & m) {
        m.transform(m_vCoord); };
    /// computes the bounding geometry, not for realtime!
    virtual void calcBounding();

    /// puts all vertices in vVertices.
    virtual void vertices(std::vector<ve::vec3f> & vVertices) const;
    /// fills tr with corresponding triangles, triangle coordinates are transformed
    virtual void triangles(std::vector<ve::triangle> & tr) const;
    /// triangulates mesh polygons.
    void triangulate();

    /// allows direct access to coordinate data.
    std::vector<ve::vec3f> & coords() { return m_vCoord; };
    /// allows direct reading of coordinate data.
    const std::vector<ve::vec3f> & coords() const { return m_vCoord; };
    /// allows direct access to texture coordinate data.
    std::vector<ve::vec2f> & texCoords() { return vTexCoords; };
    /// allows direct reading of texture coordinate data.
    const std::vector<ve::vec2f> & texCoords() const { return vTexCoords; };
    /// allows direct access to indices.
    std::vector<unsigned int> & indices() { return vIndices; };
    /// allows direct reading of indices.
    const std::vector<unsigned int> & indices() const { return vIndices; };
    /// allows direct access to face ends.
    std::vector<unsigned int> & faceEnds() { return vFaceEnds; };
    /// allows direct reading of face ends.
    const std::vector<unsigned int> & faceEnds() const { return vFaceEnds; };
    /// allows direct reading of vertex colors.
    const std::vector<ve::vec3f> & vertexColors() const { return m_vColor; };
    /// allows direct access to vertex colors.
    std::vector<ve::vec3f> & vertexColors() { return m_vColor; };
    /// allows direct reading of vertex color indices.
    const std::vector<unsigned int> & colorIndices() const { return vColorIndices; };
    /// allows direct access to vertex color indices.
    std::vector<unsigned int> & colorIndices() { return vColorIndices; };

    /// adds a complete texture definition.
    int addTexture(const std::string & filename, const std::vector<float> & texCoords, bool repeatTexture=true);
    /// returns true if mesh is textured.
    bool isTextured() const { return (m_texName.size()>0); };
    /// allows access to texture filename
    std::string & textureFileName() { return m_texName; };
    /// returns texture filename
    const std::string & textureFileName() const { return m_texName; };
    /// returns whether texture is repeated
    bool textureRepeat() const { return m_texRepeat; };
    /// allows to change whether texture is repeated
    bool & textureRepeat() { return m_texRepeat; };

    /// returns a string containing all data as VRML.
    virtual std::string vrml(unsigned int nTabs=0) const;
protected:
    /// fills tr with corresponding triangles, triangle coordinates are untransformed
    virtual void trianglesRaw(std::vector<ve::triangle> & tr) const;

    /// stores coordinates
    std::vector<ve::vec3f> m_vCoord;
    /// stores texture coords
    std::vector<ve::vec2f> vTexCoords;
    /// stores color values, if color per vertex
    std::vector<ve::vec3f> m_vColor;
    /// stores the object's normals
    std::vector<ve::vec3f> m_vNormal;
    /// stores indices
    std::vector<unsigned int> vIndices;
    /// stores texture indices
    std::vector<unsigned int> vTexIndices;
    /// stores color indices, if color per vertex
    std::vector<unsigned int> vColorIndices;
    /// stores the object's normal indices
    std::vector<unsigned int> m_vNormalIndex;

    /// stores indices of face ends
    std::vector<unsigned int> vFaceEnds;
    /// stores texture filename
    std::string m_texName;
    /// stores wrap mode for texture
    bool m_texRepeat;
    /// stores texture id
    unsigned int m_texId;
    /// stores OpenGL display list id.
    unsigned int m_listId;
};
} // namespace ve

/// operator for output of geoMeshes in ostreams.
std::ostream & operator<<(std::ostream & os, const ve::geoMesh & mesh);

//--- class ve::geoElevationGrid ----------------------------------- /*fold00*/

namespace ve {

/// a class for interpreting and displaying elevation grids / terrain models
class geoElevationGrid : public ve::geoObj {
public:
    /// constructor from memory data
    geoElevationGrid(const float * pElev, unsigned int dimX, unsigned int dimY, float spacingX, float spacingY, float scaleZ=1.0f );
    /// constructor interpreting an X3D defined ElevationGrid node.
    geoElevationGrid(const ve::xml & xs);
    /// performs OpenGL initializations.
    virtual void initGraphics();
    /// draws the elevation grid
    virtual void draw();
    /// fills tr with corresponding triangles
    void triangles(std::vector<ve::triangle> & tr) const;

    /// transforms this object by multiplying it with matrix m, not for realtime!.
    virtual void transform(const ve::mat4f & m) {
        m.transform(m_vCoord); };
    /// computes the bounding geometry, not for realtime!
    virtual void calcBounding();

    /// returns x dimension
    unsigned int dimX() const { return m_dimX; };
    /// returns y dimension
    unsigned int dimY() const { return m_dimY; };
    /// returns z value of grid cell x|y
    float zValue(unsigned int x, unsigned int y) const { return m_vCoord[(x%m_dimX)+m_dimX*(y%m_dimY)][Z]; };
    /// allows access to z value of grid cell x|y
    float & zValue(unsigned int x, unsigned int y) { return m_vCoord[(x%m_dimX)+m_dimX*(y%m_dimY)][Z]; };
    /// returns elevation at spatial coordinate x|y
    float elevation(float x, float y) const;
protected:
    /// stores x dimension
    unsigned int m_dimX;
    /// stores y dimension
    unsigned int m_dimY;
    /// stores x spacing
    float m_spaceX;
    /// stores y spacing
    float m_spaceY;
    /// stores vertices
    std::vector<ve::vec3f> m_vCoord;
    /// stores the object's normals
    std::vector<ve::vec3f> m_vNormal;

    /// stores the elevation grid's texture coordinates
    std::vector<ve::vec2f> m_vTexCoord;
    /// stores texture filename
    std::string m_texName;
    /// stores texture id
    unsigned int m_texId;
    /// stores texture coordinate scaling
    ve::vec2f m_texCoordScale;
};

} // namespace ve


//--- cvs history log ---------------------------------------------- /*FOLD00*/
/*
 * $Log: veGeoObj.h,v $
 * Revision 2.9  2005/01/17 09:28:31  gf
 * namespace quirks of plugins solved
 *
 * Revision 2.8  2005/01/10 18:03:02  franck
 * First (simple) version where a plugin can be used to draw a geoObj
 *
 * Revision 2.6  2005/01/03 10:53:24  gf
 * glBoxtree functionality now part of geoGroup
 *
 * Revision 2.5  2004/12/23 16:44:08  gf
 * - all error codes are now positive integers
 * - VRML/X3D loaders updated, now normals are interpreted if available
 * - matStack4f matrix stack class added
 * - Merry Christmas!
 *
 * Revision 2.4  2004/12/22 13:05:28  gf
 * initial transforms are now included into the vertex data
 *
 * Revision 2.3  2004/12/15 14:23:03  gf
 * Now geoObj make internally use of transformation matrices instead of
 * sixdofs. Some corresponding adaptations in various files.
 *
 * Revision 2.2  2004/12/07 13:44:29  gf
 * - mat4f is internally and externally conformant to OpenGL Matrices
 * - transformations of ElevationGrids should be handled correctly
 *
 * Revision 2.1  2004/12/06 11:19:17  gf
 * ongoing renovations of the file io framework
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 */
#endif  //_VE_GEOOBJ_H
