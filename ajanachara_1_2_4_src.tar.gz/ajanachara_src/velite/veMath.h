#ifndef _VE_MATH_H
#define _VE_MATH_H

/** @file veMath.h
 \brief mathematical classes and utility functions.

 This is the veMath auxilliary classes library.
 started 2000 as gf_math.h
 2002-02-01 generously granted to the veLib by Gerald.Franz\@tuebingen.mpg.de .

 The templates defined here are small inline functions mainly
 for convenient handling of degree angle values.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 @author  gf
 $Revision: 2.11 $
 */

#include "veStd.h"
#include<cmath>

namespace ve { // veLib standard namespace
//--- constants and enums ------------------------------------------ /*fold00*/
    /// defines PI
    const float PI=3.14159265358979323846f;
    /// defines PI/180, for angle conversions from deg to rad.
    const float PI_180=PI/180.0f;
    /// defines PI/180, for angle conversions from deg to rad.
    const float DEG2RAD=PI_180;
    /// defines 180/PI, for angle conversions from rad to deg.
    const float RAD2DEG=180.0f/PI;
    /// defines obvious names for vec2f, vec3f, vec4f, and vec6f ordinates.
    typedef enum { X=0, Y=1, Z=2, W=3, H=3, P=4, R=5 } axis;

    ///share the normal math.h definition
#ifndef M_PI
#  define M_PI PI
#endif
    /// defines C99 NaN constant if necessary
#ifndef NAN
#ifdef _MSC_VER
#define NAN log10f(0)
#else
#  define NAN 0.0f/0.0f
#endif
#endif

    /// defines C99 HUGE_VALF constant if necessary
#ifndef HUGE_VALF
#ifdef _MSC_VER
#include <float.h>
#define HUGE_VALF FLT_MAX
#else
#  define HUGE_VALF 1.0f/0.0f
#endif
#endif


/// just a small value
const double EPSILON = 0.00000001;


//--- templates and functions -------------------------------------- /*fold00*/
    /// generic sqrare function template
    template <class T> T sqr(T x) { return (x)*(x); };
    /// generic signum function template
    template <class T> int sgn(T x) { return x>0 ? 1 : (x<0 ? -1 : 0); };
    /// sinus function for degrees
    template <class T> double dsin(T x) { return sin((double(x))*PI_180); }
    /// cosinus function for degrees
    template <class T> double dcos(T x) { return cos((double(x))*PI_180); }
    /// tangens function for degrees
    template <class T> double dtan(T x) { return tan((double(x))*PI_180); }
    /// arcustangens function for degrees
    template <class T> double datan(T x) { return atan(double(x))/PI_180; }
    /// an "abs" and "mod" function for degree angles: restricts float values to 0 <= angle < 360.0
    template <class T> double angle(T angle) { return std::fmod(std::fmod((double)angle,360.0)+360.0,360.0); };
    /// returns the positive angular difference between ang2 and ang1 in degrees
    template <class T> double dAngle(T ang1, T ang2) { return angle(ang2-ang1); }
    /// swaps two values
    template <class T> void swap(T & t1, T & t2) { T tmp=t1; t1=t2; t2=tmp; };
    /**
     \brief simple signum function for floats

     Macro for extracting the sign of float or double values. It is as
     simple as the normal sign function for integers.
     */
#define fsign(fnum) ((fnum)<0.0?-1:1)
    /// returns maximum of 2 values
#ifndef max
#  define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
    /// returns minimum of 2 values
#ifndef min
#  define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif
    /// defines C99 isnan() for windows
#ifdef WIN32
#  define isnan(a) _isnan(a)
#endif
    
    /// returns minimum of 3 values
    template <class T> T min3(T value0, T value1, T value2) { return min(min(value0,value1),value2); };
    /// returns maximum of 3 values
    template <class T> T max3(T value0, T value1, T value2) { return max(max(value0,value1),value2); };

    class vec3f;  // forward declaration

    /// returns distance between P1(x1|y1|z1) and P2(x2|y2|z2)
    inline float dist(float x1, float y1,float z1, float x2,float y2,float z2) {
        return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2)); };
    /// returns distance between P1(x1|y1) and P2(x2|y2)
    inline float dist(float x1, float y1, float x2, float y2) {
        return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)); };
    /// returns minimum absolute value
    inline float minAbs(float f1, float f2) {
        return (fabs(f1)<fabs(f2) ? fabs(f1) : fabs(f2)); };
    /// returns minimum distance between P(x1|y1) and line segment((x2|y2)|(x3|y3))
    float distPointSeg(float x1, float y1, float x2, float y2,
                       float x3, float y3);
    /// returns angle between line p0|p1 and line p0|p2
    float angleXY(const ve::vec3f & p0, const ve::vec3f & p1, const ve::vec3f & p2);
    /// returns angle between point xy1 and point xy2
    float angleXY(float x1, float y1, float x2, float y2);
    /// returns angle between line xy1|xy2 and line xy1|xy3
    float angleXY(float x1, float y1, float x2, float y2, float x3, float y3);
    /// returns scalar product between vectors x1|y1 and x2|y2
    inline float scalarProduct(float x1, float y1, float x2, float y2) {
        return x1*x2 + y1*y2; };
    /// returns scalar product between vectors x1|y1|z1 and x2|y2|z2
    inline float scalarProduct(float x1, float y1, float z1, float x2, float y2, float z2) {
        return x1*x2 + y1*y2 + z1*z2; };

} // namespace ve

//--- class ve::vec2f ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class for 2d vector and vertex geometry operations.
/** The vec2f class is intentionally free of virtual methods and takes exactly
 8 bytes of memory. It is not meant as generic vector class (use vec3f instead),
 but only for efficient storing of 2D mass coordinate information. */
class vec2f {
public:
    /// default constructor
    vec2f(float x_=0, float y_=0) { coord[ve::X]=x_; coord[ve::Y]=y_; };
    /// copy constructor
    vec2f(const vec2f & v) { coord[ve::X]=v[ve::X]; coord[ve::Y]=v[ve::Y]; };
    /// constructor for vector between two given vertices
    vec2f(const vec2f & p1, const vec2f & p2) {
        coord[ve::X]=p2[ve::X]-p1[ve::X]; coord[ve::Y]=p2[ve::Y]-p1[ve::Y]; };

    /// copy operator
    const vec2f & operator=(const vec2f &source);
    /// sets vector ordinates to new values (x_|y_).
    void set(float x_, float y_) { coord[ve::X]=x_; coord[ve::Y]=y_; };
    /// sets vector ordinates to new values (x_[0]|x_[1]).
    void set(float * x_) { coord[ve::X]=x_[0]; coord[ve::Y]=x_[1]; };

    /// comparison operator equality
    bool operator==(const vec2f &vt) const;
    /// comparison operator inequality
    bool operator!=(const vec2f & vt) const { return !((*this)==vt); };
    /// returns reference to single ordinate
    float & operator[](unsigned int i) { return coord[i%2]; };
    /// returns single ordinate value
    float operator[](unsigned int i) const { return coord[i%2]; };
    /// returns coordinate array
    const float * coords() const { return coord; };

    /// translates object by dx,dy
    void translate(float dx, float dy) { coord[X]+=dx; coord[Y]+=dy; };
    /// translates object by vector v, optionally scaled by factor n
    void translate(const vec2f & v, float n=1.0f) { translate(v[ve::X]*n, v[ve::Y]*n); };
    /// += operator. Sums correspondend ordinates. Identical to translate(v).
    void operator+=(const vec2f & v) { coord[X]+=v[X]; coord[Y]+=v[Y]; };
    /// scales this vector by f.
    const vec2f & operator*=(float f) { coord[ve::X]*=f; coord[ve::Y]*=f; return *this; };
    /// devides this vector by f.
    const vec2f & operator/=(float f) { coord[ve::X]/=f; coord[ve::Y]/=f; return *this; };
    /// scales this vector to unit vector of length 1.0.
    const vec2f & normalize() { return *this*=(1.0f/length()); };

    /// returns the squared length.
    float sqrLength() const { return coord[ve::X]*coord[ve::X]+coord[ve::Y]*coord[ve::Y]; };
    /// returns absolute length.
    float length() const { return sqrt(sqrLength()); };
    
    /// vector addition operator
    inline const vec2f operator+(const vec2f & v) const {return vec2f(coord[X]+v[X], coord[Y]+v[Y]);};
    /// vector subtraction operator
    inline const vec2f operator-(const vec2f & v) const {return vec2f(coord[X]-v[X], coord[Y]-v[Y]);};
    /// operator multiplying a vector v with a scalar f
    inline const vec2f operator*(float f) const {return vec2f(coord[X]*f, coord[Y]*f);};

    /// operator for output of vec2f objects in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::vec2f & v);
protected:
    /// stores coordinate values.
    float coord[2];
};
} // namespace ve

/// operator for output of vec2f objects in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::vec2f & v);

//--- class ve::vec3f ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace
    // forward declarations:
    class mat4f;
    class vec6f;
    
/// a class for vector and 3D vertex geometry operations.
/** The vec3f class is intentionally free of virtual methods and takes exactly
 twelve bytes of memory. This allows for using a pointer to a vec3f array instead
 of using pointers to floats, e.g., for OpenGL vertex arrays. */
class vec3f {
public:
    /// default constructor
    vec3f(float x_=0, float y_=0, float z_=0) { coord[ve::X]=x_; coord[ve::Y]=y_; coord[ve::Z]=z_; };
    /// copy constructor
    vec3f(const vec3f & v) { coord[ve::X]=v[ve::X]; coord[ve::Y]=v[ve::Y]; coord[ve::Z]=v[ve::Z]; };
    /// constructor for vector between two given vertices
    vec3f(const vec3f & p1, const vec3f & p2) {
        coord[ve::X]=p2[ve::X]-p1[ve::X]; coord[ve::Y]=p2[ve::Y]-p1[ve::Y]; coord[ve::Z]=p2[ve::Z]-p1[ve::Z]; };
#ifndef _NO_STD_STRING
    /// constructor interpreting a string, values are separated by optionally definable separators
    vec3f(const std::string & s, const std::string & separator=", \t\n\015") { set(s,separator); };
    /// sets all ordinates by a string, values are separated by optionally definable separators.
    void set(const std::string & s, const std::string & separator=", \t\n\015");
    /// returns a string containing all data, optional arguments set separator between ordinates and number of digits per ordinate.
    std::string str(const std::string & separator=" ", unsigned char nDigits=8) const;
#endif
    /// copy operator
    const vec3f & operator=(const vec3f &source);
    /// sets vector ordinates to new values (x_|y_).
    void set(float x_, float y_) { coord[ve::X]=x_; coord[ve::Y]=y_; };
    /// sets vector ordinates to new values (x_|y_|z_).
    void set(float x_, float y_, float z_) {
        coord[ve::X]=x_; coord[ve::Y]=y_; coord[ve::Z]=z_; };
    /// sets vector ordinates to new values (x_[0]|x_[1]|x_[2]).
    void set(const float * x_) {
        coord[ve::X]=x_[0]; coord[ve::Y]=x_[1]; coord[ve::Z]=x_[2]; };
    /// sets vector to difference between two given vertices
    void set(const vec3f & p1, const vec3f & p2) {
        coord[ve::X]=p2[ve::X]-p1[ve::X]; coord[ve::Y]=p2[ve::Y]-p1[ve::Y]; coord[ve::Z]=p2[ve::Z]-p1[ve::Z]; };
    /// sets vec3f to the specified polar position
    void setPolar(float angleXYpl, float angleZ=0, float r=1.0) {
        set(static_cast<float>(ve::dcos(angleXYpl)) * static_cast<float>(ve::dcos(angleZ)) * r,
          static_cast<float>(ve::dsin(angleXYpl)) * static_cast<float>(ve::dcos(angleZ)) * r,
          static_cast<float>(ve::dsin(angleZ)) * r); };

    /// comparison operator equality
    bool operator==(const vec3f &vt) const;
    /// comparison operator inequality
    bool operator!=(const vec3f & vt) const { return !((*this)==vt); };
    /// returns reference to single ordinate
    float & operator[](unsigned int i) { return coord[i%3]; };
    /// returns single ordinate value
    float operator[](unsigned int i) const { return coord[i%3]; };
    /// returns coordinate array
    const float * coords() const { return coord; };

    /// translates object by dx,dy
    void translate(float dx, float dy) { coord[X]+=dx; coord[Y]+=dy; };
    /// translates object by dx,dy,dz
    void translate(float dx, float dy, float dz) {
        coord[X]+=dx; coord[Y]+=dy; coord[Z]+=dz; };
    /// translates object by vector v, optionally scaled by factor n
    void translate(const vec3f & v, float n=1.0f) { translate(v[ve::X]*n, v[ve::Y]*n, v[ve::Z]*n); };
    /// translates n points starting at ordinate *x by  dx,dy,dz.
    /** This is an optimized low level translation function for large numbers of coherent
     coordinate data. */
    static void translate(float * x, float dx, float dy, float dz, unsigned int n=1);
    /// += operator. Sums correspondent ordinates. Identical to translate(v).
    void operator+=(const vec3f & v) { coord[X]+=v[X]; coord[Y]+=v[Y]; coord[Z]+=v[Z]; };
    /// rotates object around arbitrary axis from origin to p by angle.
    void rotate(float angle, vec3f p);
    /// rotates vector according to heading, pitch, and roll.
    void rotate(float h, float p, float r);
    /// rotates point (x|y|z) by angle around axis (origin|(ax|ay|az)).
    /** Vertex (ax|ay|az) has to be normalized before applying this static method.
     Otherwise an uncontrolled scaling occurs.*/
    static void rotate(float & x, float & y, float & z, float angle, float ax, float ay, float az);
    /// rotates n vertices starting at ordinate *x  by angle around axis (origin|(ax|ay|az)).
    /** This is an optimized low level rotation function for large numbers of coherent
     coordinate data. Vertex (ax|ay|az) has to be normalized before applying this static
     method. Otherwise an uncontrolled scaling occurs.*/
    static void rotate(float * x, float angle, float ax, float ay, float az, unsigned int n=1);
    /// scales object by sx,sy and optionally sz
    void scale(float sx, float sy, float sz=1);
    /// scales this vector by f.
    const vec3f & operator*=(float f) { coord[ve::X]*=f; coord[ve::Y]*=f; coord[ve::Z]*=f; return *this; };
    /// divides this vector by f.
    const vec3f & operator/=(float f) { coord[ve::X]/=f; coord[ve::Y]/=f; coord[ve::Z]/=f; return *this; };
    /// vector addition operator
    inline const vec3f operator+(const vec3f &v) const {return vec3f(coord[X]+v[X],coord[Y]+v[Y],coord[Z]+v[Z]); };
    /// vector subtraction operator
    inline const vec3f operator-(const vec3f &v) const {return vec3f(coord[X]-v[X],coord[Y]-v[Y],coord[Z]-v[Z]); };
    /// operator multiplying a vector v with a scalar f
    inline const vec3f operator*(float f) const {return vec3f(coord[X]*f,coord[Y]*f,coord[Z]*f); };
    /// operator dividing a vector v by a scalar f
    inline const vec3f operator/(float f) const {return vec3f(coord[X]/f,coord[Y]/f,coord[Z]/f); };
    /// vector scalar product operator
    inline float operator* (const vec3f & v) const
    { return v.coord[ve::X]*coord[ve::X] + v.coord[ve::Y]*coord[ve::Y] + v.coord[ve::Z]*coord[ve::Z]; };
    /// scales this vector to unit vector of length 1.0.
    const vec3f & normalize() { return *this*=(1.0f/length()); };
    /// transforms this vector to an orthogonal projection of v2.
    void project(const vec3f & v2) { (*this)*=((*this) * v2)/sqrLength(); };
    /// transforms this vec3f by multiplying it with matrix m
    void transform(const ve::mat4f & m);
    /// transforms this vec3f by applying the provided sixdof transformation.
    /** The vector is rotated first according to r,p,h, afterwards translated
     by x,y,z. */
    void transform(const ve::vec6f & sdof);

    /// returns the squared length.
    float sqrLength() const { return coord[ve::X]*coord[ve::X]+coord[ve::Y]*coord[ve::Y]+coord[ve::Z]*coord[ve::Z]; };
    /// returns absolute length.
    float length() const { return sqrt(sqrLength()); };
    /// returns cross product vector with vec3f v2.
    vec3f crossProduct(const vec3f & v2) const;
    /// returns squared distance to coordinate x|y|(z).
    float sqrDistTo(float x, float y, float z=0.0f) const
    { return (coord[ve::X]-x)*(coord[ve::X]-x)+(coord[ve::Y]-y)*(coord[ve::Y]-y)+(coord[ve::Z]-z)*(coord[ve::Z]-z); };
    /// returns squared distance to vertex v.
    float sqrDistTo(const vec3f & v) const { return sqrDistTo(v[ve::X],v[ve::Y],v[ve::Z]); };
    /// returns distance to vertex v
    float distTo(const vec3f & v) const { return sqrt(sqrDistTo(v)); };
    /// returns distance to vertex coordinate x|y|(z).
    float distTo(float x, float y, float z=0.0f) const { return sqrt(sqrDistTo(x,y,z)); };
    /// returns angle in xy plane to vertex v
    float angleToXY(const vec3f & v) const { return angleXY(coord[ve::X],coord[ve::Y],v[ve::X],v[ve::Y]); };
    /// returns angle in xy plane to vertex x|y
    float angleToXY(float x, float y) const { return angleXY(coord[ve::X],coord[ve::Y],x,y); };
    //
    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::vec3f & v);
protected:
    /// stores coordinate values.
    float coord[3];
};
} // namespace ve

/// operator for output of vec3f objects in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::vec3f & v);


//--- class ve::vec4f ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace
/// a class for 4D vector geometry operations.
/** The vec4f class is intentionally free of virtual methods and takes exactly
 twelve bytes of memory. This allows for using a pointer to a vec4f array instead
 of using pointers to floats, e.g., for OpenGL vertex arrays.
 NOTE: This class has been added very recently (Revision 2.1) and is far from
 complete and not yet thoroughly tested! */
class vec4f {
public:
    /// default constructor
    vec4f(float x=0.0f, float y=0.0f, float z=0.0f, float w=1.0f) {
        coord[ve::X]=x; coord[ve::Y]=y; coord[ve::Z]=z; coord[ve::W]=w; };
    /// copy constructor
    vec4f(const vec4f & v) { coord[ve::X]=v[ve::X]; coord[ve::Y]=v[ve::Y];
                             coord[ve::Z]=v[ve::Z]; coord[ve::W]=v[ve::W]; };
    /// constructor from a float pointer
    vec4f(const float * f) { coord[ve::X]=f[ve::X]; coord[ve::Y]=f[ve::Y];
        	             coord[ve::Z]=f[ve::Z]; coord[ve::W]=f[ve::W]; };
#ifndef _NO_STD_STRING
    /// constructor interpreting a string, values are separated by optionally definable separators
    vec4f(const std::string & s, const std::string & separator=", \t\n\015") {
        set(s,separator); };
    /// sets all ordinates by a string, values are separated by optionally definable separators.
    void set(const std::string & s, const std::string & separator=", \t\n\015");
    /// returns a string containing all data, optional arguments set separator between ordinates and number of digits per ordinate.
    std::string str(const std::string & separator=" ", unsigned char nDigits=8) const;
#endif
    /// copy operator
    const vec4f & operator=(const vec4f &source);
    /// sets vector ordinates to new values (x|y|z|w).
    void set(float x, float y, float z, float w) {
        coord[ve::X]=x; coord[ve::Y]=y; coord[ve::Z]=z; coord[ve::W]=w; };

    /// comparison operator equality
    bool operator==(const vec4f &vt) const;
    /// comparison operator inequality
    bool operator!=(const vec4f & vt) const { return !((*this)==vt); };
    /// returns reference to single ordinate
    float & operator[](unsigned int i) { return coord[i%4]; };
    /// returns single ordinate value
    float operator[](unsigned int i) const { return coord[i%4]; };
    /// returns coordinate array
    const float * coords() const { return coord; };

    /// translates object by dx,dy,dz,dw
    void translate(float dx, float dy, float dz, float dw) {
        coord[X]+=dx; coord[Y]+=dy; coord[Z]+=dz; coord[W]+=dw; };
    /// translates object by vector v, optionally scaled by factor n
    void translate(const vec4f & v, float n=1.0f) {
        translate(v[ve::X]*n, v[ve::Y]*n, v[ve::Z]*n, v[ve::W]*n); };
    /// += operator. Sums correspondent ordinates. Identical to translate(v).
    void operator+=(const vec4f & v) {
        coord[X]+=v[X]; coord[Y]+=v[Y]; coord[Z]+=v[Z]; coord[W]+=v[W]; };
    /// scales object by sx,sy,sz,sw
    void scale(float sx, float sy, float sz, float sw) {
        coord[X]*=sx; coord[Y]*=sy; coord[Z]*=sz; coord[W]*=sw; };
    /// scales this vector by f.
    const vec4f & operator*=(float f) { coord[ve::X]*=f; coord[ve::Y]*=f;
        coord[ve::Z]*=f; coord[ve::W]*=f; return *this; };
    /// divides this vector by f.
    const vec4f & operator/=(float f) { coord[ve::X]/=f; coord[ve::Y]/=f;
        coord[ve::Z]/=f; coord[ve::W]/=f; return *this; };
    /// scales this vector to unit vector of length 1.0.
    const vec4f & normalize() { return *this*=(1.0f/length()); };
    /// transforms this vec3f by multiplying it with matrix m
    void transform(const ve::mat4f & m);
    /// returns the squared length.
    float sqrLength() const { return coord[ve::X]*coord[ve::X] + coord[ve::Y]*coord[ve::Y] + coord[ve::Z]*coord[ve::Z] + coord[ve::W]*coord[ve::W]; };
    /// returns absolute length.
    float length() const { return sqrt(sqrLength()); };
    /// computes scalar product between this vector and vec3f v.
    float scalarProduct(const vec4f & v) const {
        return v.coord[ve::X]*coord[ve::X] + v.coord[ve::Y]*coord[ve::Y] + v.coord[ve::Z]*coord[ve::Z] + v.coord[ve::W]*coord[ve::W]; };

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::vec4f & v);
protected:
    /// stores coordinate values.
    float coord[4];
};

} // namespace ve

/// operator for output of vec4f objects in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::vec4f & v);
/// operator multiplying a vec4f v with a scalar f
inline const ve::vec4f operator*(const ve::vec4f & v, float f) {
    return ve::vec4f(v[ve::X]*f,v[ve::Y]*f,v[ve::Z]*f,v[ve::W]*f); };


//--- class ve::sphere --------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class representing a sphere.
class sphere : public ve::vec3f {
public:
    /// default constructor
    sphere(float x=0, float y=0, float z=0, float rd=0) : vec3f(x,y,z) { r=rd; };
    /// constructor from a vec
    sphere(const vec3f & center, float rd=0) : vec3f(center) { r=rd; };
    /// copy constructor
    sphere(const sphere & source) : vec3f(source) { r=source.r; };
    /// returns radius
    float radius() const { return r; };
    /// sets radius
    void radius(float newRadius) { r=newRadius; };
    
    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::sphere & sph);
protected:
    /// stores radius
    float r;
};
} // namespace ve

/// operator for output of spheres in streams
std::ostream & operator<<(std::ostream & os, const ve::sphere & sph);

//--- class ve::plane ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace
    class triangle;
    
/// a class representing a plane.
class plane {
public:
    /// default constructor from a normal vector v and optional d component.
    plane(const vec3f & v=vec3f(0,0,1), float d_=0);
    /// constructor from a normal vector v and a point p.
    plane(const vec3f & v, const vec3f & p);
    /// constructor from three points
    plane(const vec3f & p0, const vec3f & p1, const vec3f & p2);
    /// constructor from triangle
    plane(const ve::triangle & tr);
    /// copy constructor
    plane(const plane & source);
    /// copy operator
    const plane & operator=(const plane & source);
    /// returns signed distance to point p
    float signedDistTo(const vec3f & p) const { return (n*p)+d; };
    /// returns absolute distance to point p
    float distTo(const vec3f & p) const { return fabs(signedDistTo(p)); };
    /// returns normal vector
    vec3f & normalVector() { return n; };
    /// returns normal vector, const
    const vec3f & normalVector() const { return n; };
    /// returns offset component d, const
    float D() const { return d; };
    /// returns offset component d
    float & D() { return d; };
    /// translates object by x|y|z.
    void translate(float x, float y, float z=0.0f) { translate(vec3f(x,y,z)); };
    /// translates object by vector v.
    void translate(const vec3f & v);
    /// rotates object around arbitrary axis from origin to p by angle.
    void rotate(float angle, vec3f p) { n.rotate(angle,p); };
    /// rotates object according to heading, pitch, and roll.
    void rotate(float h, float p, float r)  { n.rotate(h,p,r); };
    /// transforms this plane by applying the provided sixdof transformation.
    /** The plane is rotated first according to r,p,h, afterwards translated
     by x,y,z. */
    void transform(const ve::vec6f & sdof);

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::plane & pl);
protected:
    /// stores normal vector
    vec3f n;
    /// stores offset component d of plane equation.
    float d;
};

} // namespace ve

/// operator for output of planes in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::plane & pl);

//--- class ve::triangle ------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class for triangle geometry.
class triangle {
public:
    /// 2d constructor
    triangle(float x1,float y1, float x2,float y2, float x3,float y3) { set(x1,y1,0, x2,y2,0, x3,y3,0); };
    /// 3d constructor
    triangle(float x1,float y1,float z1, float x2,float y2,float z2,  float x3,float y3,float z3) {
        set(x1,y1,z1, x2,y2,z2, x3,y3,z3); };
    /// constructor taking vec3f references
    triangle(const vec3f & p0, const vec3f & p1, const vec3f & p2) { set(p0, p1, p2); };
    /// low level constructor taking binary data of 9 float values, no range checks, beware of segfaults!
    triangle(const float * pCoords);
    /// copy constructor
    triangle(const triangle & source);
    /// sets triangle to new 2D vec3f values
    void set(float x1,float y1, float x2,float y2, float x3,float y3) {
        set(x1,y1,0, x2,y2,0, x3,y3,0); };
    /// sets triangle to new 3D vec3f values
    void set(float x1,float y1,float z1, float x2,float y2,float z2,  float x3,float y3,float z3);
    /// sets triangle to new vec3f values
    void set(const ve::vec3f & v0, const ve::vec3f & v1, const ve::vec3f & v2){
        pt[0]=v0; pt[1]=v1; pt[2]=v2; };
    /// translates object by dx,dy,dz
    void translate(float dx, float dy, float dz=0) {
        vec3f::translate(&pt[0][X],dx,dy,dz,3); };
    /// translates object by vector v, optionally scaled by factor n
    void translate(const vec3f & v, float n=1.0f) { translate(v[ve::X]*n,v[ve::Y]*n,v[ve::Z]*n); };
    /// rotates object around arbitrary axis from origin to p by angle.
    void rotate(float angle, float x, float y, float z) {
        vec3f::rotate(&pt[0][X],angle,x,y,z,3); };
    /// scales object by sx,sy and optionally sz
    void scale(float sx, float sy, float sz=1);
    /// transforms this triangle by multiplying it with matrix m
    void transform(const ve::mat4f & m);
    /// transforms this triangle by applying the provided sixdof transformation.
    /** The vector is rotated first according to r,p,h, afterwards translated
     by x,y,z. */
    void transform(const ve::vec6f & sdof);
    /// returns control point n
    vec3f & operator[](unsigned int n) { return pt[n%3]; };
    /// returns control point n, const
    const vec3f & operator[](unsigned int n) const { return pt[n%3]; };
    /// fills coords with coordinate values of all 3 control points, no memory allocation.
    void getCoords(double * coords) const;
    /// tests v for being in the same xy area than the triangle
    bool isElemXY(const vec3f & p) const;
    /// returns the z distance from v to the triangle plane, positive if v is above, otherwise negative
    float distZ(const vec3f & p) const;
    /// returns normal vector of the triangle plane
    vec3f normalVector() const;
    /// returns area of triangle.
    double area() const;
    /// tests whether triangle intersects defined range between minValue and maxValue with respect to axis.
    bool inRange(int axis, double minValue, double maxValue) const;
    /// returns plane equation factors A,B,C,D.
    void getABCD(float &a, float &b, float &c, float &d) const;

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::triangle & t);
protected:
    /// vertices
    vec3f pt[3];
};

} // namespace ve

/// operator for output of trinagles in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::triangle & t);

//--- class ve::line ----------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class for line mathematics.
/** Depending on the method, the line is treated as a
 -# line segment (limited by the 2 control vertices): distTo, length, squaredLength, intersect2d, intersects(isRay=false)
 -# ray with pt[0] as origin and pt[0]pt[1] as direction: intersects(isRay=true)
 -# infinite line.
 */
class line {
public:
    /// default constructor
    line();
    /// explicit 3d constructor
    line(float x1_, float y1_, float z1_, float x2_, float y2_, float z2_);
    /// explicit 2d constructor
    line(float x1_, float y1_, float x2_, float y2_);
    ///constructor taking vertices as argument
    line(const vec3f & p1, const vec3f & p2);
    /// copy constructor
    line(const line& source);
    /// destructor
    ~line();
    /// copy operator
    const line & operator=(const line& source);

    /// sets the coordinates of the two control vertices
    void set(float x1_, float y1_, float z1_, float x2_, float y2_, float z2_);
    /// sets the two control vertices to p1 & p2
    void set(const vec3f & p1, const vec3f & p2);
    /// returns the current control vec3f values in p1 and p2
    void get(vec3f & p1, vec3f & p2) const;
    /// translates object by dx,dy,dz
    void translate(float dx, float dy, float dz=0);
    /// translates object by vector v, optionally scaled by factor n
    void translate(const vec3f & v, float n=1.0f) { translate(v[ve::X]*n,v[ve::Y]*n,v[ve::Z]*n); };
    /// rotates object around arbitrary axis from origin to p by angle.
    void rotate(float angle, float x, float y, float z) {
        vec3f::rotate(&pt[0][X],angle,x,y,z,2); };
    /// scales object by sx,sy and optionally sz
    void scale(float sx, float sy, float sz=1);
    /// transforms this line by multiplying it with matrix m
    void transform(const ve::mat4f & m);
    /// transforms this line by applying the provided sixdof transformation.
    /** The vector is rotated first according to r,p,h, afterwards translated
     by x,y,z. */
    void transform(const ve::vec6f & sdof);
    /// returns control vec3f n
    vec3f & operator[](unsigned int n) { return pt[n%2]; };
    /// returns control vec3f n, const
    const vec3f & operator[](unsigned int n) const { return pt[n%2]; };
    /// returns distance to vertex p
    float distTo(const vec3f & p) const;
    /// returns length
    float length() const { return sqrt( (pt[0][ve::X]-pt[1][ve::X])*(pt[0][ve::X]-pt[1][ve::X]) + (pt[0][ve::Y]-pt[1][ve::Y])*(pt[0][ve::Y]-pt[1][ve::Y])+(pt[0][ve::Z]-pt[1][ve::Z])*(pt[0][ve::Z]-pt[1][ve::Z])); };
    /// returns the squared length.
    /** This method is provided mainly for efficiency reasons for avoiding square root computations. */
    float sqrLength() const { return (pt[0][ve::X]-pt[1][ve::X])*(pt[0][ve::X]-pt[1][ve::X]) + (pt[0][ve::Y]-pt[1][ve::Y])*(pt[0][ve::Y]-pt[1][ve::Y])+(pt[0][ve::Z]-pt[1][ve::Z])*(pt[0][ve::Z]-pt[1][ve::Z]); };
    /// tests for intersection, projected in xy plane.
    /** WARNING: never tested since part of veMath! */
    bool intersect2d(line &l) const;
    /// tests for intersection with triangle tr.
    /**
     \param tr is a reference to the triangle that is tested
     \param isRay (optional) defines whether the line is
     treated as as infinite ray starting from pt[0].
     \return NULL or intersection point. The memory of this vec
     has to be deallocated by the user! */
    vec3f * intersects(const triangle & tr, bool isRay=true ) const;
    /// tests for intersection with sphere sph.
    /**
     \param sph is a reference to the sphere that is tested
     \param isRay (optional) defines whether the line is
     treated as as infinite ray starting from pt[0].
     \return NULL or intersection point. The memory of this vec
     has to be deallocated by the user! */
    vec3f * intersects(const sphere & sph, bool isRay=true ) const;
    /// returns intersection point between a line (segment) and a triangle array.
    /**
     \param vTr is a reference to the triangle array that is tested
     \param isRay (optional) defines whether the line is
     treated as as infinite ray starting from pt[0].
     \return NULL or intersection point. The memory of this vec
     has to be deallocated by the user! */
    vec3f * intersects(const std::vector<ve::triangle> & vTr, bool isRay=true ) const;

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::line & l);
protected:
    /// pointer to vertices
    vec3f * pt;
};
} // namespace ve

/// operator for output of lines in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::line & l);


//--- class ve::vec6f ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class representing a six degree of freedom coordinate.
/** Note that unfortunately there is no generally accepted standard for
 sixdofs rotations. Since the veLib normally defines forward along the +Y
 axis and upward along +Z axis, roll means a rotation around the Y axis, pitch
 around the X axis, and heading (i.e. yaw) around the Z axis. Euler rotations
 shall be preformed in exactly this order. */
class vec6f : public vec3f {
public:
    /// default constructor
    vec6f(float x=0, float y=0, float z=0, float h=0, float p=0, float r=0);
    /// copy constructor
    vec6f(const vec6f & source);
    /// constructor from a vec3f
    vec6f(const vec3f & source);
    /// constructor from a transformation matrix
    vec6f(const ve::mat4f & m) : vec3f() { set(m); };
#ifndef _NO_STD_STRING
    /// constructor interpreting a string, values are separated by optionally definable separators
    vec6f(const std::string & s, const std::string & separator=", \t\n\015") { set(s,separator); };
    /// sets all ordinates by a string, values are separated by optionally definable separators.
    void set(const std::string & s, const std::string & separator=", \t\n\015");
    /// returns a string containing all data, optional arguments set separator between ordinates and number of digits per ordinate.
    std::string str(const std::string & separator=" ", unsigned char nDigits=8) const;
#endif
    /// copy operator
    vec6f & operator=(const vec6f & source);
    /// += operator. Sums correspondend ordinates.
    void operator+=(const vec6f & summand);
    /// comparison operator equality
    bool operator==(const vec6f & sd) const;
    /// comparison operator inequality
    bool operator!=(const vec6f & sd) const { return !((*this)==sd); };
    /// transforms this sixdof by multiplying it with matrix m
    /** Note that this operation is computationally expensive, since
     this vec6f has to be transformed into a matrix first, then the
     matrices are multiplied, and then the result is retransformed.*/
    void transform(const ve::mat4f & m);
    /// translates the vec6f in the direction of v (basically the same as in class vec3f). It also rotates with respective scaling factor.
    void translate(const vec6f & v, float linearscale=1.0f, float angularscale=1.0f);
    /// sets all ordinates
    void set(float x=0, float y=0, float z=0, float h=0, float p=0, float r=0);
    /// sets sixdof as far as possible to an equivalent transformation as in matrix m
    void set(const ve::mat4f & m);
    /// copies values into a float pointer
    void get(float * f) const;
    /// returns single ordinate reference
    float & operator[](unsigned int i);
    /// returns single ordinate value, const
    float operator[](unsigned int i) const;
    /// product operator. All ordinates of the return value are scaled by f.
    vec6f& operator*(float f) const;
    /// addition operator vec6f+vec6f
    inline const vec6f operator+(const vec6f & v) const {
        return vec6f(coord[X]+v[X],coord[Y]+v[Y],coord[Z]+v[Z],
                     coord[H]+v[H],coord[P]+v[P],coord[R]+v[R]); };
    /// addition operator vec6f+vec3f
    inline const vec6f operator+(const vec3f & v) const {
        return vec6f(coord[X]+v[X],coord[Y]+v[Y],coord[Z]+v[Z],
                         coord[H],coord[P],coord[R]); };
    /// subtraction operator
    inline const vec6f operator-(const vec6f & v) const {
        return vec6f(coord[X]-v[X],coord[Y]-v[Y],coord[Z]-v[Z],
                         coord[H]-v[H],coord[P]-v[P],coord[R]-v[R]); };

    /// sets all ordinates to 0.0
    void reset() { coord[ve::X]=coord[ve::Y]=coord[ve::Z]=ang[0]=ang[1]=ang[2]=0.0f; };
    /// returns vec6f size (number of ordinates), mainly for "for" statements
    static unsigned int size() { return 6; };
    /** \brief applies a remapping and an optional scaling
     The axes are first remapped, scaling, shifting and appliance of deadzone occures afterwards.
     \param mapping must provide an array of 6 values from 0..5 in the desired order.
     \param scale (optional) holds the linear scaling values.
     \param shift (optional) holds values that are added to the final result.
     \param deadzone (optional) holds range in which axes will be reported as zero.*/
    void remap(const unsigned int * mapping,
               const ve::vec6f & scale=ve::vec6f(1.0f,1.0f,1.0f,1.0f,1.0f,1.0f),
               const ve::vec6f & shift=ve::vec6f(0.0f,0.0f,0.0f,0.0f,0.0f,0.0f),
               const ve::vec6f & deadzone=ve::vec6f(0.0f,0.0f,0.0f,0.0f,0.0f,0.0f));

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const vec6f & sdof);
protected:
    /// stores angle ordinates
    float ang[3];
};
} // namespace ve
//
/// operator for output of sixdofs in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::vec6f & sdof);
//
/// addition operator vec3f+vec6f
inline const ve::vec6f operator+(const ve::vec3f &v1, const ve::vec6f &v2) {
        return ve::vec6f(v1[ve::X]+v2[ve::X],v1[ve::Y]+v2[ve::Y],v1[ve::Z]+v2[ve::Z],
            v2[ve::H],v2[ve::P],v2[ve::R]); };

//--- class ve::frustum -------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// class for frustum (clipping) operations.
class frustum {
public:
    /// default constructor
    frustum();
    /// constructor
    frustum(float clipLeft,float clipRight,float clipBottom,
            float clipTop,float clipNear,float clipFar);
    /// copy constructor
    frustum(const frustum & source);
    /// copy operator
    const frustum & operator=(const frustum & source);
    /// sets frustum geometry
    void set(float clipLeft,float clipRight,float clipBottom,
            float clipTop,float clipNear,float clipFar);
    /// tests whether sphere sph at least partially intersects this frustum.
    bool intersects(const sphere & sph) const;
    /// tests whether an axis-aligned box, defined by its min and max coordinates, at least partially intersects this frustum.
    bool intersects(const ve::vec3f & vecMin, const ve::vec3f & vecMax ) const;
    /// translates object by x|y|z.
    void translate(float x, float y, float z=0.0f) { translate(vec3f(x,y,z)); };
    /// translates object by vector v.
    void translate(const vec3f & v);
    /// rotates object around arbitrary axis from origin to p by angle.
    void rotate(float angle, const vec3f & p);
    /// rotates object according to heading, pitch, and roll.
    void rotate(float h, float p, float r);
    /// transforms this frustum by applying the provided sixdof transformation.
    /** The vector is rotated first according to r,p,h, afterwards translated
     by x,y,z. */
    void transform(const ve::vec6f & sdof);
    /// allows access to plane i
    ve::plane & plane(unsigned int i) { return pl[i%6]; };
    /// allows reading of plane i
    const ve::plane & plane(unsigned int i) const { return pl[i%6]; };

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::frustum & fr);
protected:
    /// stores clipping planes
    ve::plane pl[6];
};

} // namespace ve

/// operator for output of frustums in streams
std::ostream & ve::operator<<(std::ostream & os, const ve::frustum & fr);

//--- class ve::rnd ------------------------------------------------ /*fold00*/
namespace ve { // veLib standard namespace

/// an extension of c random number functions.
class rnd {
public:
    /// default constructor.
    rnd(unsigned int seed=0);
    /// returns a random integer value.
    int get();
    /// returns an int number between 0 < max.
    int get(int max);
    /// returns a float number between 0.0 and 1.0.
    float getf();
    /// returns a float number between 0.0 and f.
    float getf(float f) { return getf()*f; };
    /// randomizes an unsigned int vector, optionally fills in n Elements 0..n-1.
    static void permutate(std::vector<unsigned int> & vec, unsigned int n=0);
    /// randomizes a string vector.
    static void permutate(std::vector<std::string> & vec);
    /// randomizes a float vector.
    static void permutate(std::vector<float> & vec);
    /// fills vec3f with n equal-distributed pseudo random numbers.
    /** This random algorithm provides equally-distributed random numbers
     for small quantitities by dividing the range between loBound and hiBound
     in even intervals and using each interval equally often for generating random numbers.*/
    static void rndEqual(std::vector<float> & vec, unsigned int n,
                         float loBound, float hiBound, unsigned int intervals);
protected:
    /// stores a seed for the case no seed is provided by the constructor call.
    /** The default seed will be generated from system time or
     from previously instanciated ve::rnd object constructors. */
    static unsigned int defaultSeed;
};

#ifdef _MSC_VER
/// provide a random number
double drand48();
#endif

/// provide a random int number between 0 and max-1
#define veRandi(max) (veRound(floor(drand48()*((double)(max)))))

/// provide a random float number between 0 and max
#define veRandf(max) (drand48()*(max))
} // namespace ve


//--- class ve::mat4f ---------------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class for typical 3D geometry 4x4 matrix operations.
/** The matrix class is intentionally free of virtual methods and takes exactly
 64 bytes memory. This allows for using a pointer to a matrix identically
 to using float pointers, e.g., for OpenGL. Therefore also the order of tranformations
 (e.g., rotations, scale) correspond exactly to OpenGL's factor order.\n
 Also the order of its members is equivalent to OpenGL:\n
 \verbatim
 mat4f M = [ m0  m4 m8  m12
             m1  m5 m9  m13
             m2  m6 m10 m14
             m3  m7 m11 m15 ]
 \endverbatim
 Note that this order has changed between veLib v1.0 and veLib 1.1.1!
 The normal user should not be affected, as long as matrices have not been used
 directly. However, the switch of the order could also be the origin of subtle
 bugs. In order to make the user explicitly aware of this change, the class has
 been renamed from matrix4f to mat4f (which also is equivalent to GLSL).
 */
class mat4f {
public:
    /// default constructor, creating identity matrix
    mat4f() { identity(); };
    /// constructor from sixdof
    mat4f(const ve::vec6f & sdof) { set(sdof); };
    /// copy constructor, bitwise copy.
    mat4f(const ve::mat4f & source);
    /// copy operator, bitwise copy.
    const ve::mat4f & operator=(const ve::mat4f & source);
    /// returns reference of single ordinate
    float & operator[](unsigned int i) { return m[i%16]; };
    /// returns single ordinate value
    float operator[](unsigned int i) const { return m[i%16]; };
    /// returns column vector i
    const ve::vec4f col(unsigned int i) const {
        return ve::vec4f(&m[4*(i%4)]); };
    /// returns row vector i
    const ve::vec4f row(unsigned int i) const {
        return ve::vec4f(m[i%4], m[4+(i%4)], m[8+(i%4)], m[12+(i%4)]); };

    /// transforms this matrix to an identity matrix
    void identity();
    /// returns true if this matrix is an identity matrix
    bool isIdentity() const;
    /// makes this matrix to a NaN matrix
    /** The NaN matrix is used to indicate that no mathematical solution could
     be found in an operation. To test for NaN, use the mat4f::isNan() method. */
    void nan() { m[0]=NAN; };
    /// returns true if this matrix is a NaN matrix
    bool isNan() const { if(isnan(m[0])) return true; else return false; };

    /// transposes this matrix
    void transpose();
    /// transforms this matrix into its inverse if possible, otherwise into a NaN matrix
    void inverse();
    /// sets this matrix to the 16 provided values
    /** the values are assumed to be in the OpenGL order. */
    void set(float m0, float m1, float m2, float m3,
             float m4, float m5, float m6, float m7,
             float m8, float m9, float m10,float m11,
             float m12,float m13,float m14,float m15);
    /// sets this matrix to the values provided in a float array
    /** the values are assumed to be in the OpenGL order. */
    void set(float *f);
    /// sets this matrix to transformation stored in a sixdof
    void set(const ve::vec6f & sdof);
    /// flips this matrix from the vrml/x3d coordinate system to the veLib coordinate system
    void vrml2ve();
    /// flips this matrix from the veLib coordinate system to the vrml/x3d coordinate system
    void ve2vrml();

    /// operator multiplying two matrixes in the order (*this) * m
    const mat4f operator*(const mat4f & m) const;
    /// multiplies this matrix by m2, (*this) = (*this) * m2
    void operator*=(const ve::mat4f & m2) { (*this)= (*this)*m2; };
    /// adds the translation x|y|z to the transformation
    void translate(float x, float y, float z=0) { translate(ve::vec3f(x,y,z)); };
    /// adds the translation v to the transformation
    void translate(const ve::vec3f & v);
    /// multiplies matrix with a rotation matrix around arbitrary axis from origin to p by angle, (*this) = (*this) * mRot
    void rotate(float angle, vec3f p);
    /// multiplies matrix with a rotation matrix around arbitrary axis from origin to (x|y|z) by angle, (*this) = (*this) * mRot
    void rotate(float angle, float ax, float ay, float az) { rotate(angle,ve::vec3f(ax,ay,az)); };
    /// multiplies matrix with a scale matrix, (*this) = (*this) * mScale
    void scale(float sx, float sy, float sz);

    /// transforms a vector of ve::vec3f by applying this matrix
    void transform(std::vector<ve::vec3f> & vV) const;
    /// transforms a vector of float coordinates n*(x|y|z) by applying this matrix
    void transform(std::vector<float> & vF) const;
    /// transforms an array of coherent float coordinates n*(x|y|z) starting at pF by applying this matrix
    void transform(float * pF, unsigned int n) const;
#ifndef _NO_STD_STRING
    /// returns a string containing all data, optional arguments set separator between ordinates and number of digits per ordinate.
    std::string str() const;
#endif
    /// operator for output in streams
    friend inline std::ostream & operator<<(std::ostream & os, const ve::mat4f & m);

protected:
    /// stores values.
    float m[16];
};
} // namespace ve

    /// operator for output in streams
inline std::ostream & ve::operator<<(std::ostream & os, const ve::mat4f & m) {
    return os << m.str(); };

//--- class ve::matStack4f ----------------------------------------- /*fold00*/

namespace ve { // veLib standard namespace

/// a class for typical 3D geometry 4x4 matrix stack operations such as in OpenGL.
class matStack4f : public ve::mat4f {
public:
    /// default constructor, creating empty stack and identity matrix
    matStack4f() : mat4f() { ; };
    /// constructor from sixdof
    matStack4f(const ve::vec6f & sdof) : mat4f(sdof) { ; };
    /// constructor from normal matrix
    matStack4f(const ve::mat4f & source) : mat4f(source) { ; };
    /// copy constructor from matrix stack
    matStack4f(const ve::matStack4f & source) : mat4f(source) {
        m_stack=source.m_stack; };
    /// pushes current matrix onto the stack
    void push() { m_stack.push_back(ve::mat4f(*this)); };
    /// pops current matrix and replaces it by last stored matrix
    void pop() {
        if(m_stack.size()>0) { set(&m_stack[m_stack.size()-1][0]); m_stack.pop_back(); } };
protected:
    /// stores pushed matrices
    std::vector<ve::mat4f> m_stack;
};
} // namespace ve


//--- cvs history log : -------------------------------------------- /*FOLD00*/
/*
 * $Log: veMath.h,v $
 * Revision 2.11  2004/12/23 16:44:08  gf
 * - all error codes are now positive integers
 * - VRML/X3D loaders updated, now normals are interpreted if available
 * - matStack4f matrix stack class added
 * - Merry Christmas!
 *
 * Revision 2.10  2004/12/20 09:47:30  weyel
 * resolved a compiler msvc compiler warning
 *
 * Revision 2.9  2004/12/15 14:20:10  gf
 * bug in mat4f::translate() fixed
 *
 * Revision 2.8  2004/12/14 17:54:06  gf
 * mat4f::inverse() method added
 *
 * Revision 2.7  2004/12/11 16:40:14  franck
 * Added missing const qualifiers
 *
 * Revision 2.6  2004/12/11 11:09:36  franck
 * General cleaning:
 * - removed scalarProduct function in vec3f class (use operator* instead)
 * - moved some operators inside the classes so they show up in the documentation
 * - made more functions inline in the vec2f class
 *
 * Revision 2.5  2004/12/08 14:14:15  weyel
 * -ongoing bugfixing in network device
 * -added deadzone to input axes mapping
 *
 * Revision 2.4  2004/12/07 13:44:29  gf
 * - mat4f is internally and externally conformant to OpenGL Matrices
 * - transformations of ElevationGrids should be handled correctly
 *
 * Revision 2.3  2004/12/06 18:16:37  franck
 * Re-added the friend declarations with the apparently correct syntax.
 *
 * Revision 2.1  2004/12/06 11:14:23  gf
 * - matrix <-> vec6f conversion methods added
 * - class vec4f added
 * - matrix4f renamed to mat4f in order to resemble GLSL
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.75  2004/10/25 15:09:56  weyel
 * added NAN defines for MSVC
 *
 * Revision 1.74  2004/10/24 18:52:45  gf
 * collision detection can now handle more than one object
 *
 * Revision 1.73  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.72  2004/10/14 14:56:56  gf
 * - nasty little bug in veGlUtils, ovl::dropObj() fixed
 * - some doxygen warnings removed
 *
 * Revision 1.71  2004/10/04 09:38:43  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.70  2004/09/14 15:59:54  gf
 * vec6f + vec3f and vice versa operators added, deviceNetworkUDP removed from Makefile
 *
 * Revision 1.69  2004/09/14 15:32:01  gf
 * vec6f + and - operators added, small interface change in ovlObj
 *
 * Revision 1.68  2004/08/17 15:24:39  gf
 * matrix4f::scale() and ::rotate() methods added
 *
 * Revision 1.66  2004/08/09 09:34:37  gf
 * - adaptations due to ongoing cleanup/improvement of graphics device:
 * - transform() methods for planes and frustums added
 * - (animated) billboards work again, therefore some minor changes geoObj()
 *
 * Revision 1.65  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.64  2004/07/01 15:29:09  gf
 * - vec6f::get() method added
 * - some strange compatibility issues for VC6 done, that's maybe morally wrong
 *
 * Revision 1.63  2004/05/24 20:37:01  gf
 * many functions now inline
 *
 * Revision 1.62  2004/04/27 10:33:25  gf
 * frustum::intersects(cube) method added
 *
 * Revision 1.61  2004/04/05 11:14:36  gf
 * - loading of bmp files added (via libSDL), mime type added
 * - vec2f class added
 *
 * Revision 1.60  2004/03/08 09:54:43  gf
 * some vbasic functions now inline, triangle::isElement method hopefully improved
 *
 * Revision 1.59  2004/02/25 17:37:44  gf
 * isnan() macro for windows added
 *
 * Revision 1.58  2004/02/24 13:33:33  gf
 * - ve::vec (veMath.h) renamed to ve::vec3f
 * - VEEC_XYZ (veTypes.h) error codes renamed to ve::ERR_XYZ
 *
 * Revision 1.57  2004/02/18 14:14:31  gf
 * first version of a matrix class added
 *
 * Revision 1.56  2004/02/09 11:46:06  gf
 * - all enums in veTypes.h now consequently in capital letters
 * - dataContainer has now an additional constructor
 *
 * Revision 1.55  2004/01/29 18:25:03  gf
 * - axesInputShift factor added
 * - vrml parser now ignores file:// in URLs
 *
 * Revision 1.54  2004/01/26 09:10:44  gf
 * - simple remapping mechanism implemented
 * - dynamic scenegraph objects have now a local coordinate system for speed
 *
 * Revision 1.53  2004/01/19 10:21:57  gf
 * - namespace ve now consequently used in more classes
 * - veImg.h/.cpp renamed to veImage.h/.cpp
 *
 * Revision 1.52  2004/01/08 16:04:16  gf
 * ve::vec3f additional methods added
 *
 * Revision 1.51  2003/12/12 16:39:22  gf
 * just small changes, leading to hours of unproductive work: definitions
 * ubited in veTypes.h some #defines moved to const unsigned int
 *
 * Revision 1.50  2003/11/24 17:34:28  gf
 * veMath: include <cmath> added; veIO: small bug reading zip directories corrected;
 * veStd.h: some constants for ALT, CTRL, SHIFT added (gf)
 *
 * Revision 1.49  2003/11/17 15:44:40  gf
 * random functions moved to veRnd (in veMath.h)
 *
 * Revision 1.48  2003/10/28 14:55:42  gf
 * deprecated methods removed
 *
 * Revision 1.47  2003/10/27 13:55:03  weyel
 * vec6f now has dump()-function
 *
 * Revision 1.46  2003/09/23 16:33:57  gf
 * comparison operators for vec6f and vec3f added
 *
 * Revision 1.45  2003/08/20 09:28:22  gf
 * vec3f operator+= added
 *
 * Revision 1.44  2003/07/25 10:55:08  gf
 * lots of changes:
 * - base class veMath removed, optimizes memory usage, computation
 *   now in functions instead of static methods.
 * - class sphere, plane, and frustum added
 * - move() methods renamed to translate()
 * - vec6f now again has ang data
 * - H,P,R instead of R,P,H restored
 *
 * Revision 1.43  2003/07/22 09:56:08  weyel
 * removed vec6f::ang[3], rotations are now stored in
 * coord[3] - coord[5], applied change to all vec6f functions
 *
 * Revision 1.42  2003/06/27 14:09:17  gf
 * changed order of HPR to RPH
 *
 * Revision 1.41  2003/06/24 14:05:28  gf
 * added rotation for vec6f::move()
 *
 * Revision 1.40  2003/06/23 14:57:12  weyel
 * made it compile with new talk version
 *
 * Revision 1.39  2003/05/30 08:32:06  mvdh
 * added more documentation
 *
 * Revision 1.38  2003/05/27 14:57:11  weyel
 * changed #ifdef _MSC_VER to #ifdef WIN32 for compiling with MinGW
 *
 * Revision 1.37  2003/05/21 09:15:23  mvdh
 * fixed several doxygen errors and warnings
 *
 * Revision 1.36  2003/05/16 16:09:11  mvdh
 * some changes to make the version compile on IRIX and run on Linux
 *
 * Revision 1.35  2003/04/06 18:48:16  gf
 * veMath: vertex and vec3f class unified to generic vec3f class with full
 * functionality. This requires the renaming of vertex in several files.
 * line::intersects() methods added.
 *
 * Revision 1.34  2003/04/01 09:57:56  gf
 * instead of WIN32 use of _MSC_VER, for keeping MinGW compatibility. If this
 * does not work under Visual C++ please let me know to find a better solution!
 *
 * Revision 1.33  2003/03/31 16:19:52  gf
 * namespace ve added. Should be consequently used instead of VE_ etc.
 *
 * Revision 1.32  2003/03/26 15:34:28  gf
 * triangle::transform added
 *
 * Revision 1.31  2003/03/25 21:33:32  mvdh
 * doxygenify most standard doc++ statements
 *
 * Revision 1.30  2003/03/25 17:29:00  mvdh
 * major changes in most files - cebit version from MvdH now in action - please watch out for eventual errors and conflicts - now windows and linux support
 */
#endif        // _VE_MATH_H
