// veGeoObj - generic geometry object classes
// started 2003-03-10 by Gerald.Franz@tuebingen.mpg.de

#include "veConfig.h"
#include "veStd.h"
#ifdef _HAVE_GL
#  include <GL/gl.h>
#  include <GL/glu.h>
#  include <veImage.h>
#endif
#include "veGeoObj.h"
#include "veStrUtils.h"
#include "veTypes.h"
#include "veUtils.h"
#include "veXml.h"
#include "veMath.h"
#include "veIo3ds.h"
#include <float.h>

#ifdef _VELITE
class ve::plugin { // dummy
public:
    void draw(ve::geoObj *) { ; };
    bool drawFunctionLinked() { return false; };
};
#else
#  include "vePlugins.h"
#endif

using namespace ve;
using namespace std;

//--- class ve::ioFileHandler -------------------------------------- /*fold00*/

vector<string> ioFileHandler::vSuffix;
vector<geoObj* (*)(const std::string &)> ioFileHandler::vLoadFunc;

geoObj * ioFileHandler::load(const std::string & filename) {
    string suffix=filename.substr(filename.rfind('.')+1);
    for(unsigned int i=0; i<vSuffix.size(); i++) if(vSuffix[i]==suffix) {
        return (*vLoadFunc[i])(filename);
    }
    return 0;
}

//--- class ve::ioVrml --------------------------------------------- /*fold00*/

int ioVrml::toX3d (const std::string & filename, ve::xml & xs) {
    FILE * file=0;
    file=fileIo::open(filename,"r");
    if(!file) {
        cerr << "ERROR glMeshObj::preparse(): error in file "<< filename << " or file not found" << endl;
        return 1;
    }

    vector<string> token;
    string s;
    fileIo::getline(file,s); // interpret first line
    float vrmlVersion=-1;
    if(s.size()>7) vrmlVersion=s2f(s.substr(7));
    else {
        cerr << "ERROR glMeshObj::preparse(): file "<< filename << " has corrupt VRMl header." << endl;
        fileIo::close(file);
        return 1;
    }
    if((vrmlVersion > 2.0f)||(vrmlVersion < 1.0f))
        cerr << "WARNING glMeshObj::preparse(): VRML version "<< xs.getAttribute("version") << " not officially supported." << endl;

    while(!fileIo::eof(file)) {  // load file
        fileIo::getline(file,s);
        s=replaceAll(s.substr(0,s.find('#')),"]"," ] ");   // strip comments and add a leading space before brackets which 3ds forgets
        s=replaceAll(s,"["," [ ");  // there are lots of lazy exporters that do not stick to the whitespace rule...
        s=replaceAll(s,"{"," { ");
        s=replaceAll(s,"}"," } ");
        split(s,token,", \t\n\015"); // tokenize, remove commata
    }
    fileIo::close(file);
    s.erase();

    // prepare x3d root:
    xs.tag("X3D");
    xs.setAttribute("version","3.0");
    ve::xml head("head");
    ve::xml meta("meta");
    meta.setAttribute("name","filename");
    meta.setAttribute("content",filename);
    head.addChild(meta);
    xs.addChild(head);
    ve::xml scene("Scene");
    xs.addChild(scene);

    // split into nodes and transform into xml:
    ve::xml *currSt = xs.subTag("Scene");
    unsigned int i;
    for (i=0; i<token.size(); i++) {
        if(!token[i].size()) continue;
        if(vrmlVersion==1.0f) { // translate into vrml97
            if(token[i]=="filename") token[i]="url";
            else if(token[i]=="Coordinate3") token[i]="Coordinate";
            else if(token[i]=="TextureCoordinate2") token[i]="TextureCoordinate";
            else if(token[i]=="Texture2") token[i]="ImageTexture";
        }
        //cout << token[i] << " " << flush;
        // common operations:
        if((token[i][0]=='{')&&(i>0)) {
            ve::xml newSt;
            newSt.tag(token[i-1]);
            if((i>2)&&(token[i-3]=="DEF")) newSt.setAttribute("DEF",token[i-2]);
            //cout << "\nnewSt: " << newSt.str() << flush;
            //cout << "curSt: " << currSt->tag() << endl;
            currSt->addChild(newSt);
            currSt=currSt->child(currSt->nChildren()-1);
            //cout << "curSt after: " << currSt->tag() << endl;
        }
        else if(token[i][0]=='}') {
            if((currSt->tag()=="TextureCoordinate")||(currSt->tag()=="Coordinate"))
                currSt->setAttribute("point",s);
            else if(currSt->tag()=="Color")
                currSt->setAttribute("color",s);
            else if(currSt->tag()=="Normal")
                currSt->setAttribute("vector",s);
            s.erase();
            currSt=currSt->parent();
            //cout << "curSt back: " << currSt->tag() << endl;
        }
        else if(token[i]=="DEF") i++;  // skip also following id
        else if((i<token.size()-2)&&(token[i+1][0]=='{')) { ; } // skip subnode tags
        // special operations for recognized nodes:
        else if(currSt->tag()=="IndexedFaceSet") {
            if((token[i]=="coordIndex")||(token[i]=="texCoordIndex")
               ||(token[i]=="colorIndex")||(token[i]=="normalIndex")) {
                const string & attribute=token[i++];
                string value;
                while(token[++i][0]!=']') value+=" "+token[i];
                currSt->setAttribute(attribute,value);
            }
            else if((token[i]=="FALSE")||(token[i]=="TRUE"))
                currSt->setAttribute(token[i-1],token[i]);
            else if(token[i]=="USE") {
                currSt->setAttribute("USE"+i2s(i),token[i+1]);
                i++;
            }
        }
        else if(currSt->tag()=="ElevationGrid") {
            if((token[i]=="height")) {
                const string & attribute=token[i++];
                string value;
                while(token[++i][0]!=']') value+=" "+token[i];
                currSt->setAttribute(attribute,value);
            }
            else if((token[i]=="xDimension")||(token[i]=="xSpacing")||(token[i]=="zDimension")||(token[i]=="zSpacing")) {
                currSt->setAttribute(token[i],token[i+1]);
                i++;
            }
        }
        else if(currSt->tag()=="TextureTransform") {
            if(token[i]=="rotation") {
                currSt->setAttribute(token[i],token[i+1]);
                i++;
            }
            else if((token[i]=="scale")||(token[i]=="center")||(token[i]=="translation")) {
                currSt->setAttribute(token[i],token[i+1]+' '+token[i+2]);
                i+=2;
            }
        }
        else if((token[i][0]=='[')||(token[i][0]==']')
                ||(token[i]=="point")||(token[i]=="color")
                ||(token[i]=="vector")) { ; }  // skip
        else if((currSt->tag()=="TextureCoordinate")||(currSt->tag()=="Coordinate")
                ||(currSt->tag()=="Color")||(currSt->tag()=="Normal"))
            s+=" "+token[i];
        else if((token[i]=="diffuseColor")||(token[i]=="emissiveColor")||(token[i]=="specularColor")) {
                currSt->setAttribute(token[i],token[i+1]+' '+token[i+2]+' '+token[i+3]);
                i+=3;
        }
        else if((token[i]=="transparency")||(token[i]=="shininess")||(token[i]=="ambientIntensity")
                ||(token[i]=="repeatS")||(token[i]=="repeatT")||(token[i]=="USE")) {
            currSt->setAttribute(token[i],token[i+1]);
            i++;
        }
        else if(token[i]=="url") {
            string url;
            if(token[i+1][0]=='[') {
                url=token[i+2].substr(1,token[i+2].size()-2); // strip quotation marks
                i+=3;
            }
            else {
                url=token[i+1].substr(1,token[i+1].size()-2); // strip quotation marks
                i++;
            }
            if(url.find("file://")<url.size()) url=url.substr(url.find("file://")+7);
            currSt->setAttribute("url",url);
        }
        else if(((token[i]=="translation")||(token[i]=="scale")||(token[i]=="center"))&&((i+3)<token.size())) {
            currSt->setAttribute(token[i],token[i+1]+" "+token[i+2]+" "+token[i+3]);
            i+=3;
        }
        else if(((token[i]=="rotation")||(token[i]=="scaleOrientation"))&&((i+4)<token.size())) {
            currSt->setAttribute(token[i],token[i+1]+" "+token[i+2]+" "+token[i+3]+" "+token[i+4]);
            i+=4;
        }
        else { ; } // skip
    }
    return 0;
}

int ioVrml::toGeo(const std::string & filename, std::vector<ve::geoObj*> & vObj) {
    ve::xml xs;
    if(ioVrml::toX3d(filename,xs)!=0) return 1;
    return ioX3d::toGeo(xs,vObj);
}

void ioVrml::vrml2ve(std::vector<ve::vec3f> & vCoord) {
    float f;
    for(unsigned i=0; i<vCoord.size(); i++) {
        f=vCoord[i][Y];
        vCoord[i][Y]=-vCoord[i][Z];
        vCoord[i][Z]=f;
    }
}

//--- class ve::ioX3d ---------------------------------------------- /*fold00*/

int ioX3d::toGeo(const std::string & filename, std::vector<ve::geoObj*> & vObj) {
    ve::xml xs;
    xs.load(filename);
    matStack4f m;
    return interpretNode(xs,vObj,m);
}


int ioX3d::toGeo(ve::xml & xs, std::vector<ve::geoObj*> & vObj) {
    matStack4f m;
    return interpretNode(xs,vObj,m);
}


int ioX3d::interpretNode(ve::xml & xs, std::vector<ve::geoObj*> & vObj, ve::matStack4f & m ) {
    //cout << "\n---\n" << xs.str() << endl;
    bool matrixPushed=false;
    // check for and perform substitutions:
    unsigned int i;
    for(i=0; i<xs.nAttributes(); i++) if(xs.attributeName(i).substr(0,3)=="USE") {
        ve::xml * pRoot=&xs;
        while(pRoot->parent()!=0) pRoot=pRoot->parent();
        if(pRoot->subTagAttribute("DEF",xs.getAttribute(i)))
            xs.addChild(*pRoot->subTagAttribute("DEF",xs.getAttribute(i)));
    }
    // interpret recognized nodes:
    if(xs.tag()    == "Transform") {
        m.push();
        matrixPushed=true;
        m*=interpretTransform(xs,true);
    }
    else if(xs.tag()=="IndexedFaceSet") {
        geoMesh * pShape= new geoMesh(xs);
        if(pShape->state()!=ERR_OK) {
            delete pShape;
            return 1;
        }
        pShape->transform(m);   // apply current transformation
        vObj.push_back(pShape); // store interpreted object
        return 0;
    }
    else if(xs.tag()=="ElevationGrid") {
        geoElevationGrid * pShape=new geoElevationGrid(xs);
        if(pShape->state()!=ERR_OK) {
            delete pShape;
            return 1;
        }
        pShape->transform(m);   // apply current transformation
        vObj.push_back(pShape); // store interpreted object
        return 0;
    }
    // descend into subtags:
    for(i=0; i<xs.nChildren(); i++)
        interpretNode(*xs.child(i),vObj,m);

    if(matrixPushed) m.pop();
    return 0;
}


mat4f ioX3d::interpretTransform(const ve::xml & xs, bool vrml2ve) {
    vector<string> vStr;
    mat4f m;
    unsigned int indY, indZ;
    float        sgnY;
    if(vrml2ve) { indY=Z; indZ=Y; sgnY=-1.0f; }
    else        { indY=Y; indZ=Z; sgnY= 1.0f; }

    if(xs.tag()!="Transform") {
        cerr << "ve::ioX3D::interpretTransform WARNING: statement has wrong tag: [" << xs.tag() << "]\n";
    }
    if(xs.getAttribute("translation").size()) {
        //cerr << "translation " << xs.getAttribute("translation") << "\n";
        vStr.clear();
        split(xs.getAttribute("translation"),vStr);
        if(vStr.size()>2)
            m.translate(s2f(vStr[0]),sgnY*s2f(vStr[indY]),s2f(vStr[indZ]));
    }
    if(xs.getAttribute("center").size()) {
        //cerr << "center " << xs.getAttribute("center") << "\n";
        vStr.clear();
        split(xs.getAttribute("center"),vStr);
        if(vStr.size()>2)
            m.translate(s2f(vStr[0]),sgnY*s2f(vStr[indY]),s2f(vStr[indZ]));
    }
    if(xs.getAttribute("rotation").size()) {
        //cerr << "rotation " << xs.getAttribute("rotation") << "\n";
        vStr.clear();
        split(xs.getAttribute("rotation"),vStr);
        if(vStr.size()>3)
            m.rotate(s2f(vStr[3])*RAD2DEG, s2f(vStr[0]),sgnY*s2f(vStr[indY]),s2f(vStr[indZ]));
    }
    if(xs.getAttribute("scale").size()) {
        if(xs.getAttribute("scaleOrientation").size()) {
            //cerr << "scaleOrientation " << xs.getAttribute("scaleOrientation") << "\n";
            vStr.clear();
            split(xs.getAttribute("scaleOrientation"),vStr);
            if(vStr.size()>3)
                m.rotate(-s2f(vStr[3])*RAD2DEG,s2f(vStr[0]),sgnY*s2f(vStr[indY]),s2f(vStr[indZ]));
        }
        //cerr << "scale " << xs.getAttribute("scale") << "\n";
        vStr.clear();
        split(xs.getAttribute("scale"),vStr);
        if(vStr.size()>2)
            m.scale(s2f(vStr[0]),s2f(vStr[indY]),s2f(vStr[indZ]));
        if(xs.getAttribute("scaleOrientation").size()) {
            //cerr << "scaleOrientation " << xs.getAttribute("scaleOrientation") << "\n";
            vStr.clear();
            split(xs.getAttribute("scaleOrientation"),vStr);
            if(vStr.size()>3)
                m.rotate(s2f(vStr[3])*RAD2DEG,s2f(vStr[0]),sgnY*s2f(vStr[indY]),s2f(vStr[indZ]));
        }
    }
    if(xs.getAttribute("center").size()) {
        //cerr << "center " << xs.getAttribute("center") << "\n";
        vStr.clear();
        split(xs.getAttribute("center"),vStr);
        if(vStr.size()>2)
            m.translate(-s2f(vStr[0]),sgnY*-s2f(vStr[indY]),-s2f(vStr[indZ]));
    }
    return m;
}


//--- class ve::geoObj --------------------------------------------- /*fold00*/

int geoObj::s_counter=0;
double geoObj::s_tNow=0.0;
vec6f * geoObj::s_pCamera=0;

geoObj::geoObj(unsigned int newId) {
    m_plugin = NULL;
    m_pParent=NULL;
    m_id=s_counter++;
    m_classId=newId;
    m_color.set(1.0f, 1.0f, 1.0f, 1.0f);
    m_isTransp=false;
    m_pUserData=0;
    m_state=ERR_OK;
}

geoObj::geoObj(const geoObj & source) {
    m_plugin = NULL;
    m_pParent=NULL;
    m_id=s_counter++;
    m_classId=source.m_classId;
    m_name=source.m_name;
    m_color=source.m_color;
    m_isTransp=source.m_isTransp;
    m_pUserData=source.m_pUserData;
    m_state=source.m_state;
}

geoObj::~geoObj() {
    if(m_pParent!=NULL) m_pParent->dropChild(this);
}

xml geoObj::xml() const {
    return ve::xml("geoObj",i2s(m_id));
}

bool geoObj::testBounding(const frustum & fr, const vec6f & sdof) const {
    if(!m_bndSphere.radius()) return true; // default draw everything
    sphere boundingSphere(m_bndSphere);
    boundingSphere.transform(sdof);
    return fr.intersects(boundingSphere);
}

void geoObj::drawBounding() {
#ifdef _HAVE_GL
    if(!m_bndSphere.radius()) return;
    // draw bounding geometry for debug purposes:
    static GLUquadricObj* quadric=0;
    if(!quadric) {
        quadric=gluNewQuadric();
        gluQuadricDrawStyle( quadric, (GLenum)GLU_LINE );
    }
    glPushMatrix();
    glTranslatef(m_bndSphere[X],m_bndSphere[Y],m_bndSphere[Z]);
    glColor3f(1.0f,1.0f,0.0f);
    gluSphere( quadric, m_bndSphere.radius(),8,16 );
    glPopMatrix();
#endif
}


//--- class ve::geoGroup ------------------------------------------- /*fold00*/

geoGroup::geoGroup(const string & filename, unsigned int newId) : geoObj(newId) {
    string suffix=filename.substr(filename.rfind('.'));
    if((suffix==".wrl")||(suffix==".WRL")) {
        if(ioVrml::toGeo(filename,vChildren)!=0) return;
    }
    else if((suffix==".x3d")||(suffix==".X3D")) {
        if(ioX3d::toGeo(filename,vChildren)!=0) return;
    }
    else if((suffix==".3ds")||(suffix==".3DS")) {
        io3ds loader;
        loader.load(filename,vChildren);
    }
    else {
        cerr << "ve::geoGroup constructor ERROR: " << filename << " unknown filetype.\n";
        m_state=ERR_IO;
        return;
    }
    for(unsigned int i=0; i<vChildren.size(); i++)
        vChildren[i]->parent(this);

    m_isIdentity=true;
    m_cleanupChildren=true;
    m_name=fileIo::unifyPath(filename);
#ifdef _HAVE_GL
    ve::glTexture::addSearchPath(m_name.substr(0,m_name.rfind('/')));
#endif
}

geoGroup::~geoGroup() {
    if(m_cleanupChildren) {
        for(vector<geoObj*>::iterator i=vChildren.begin(); i<vChildren.end(); i++)
            delete (*i);
        vChildren.clear();
    }
    else for(vector<geoObj*>::iterator i=vChildren.begin(); i<vChildren.end(); i++)
        (*i)->parent(NULL);
}

void geoGroup::draw() {
#ifdef _HAVE_GL
    if(!m_isIdentity) {
        glPushMatrix();
        glMultMatrixf(&m_mat[0]);
    }
    for(unsigned int i=0; i<vChildren.size(); i++) vChildren[i]->draw();
    if(!m_isIdentity) {
        glPopMatrix();
    }
#endif
}

void geoGroup::initGraphics() {
    for(unsigned int i=0; i<vChildren.size(); i++)
        vChildren[i]->initGraphics();
}

void geoGroup::addChild(geoObj * geoObject) {
    if(geoObject!=NULL) vChildren.push_back(geoObject);
    geoObject->parent(this);
}

void geoGroup::dropChild(geoObj * geoObject) {
    for(vector<geoObj*>::iterator i=vChildren.begin(); i<vChildren.end(); i++)
        if((*i)==(geoObject)) {
            vChildren.erase(i);
            return;
        }
}

void geoGroup::calcBounding() {
    vector<vec3f> vVertices;
    unsigned int i;
    for(i=0; i<vChildren.size(); i++)
        vChildren[i]->vertices(vVertices);
    if(vVertices.size()<1) return;

    // calculate bounding box parallel to coordinate system:
    vec3f pMin(vVertices[0]);
    vec3f pMax(vVertices[0]);
    for(i=1; i<vVertices.size(); i++) {
        if(vVertices[i][X]<pMin[X]) pMin[X]=vVertices[i][X];
        else if(vVertices[i][X]>pMax[X]) pMax[X]=vVertices[i][X];
        if(vVertices[i][Y]<pMin[Y]) pMin[Y]=vVertices[i][Y];
        else if(vVertices[i][Y]>pMax[Y]) pMax[Y]=vVertices[i][Y];
        if(vVertices[i][Z]<pMin[Z]) pMin[Z]=vVertices[i][Z];
        else if(vVertices[i][Z]>pMax[Z]) pMax[Z]=vVertices[i][Z];
    }
    // search for minimal radius from center of bounding box:
    vec3f c((pMin+pMax)*0.5f);
    float rSquared=0.0f;
    for(i=0; i<vVertices.size(); i++) {
        float currDist=c.sqrDistTo(vVertices[i]);
        if(currDist>rSquared) rSquared=currDist;
    }
    m_bndSphere=sphere(c,sqrt(rSquared));
}

const ve::vec3f geoGroup::minCoord() const {
    vector<vec3f> vVertices;
    unsigned int i;
    for(i=0; i<vChildren.size(); i++)
        vChildren[i]->vertices(vVertices);
    if(vVertices.size()<1) return vec3f(0,0,0);
    vec3f extremum=vVertices[0];
    for(i=1; i<vVertices.size(); i++) {
        if(vVertices[i][X]<extremum[X]) extremum[X]=vVertices[i][X];
        if(vVertices[i][Y]<extremum[Y]) extremum[Y]=vVertices[i][Y];
        if(vVertices[i][Z]<extremum[Z]) extremum[Z]=vVertices[i][Z];
    }
    return extremum;
}

const ve::vec3f geoGroup::maxCoord() const {
    vector<vec3f> vVertices;
    unsigned int i;
    for(i=0; i<vChildren.size(); i++)
        vChildren[i]->vertices(vVertices);
    if(vVertices.size()<1) return vec3f(0,0,0);
    vec3f extremum=vVertices[0];
    for(i=1; i<vVertices.size(); i++) {
        if(vVertices[i][X]>extremum[X]) extremum[X]=vVertices[i][X];
        if(vVertices[i][Y]>extremum[Y]) extremum[Y]=vVertices[i][Y];
        if(vVertices[i][Z]>extremum[Z]) extremum[Z]=vVertices[i][Z];
    }
    return extremum;
}

void geoGroup::triangles(vector<triangle> & vTr) const { // fills vTr with corresponding triangles
    unsigned int startSize=static_cast<unsigned int>(vTr.size());
    for(unsigned int i=0; i<vChildren.size(); i++)
        vChildren[i]->triangles(vTr);
    m_mat.transform(&vTr[startSize][0][X], (static_cast<unsigned int>(vTr.size())-startSize)*3);
}

void geoGroup::vertices(vector<vec3f> & vVertices) const {
    unsigned int startSize = static_cast<unsigned int>(vVertices.size());
    for(unsigned int i = 0; i < static_cast<unsigned int>(vChildren.size()); i++)
        vChildren[i]->vertices(vVertices);
    m_mat.transform(&vVertices[startSize][X], static_cast<unsigned int>(vVertices.size())-startSize);
}

string geoGroup::vrml(unsigned int nTabs) const {
    string s;
    unsigned int i;
    string tabs;
    for(i=0; i<nTabs; i++) tabs+='\t';
    vec6f pos(m_mat); // has to be improved...
    vec6f noTransform;

    if(pos!=noTransform) {
        s+=tabs+"Transform {  # group translation, heading\n";
        s+=tabs+"\ttranslation "+f2s(pos[X])+' '+f2s(pos[Z])+' '+f2s(-pos[Y])+'\n';
        if(pos[H]) s+=tabs+"\trotation 0 1 0 "+f2s(DEG2RAD*pos[H])+'\n';
        s+=tabs+"\tchildren [\n";
        tabs+="\t\t";
        nTabs+=2;
    }
    else nTabs++;
    if(pos[P]) {
        s+=tabs+"Transform { # pitch\n";
        s+=tabs+"\ttranslation 0 0 0\n";
        s+=tabs+"\trotation 0 0 -1 "+f2s(DEG2RAD*pos[P])+'\n';
        s+=tabs+"\tchildren [\n";
        tabs+="\t\t";
        nTabs+=2;
    }
    if(pos[R]) {
        s+=tabs+"Transform { # roll\n";
        s+=tabs+"\ttranslation 0 0 0\n";
        s+=tabs+"\trotation 1 0 0 "+f2s(DEG2RAD*pos[R])+'\n';
        s+=tabs+"\tchildren [\n";
        tabs+="\t\t";
        nTabs+=2;
    }

    for(unsigned int i=0; i<vChildren.size(); i++)
        s+=vChildren[i]->vrml(nTabs)+'\n';

    if(pos[R]) {
        tabs-=2;
        s+=tabs+"\t]\n"+tabs+"}\n";
    }
    if(pos[P]) {
        tabs-=2;
        s+=tabs+"\t]\n"+tabs+"}\n";
    }
    if(pos!=noTransform) {
        tabs-=2;
        s+=tabs+"\t]\n"+tabs+"}\n";
    }
    return s;
}

void geoGroup::regionalize(unsigned int currRecursion) {
    const unsigned int maxRecursion=8;
    if(currRecursion>maxRecursion) return;
    // try to further subdivide:
    vector<geoObj*> vLeaf[5];
    unsigned int i;
    if(!m_bndSphere.radius()) calcBounding();
    for(i=0; i<vChildren.size(); i++) {
        if(!vChildren[i]->boundingSphere().radius()) vChildren[i]->calcBounding();

        unsigned char sector=4;
        float currRadius= (vChildren[i]->boundingSphere().radius()) < (0.3 * m_bndSphere.radius()) ? 0 : vChildren[i]->boundingSphere().radius();
        if(vChildren[i]->boundingSphere()[X] + currRadius <= m_bndSphere[X])
            sector=0;
        else if(vChildren[i]->boundingSphere()[X] - currRadius >= m_bndSphere[X])
            sector=1;

        if(sector<4) {
            if(vChildren[i]->boundingSphere()[Y] + currRadius <= m_bndSphere[Y]) { }
            else if(vChildren[i]->boundingSphere()[Y] - currRadius >= m_bndSphere[Y])
                sector+=2;
            else sector=4;
        }
        vLeaf[sector].push_back(vChildren[i]);
    }

    vChildren=vLeaf[4];
    for(i=0; i<4; i++) if(vLeaf[i].size()) {
        geoGroup* pSubNode=new geoGroup();
        pSubNode->parent(this);
        for(unsigned int j=0; j<vLeaf[i].size(); ++j)
            pSubNode->addChild(vLeaf[i][j]);
        pSubNode->regionalize(currRecursion+1);
        vChildren.push_back(pSubNode);
    }
}


//--- class ve::geoMesh -------------------------------------------- /*fold00*/

geoMesh::geoMesh() : geoObj() { /// constructor
    m_texRepeat=false;
    m_texId=m_listId=0;
    m_state=ERR_WARNING;
}

geoMesh::geoMesh(const geoMesh& source) : geoObj(source) { // copy constructor
    m_vCoord      = source.m_vCoord;
    vTexCoords    = source.vTexCoords;
    vIndices      = source.vIndices;
    vTexIndices   = source.vTexIndices;
    vFaceEnds     = source.vFaceEnds;
    vColorIndices = source.vColorIndices;
    m_vNormalIndex= source.m_vNormalIndex;
    m_vColor      = source.m_vColor;
    m_vNormal     = source.m_vNormal;
    m_texName     = source.m_texName;
    m_texRepeat   = source.m_texRepeat;
    m_texId       = source.m_texId;
    m_listId      = source.m_listId;
}


geoMesh::geoMesh(const ve::xml & xs) : geoObj() {
    m_texRepeat=false;
    m_texId=m_listId=0;

    if(xs.tag()!="IndexedFaceSet") {
        cerr << "ve::geoMesh X3D interpreter WARNING: statement has wrong tag: [" << xs.tag() << "]\n";
    }

    // search necessary subtags:
    const ve::xml * coord=xs.subTag("Coordinate");
    const ve::xml * colorValues=xs.subTag("Color");
    bool abort=false;
    if(!coord) {
        cerr << "WARNING geoMesh X3D interpreter: no Coordinate tag found." << endl;
        abort=true;
    }
    if(!xs.getAttribute("coordIndex").size()) {
        cerr << "WARNING geoMesh X3D interpreter: no coordIndex tag found." << endl;
        abort=true;
    }
    if(abort) {
        cerr << "ve::geoMesh X3D interpreter ERROR: IndexedFaceSet not interpretable.\n";
        m_state=ERR_ERROR;
        return;
    }
    //clog << "all necessary tags available.\n";

    // read into geoMesh object:
    vector<string> vStr;
    unsigned int i;
    split(coord->getAttribute("point"),vStr,", \t\n\015");
    if(vStr.size()%3!=0)
        cerr << "WARNING geoGroup::parse(): number of coords not a multiple of 3.\n";
    else for(i=0; i<vStr.size(); i+=3)
        m_vCoord.push_back(vec3f(s2f(vStr[i]),s2f(vStr[i+1]),s2f(vStr[i+2])));

    // add coordinate indices:
    vStr.clear();
    split(xs.getAttribute("coordIndex"),vStr,", \t\n\015");
    if(vStr.size()>0) {
        for(i=0; i<vStr.size()-1; i++) {
            vIndices.push_back(s2ui(vStr[i]));
            if(vStr[i+1]=="-1") {
                vFaceEnds.push_back(static_cast<unsigned int>(vIndices.size())-1);
                ++i;
            }
        }
        if(i<vStr.size()) {
            int index=s2i(vStr[i]);
            if(index>=0) {
                vIndices.push_back(index);
                vFaceEnds.push_back(static_cast<unsigned int>(vIndices.size())-1);
            }
        }
    }

    if(xs.getAttribute("texCoordIndex").size()) {
        vStr.clear();
        split(xs.getAttribute("texCoordIndex"),vStr,", \t\n\015");
        for(i=0; i<vStr.size(); i++) {
            int index=s2i(vStr[i]);
            if(index>=0) vTexIndices.push_back(index);
        }
    }

    if(xs.getAttribute("normalIndex").size()) {
        vStr.clear();
        split(xs.getAttribute("normalIndex"),vStr,", \t\n\015");
        for(i=0; i<vStr.size(); i++) {
            int index=s2i(vStr[i]);
            if(index>=0) m_vNormalIndex.push_back(index);
        }
    }
    ve::xml * xsNormal=xs.parent()->subTag("Normal");
    if(xsNormal) {
        vector<float> vNormal;
        s2f(xsNormal->getAttribute("vector"),vNormal);
        if(vNormal.size()%3!=0)
            cerr << "geoMesh X3D interpreter WARNING: number of coords not a multiple of 3.\n";
        else for(i=0; i<vNormal.size(); i+=3)
            m_vNormal.push_back(vec3f(vNormal[i],vNormal[i+1],vNormal[i+2]));
    }

    // add color per vertex information:
    if(xs.getAttribute("colorPerVertex")!="FALSE") {
        if(xs.getAttribute("colorIndex").size()) {
            vStr.clear();
            split(xs.getAttribute("colorIndex"),vStr,", \t\n\015");
            for(i=0; i<vStr.size(); i++) {
                int index=s2i(vStr[i]);
                if(index>=0) vColorIndices.push_back(index);
            }
        }
        if(colorValues) {
            vector<float> vColors;
            s2f(colorValues->getAttribute("color"),vColors);
            for(i=0;i<vColors.size()-2;i+=3)
                m_vColor.push_back(vec3f(vColors[i],vColors[i+1],vColors[i+2]));
        }
    }

    // add material information:
    m_color.set(1.0f,1.0f,1.0f,1.0f);
    if(xs.parent()) {
        ve::xml * mat=xs.parent()->subTag("Material");
        if(mat) {
            vStr.clear();
            split(mat->getAttribute("diffuseColor"),vStr,", \t\n\015");
            float opacity=1.0f;
            if(mat->getAttribute("transparency")!="") opacity=1.0f-s2f(mat->getAttribute("transparency"));
            if(vStr.size()==3)
                m_color.set(s2f(vStr[0]),s2f(vStr[1]),s2f(vStr[2]),opacity);
        }
        // search additional texture subtags:
        ve::xml * tex=xs.parent()->subTag("ImageTexture");
        ve::xml * texCoord=xs.parent()->subTag("TextureCoordinate");
        if(tex&&texCoord) {
            vector<float> texCoords;
            s2f(texCoord->getAttribute("point"),texCoords);
            addTexture(tex->getAttribute("url"),texCoords,(tex->getAttribute("repeatS")!="FALSE"));
        }
    }
    if(m_vCoord.size()) {
        ioVrml::vrml2ve(m_vCoord);           // flip YZ coordinates
        m_state=ERR_OK;
    }
    if(m_vNormal.size())
        ioVrml::vrml2ve(m_vNormal);          // flip YZ coordinates
}


void geoMesh::draw() { // draws object
  if ( (m_plugin != NULL) && (m_plugin->drawFunctionLinked()) ) {
    m_plugin->draw(this);
  } else {
#ifdef _HAVE_GL
    glCallList(m_listId);
#endif // _HAVE_GL
  }
}

void geoMesh::initGraphics() { // initializes OpenGL
#ifdef _HAVE_GL
    if(vTexCoords.size()&&m_texName.size()) {
        int texWidth, texHeight, byteDepth;
        // upload texture and get m_texId:
        if(glTexture::load(m_texName,m_texId,byteDepth,texWidth,texHeight,m_texRepeat)) {
            vTexCoords.clear(); // loading failed
            cerr << "WARNING glMesh::uploadTextures(): failed to open texture " << m_texName << endl;
        }
        else if(!(byteDepth%2)) m_isTransp=true;
    }
    if(m_color[3]<1.0) m_isTransp=true;
    bool isTriangular=true;
    unsigned int i;
    for(i=0; i<vFaceEnds.size(); i++) if(vFaceEnds[i]%3!=2) {
        isTriangular=false;
        break;
    }

    vector<vec3f> vNormal;
    unsigned int currEnd=0;
    if(!m_vNormal.size()||!m_vNormalIndex.size()) { // compute normals:
        for(i=0; ((i+2)<vIndices.size())&&(currEnd<vFaceEnds.size()); i++) {
            const vec3f & p0(m_vCoord[vIndices[i]]); ++i;
            const vec3f & p1(m_vCoord[vIndices[i]]); ++i;
            const vec3f & p2(m_vCoord[vIndices[i]]);
            vec3f v1(p0,p1);
            vec3f v2(p0,p2);
            // are vec1 and vec2f parallel?
            v1.normalize();
            v2.normalize();
            while((v1==v2)&&(i<currEnd)&&((i+1)<vIndices.size())) {
                i++;
                v2.set(p0,m_vCoord[vIndices[i]]);
                v2.normalize();
            }
            // compute normal:
            vec3f normal=v1.crossProduct(v2);
            normal.normalize();
            if(isnan(normal[X])||isnan(normal[Y])||isnan(normal[Z]))
                normal.set(0,0,1);
            vNormal.push_back(normal);
            i=vFaceEnds[currEnd];
            currEnd++;
        }
    }

    // generate display list:
    m_listId=glGenLists(1);
    glNewList(m_listId,GL_COMPILE);
    if(vTexCoords.size()&&m_texName.size()) {
        glEnable      ( GL_TEXTURE_2D );
        glTexEnvi     ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
        glBindTexture ( GL_TEXTURE_2D, m_texId );
    }
    glColor4fv(&m_color[0]);
    currEnd=0;

    if(isTriangular) glBegin(GL_TRIANGLES);
    else glBegin(GL_POLYGON);
    if(vNormal.size())
        glNormal3fv(&vNormal[currEnd][X]);
    for(i=0; (i<vIndices.size())&&(currEnd<vFaceEnds.size()); i++) {
        if(m_vColor.size()) {
          if(vColorIndices.size()) {
            if(i < vColorIndices.size())
              glColor3fv(&m_vColor[vColorIndices[i]][X]);
          }
          else
          {
            if(i < vIndices.size())
              glColor3fv(&m_vColor[vIndices[i]][X]);
          }
        }
        if(vTexCoords.size()) {
            if(vTexIndices.size())
            {
              if(i < vTexIndices.size())
                glTexCoord2fv(&vTexCoords[vTexIndices[i]][X]);
            }
            else
              if(i < vIndices.size())
                glTexCoord2fv(&vTexCoords[vIndices[i]][X]);
        }

        if(m_vNormal.size()&&m_vNormalIndex.size()) {
            if((i<m_vNormalIndex.size())&&(m_vNormalIndex[i]<m_vNormal.size()))
                glNormal3fv(&m_vNormal[m_vNormalIndex[i]][X]);
        }
        else if(vIndices[i]<m_vNormal.size())
            glNormal3fv(&m_vNormal[vIndices[i]][X]);

        glVertex3fv(&m_vCoord[vIndices[i]][X]);

        if(isTriangular) {
            if(i%3==2) {
                currEnd++;
                if(currEnd < vNormal.size())
                  glNormal3fv(&vNormal[currEnd][X]);
            }
        }
        else if(i>=vFaceEnds[currEnd]) {
            glEnd();
            if((currEnd+1)<vFaceEnds.size()) {
                glBegin(GL_POLYGON);
                currEnd++;
                if(currEnd < vNormal.size())
                  glNormal3fv(&vNormal[currEnd][X]);
            }
        }
    }
    if(isTriangular) glEnd();
    if(vTexCoords.size()&&m_texName.size())
        glDisable(GL_TEXTURE_2D);
    glEndList();
#endif // _HAVE_GL
}

void geoMesh::trianglesRaw(vector<triangle> & tr ) const { // fills tr with corresponding triangles
    const unsigned int * currPos= &vIndices[0];
    for(unsigned int i=0; i<vFaceEnds.size(); i++) {
        const unsigned int * currStop=&vIndices[vFaceEnds[i]];
        vector<vec3f> vertices;
        while(currPos<=currStop) {
            vertices.push_back(m_vCoord[*currPos]);
            currPos++;
        }
        if(vertices.size()<3) continue;
        else for( unsigned int j=2; j<vertices.size(); j++)
            tr.push_back(triangle(vertices[0],vertices[j-1],vertices[j]));
    }
}

void geoMesh::triangles(vector<triangle> & tr ) const { // fills tr with corresponding triangles
    if(!vFaceEnds.size()) return;
    unsigned int startSize = static_cast<unsigned int>(tr.size());

    trianglesRaw(tr);
    // apply transformations:
    mat4f m;
    geoGroup * pParent=m_pParent;
    while(pParent!=0) {
        m=pParent->transform()*m;
        pParent=pParent->parent();
    }
    m.transform(&tr[startSize][0][X],(static_cast<unsigned int>(tr.size())-startSize)*3);
}

void geoMesh::triangulate() {
    if(!vFaceEnds.size()) return;
    // copy coordinates in triangles:
    vector<triangle> tr;
    trianglesRaw(tr);
    // rebuild indices and face end list:
    vIndices.clear();
    vFaceEnds.clear();
    unsigned int i, j, k;
    for(i=0; i<tr.size(); i++)
        for(j=0; j<3; j++)
            for(k=0; k<m_vCoord.size(); k++)
                if((tr[i][j][X]==m_vCoord[k][X])&&(tr[i][j][Y]==m_vCoord[k][Y])&&(tr[i][j][Z]==m_vCoord[k][Z])) {
                    vIndices.push_back(k);
                    if(j==2) vFaceEnds.push_back(static_cast<unsigned int>(vIndices.size())-1);
                    continue;
                }
}

int geoMesh::addTexture(const string & filename, const vector<float> & texCoords,  bool repeatTexture) {
    vTexCoords.clear(); // currently only 1 texture supported.
    vTexCoords.reserve(texCoords.size()/2);
    unsigned int i;
    for(i=0; i<texCoords.size(); i+=2) vTexCoords.push_back(vec2f(texCoords[i],texCoords[i+1]));
    m_texName=filename;
    m_texRepeat=repeatTexture;
    return 0;
}

string geoMesh::vrml(unsigned int nTabs) const {
    string s;
    unsigned int i;
    string tabs;
    for(i=0; i<nTabs; i++) tabs+='\t';

    s+=tabs+"Shape { # mesh\n";
    s+=tabs+"\tappearance Appearance {\n";
    s+=tabs+"\t\tmaterial Material {\n";
    s+=tabs+"\t\t\tdiffuseColor " + f2s(m_color[0])+' '+ f2s(m_color[1]) + ' ' + f2s(m_color[2]) + '\n';
    //s+=tabs+"\t\t\tambientIntensity " + f2s(gamma_) + '\n';
    s+=tabs+"\t\t\ttransparency " + f2s(1.0-m_color[3]) + '\n';
    s+=tabs+"\t\t}\n";
    if(m_texName!="") {
        s+=tabs+"\t\ttexture ImageTexture {\n";
        s+=tabs+"\t\t\turl [ \""+m_texName+"\" ]\n";
        s+=tabs+"\t\t\trepeatS "+string(m_texRepeat? "TRUE\n" : "FALSE\n");
        s+=tabs+"\t\t\trepeatT "+string(m_texRepeat? "TRUE\n" : "FALSE\n");
        s+=tabs+"\t\t}\n";
    }
    s+=tabs+"\t}\n";
    s+=tabs+"\tgeometry IndexedFaceSet {\n";
    s+=tabs+"\t\tcoord Coordinate { point [\n";
    if(m_vCoord.size())
        s+=tabs+"\t\t\t"+f2s(m_vCoord[0][X])+' '+f2s(m_vCoord[0][Z])+' '+f2s(-m_vCoord[0][Y]);
    for (i=1; i<m_vCoord.size(); i++)
        s+=",\n"+tabs+"\t\t\t"+f2s(m_vCoord[i][X])+' '+f2s(m_vCoord[i][Z])+' '+f2s(-m_vCoord[i][Y]);
    s+="\n"+tabs+"\t\t] }\n";
    if(m_texName.size()) {
        s+=tabs+"\t\ttexCoord TextureCoordinate { point [\n";
        if(vTexCoords.size())
            s+=tabs+"\t\t\t"+f2s(vTexCoords[0][X])+' '+f2s(vTexCoords[0][Y]);
        for (i=1; i<vTexCoords.size(); i++)
            s+=",\n"+tabs+"\t\t\t"+f2s(vTexCoords[i][X])+' '+f2s(vTexCoords[i][Y]);
        s+="\n"+tabs+"\t\t] }\n";
    }
    if(vFaceEnds.size()&&vIndices.size()) {
        s+=tabs+"\t\tcoordIndex [\n"+tabs+"\t\t\t";
        unsigned int currFaceEnd=0;
        for(i=0;i<vIndices.size(); i++) {
            s+=i2s(vIndices[i])+", ";
            if(i==vFaceEnds[currFaceEnd]) {
                currFaceEnd++;
                if(currFaceEnd<vFaceEnds.size())
                    s+="-1,\n"+tabs+"\t\t\t";
                else s+="-1\n"+tabs+"\t\t]\n";
            }
        }
    }
    if(vTexIndices.size()&&vFaceEnds.size()) {
        s+=tabs+"\t\ttexCoordIndex [\n"+tabs+"\t\t\t";
        unsigned int currFaceEnd=0;
        for(i=0;i<vTexIndices.size(); i++) {
            s+=i2s(vTexIndices[i])+", ";
            if(i==vFaceEnds[currFaceEnd]) {
                currFaceEnd++;
                if(currFaceEnd<vFaceEnds.size())
                    s+="-1,\n"+tabs+"\t\t\t";
                else s+="-1\n"+tabs+"\t\t]\n";
            }
        }
    }
    if(m_vColor.size()) {
        s+=tabs+"\t\tcolor Color { color [\n";
        if(m_vColor.size())
            s+=tabs+"\t\t\t"+f2s(m_vColor[0][X])+' '+f2s(m_vColor[0][Y])+' '+f2s(m_vColor[0][Z]);
        for(i=1;i<m_vColor.size(); i++)
            s+=",\n"+tabs+"\t\t\t"+f2s(m_vColor[i][X])+' '+f2s(m_vColor[i][Y])+' '+f2s(m_vColor[i][Z]);
        s+='\n'+tabs+"\t\t] }\n";
    }
    if(vColorIndices.size()&&vFaceEnds.size()) {
        s+=tabs+"\t\tcolorIndex [\n"+tabs+"\t\t\t";
        unsigned int currFaceEnd=0;
        for(i=0;i<vColorIndices.size(); i++) {
            s+=i2s(vColorIndices[i])+", ";
            if(i==vFaceEnds[currFaceEnd]) {
                currFaceEnd++;
                if(currFaceEnd<vFaceEnds.size())
                    s+="-1,\n"+tabs+"\t\t\t";
                else s+="-1\n"+tabs+"\t\t]\n";
            }
        }
    }
    s+=tabs+"\t}\n";
    s+=tabs+"}\n";
    return s;
}

ostream & operator<<(ostream & os, const geoMesh & mesh) {
    return os << mesh.vrml();
}

void geoMesh::calcBounding() {
    if(!m_vCoord.size()) return;
    // collect transformed vertices:
    vector<vec3f> vVertex;
    vertices(vVertex);
    // calculate bounding box parallel to coordinate system:
    vec3f pMin(vVertex[0]);
    vec3f pMax(pMin);
    unsigned int i;
    for(i=1; i<vVertex.size(); i++) {
        if(vVertex[i][X]<pMin[X]) pMin[X]=vVertex[i][X];
        else if(vVertex[i][X]>pMax[X]) pMax[X]=vVertex[i][X];
        if(vVertex[i][Y]<pMin[Y]) pMin[Y]=vVertex[i][Y];
        else if(vVertex[i][Y]>pMax[Y]) pMax[Y]=vVertex[i][Y];
        if(vVertex[i][Z]<pMin[Z]) pMin[Z]=vVertex[i][Z];
        else if(vVertex[i][Z]>pMax[Z]) pMax[Z]=vVertex[i][Z];
    }
    // search for minimal radius from center of bounding box:
    vec3f c((pMin+pMax)*0.5f);
    float rSquared=0.0f;
    for(i=0; i<vVertex.size(); i++) {
        float currDist=c.sqrDistTo(vVertex[i]);
        if(currDist>rSquared) rSquared=currDist;
    }
    m_bndSphere=sphere(c,sqrt(rSquared));
}

void geoMesh::vertices(vector<vec3f> & vVertices) const {
    unsigned int startSize = static_cast<unsigned int>(vVertices.size());
    for(unsigned int i=0; i<m_vCoord.size(); i++)
        vVertices.push_back(m_vCoord[i]);
}

//--- class ve::geoElevationGrid ----------------------------------- /*fold00*/

geoElevationGrid::geoElevationGrid(const float * pElev, unsigned int dimX, unsigned int dimY, float spacingX, float spacingY, float scaleZ) : geoObj() {
    m_dimX=dimX;
    m_dimY=dimY;
    m_spaceX=spacingX;
    m_spaceY=spacingY;
    m_texId=0;
    m_texCoordScale.set(1.0f,1.0f);

    m_vCoord.assign(m_dimX*m_dimY,vec3f(0,0,0));
    for(unsigned int j=0; j<m_dimY; j++)
        for(unsigned int i=0; i<m_dimX; i++)
            m_vCoord[i+m_dimX*j].set(i*m_spaceX, j*m_spaceY, scaleZ*pElev[i+m_dimX*j]);
    if(!m_vCoord.size()) m_state=ERR_WARNING;
}

geoElevationGrid::geoElevationGrid(const ve::xml & xs) : geoObj() {
    if(xs.tag()!="ElevationGrid") {
        cerr << "ve::geoElevationGrid X3D interpreter WARNING: statement has wrong tag:[" << xs.tag() << "]\n";
    }
    m_dimX=s2ui(xs.getAttribute("xDimension","0"));
    m_dimY=s2ui(xs.getAttribute("zDimension","0"));
    m_spaceX=s2f(xs.getAttribute("xSpacing","1"));
    m_spaceY=s2f(xs.getAttribute("zSpacing","1"));
    m_texId=0;
    m_texCoordScale.set(1.0f,1.0f);

    vector<float> vHeight;
    if(xs.getAttribute("height").size())
        s2f(xs.getAttribute("height"),vHeight);
    if(vHeight.size()<m_dimX*m_dimY) {
        cerr << "ve::geoElevationGrid X3D interpreter ERROR: not enough height values found.\n";
        m_state=ERR_ERROR;
        return;
    }
    if(xs.parent()!=0) {
        const ve::xml * mat=xs.parent()->subTag("Material");
        if(mat) {
            m_color.set(mat->getAttribute("diffuseColor"));
            if(mat->getAttribute("transparency")!="")
                m_color[3]=1.0f-s2f(mat->getAttribute("transparency"));
            else m_color[3]=1.0f;
            ve::xml * tex=xs.parent()->subTag("ImageTexture");
            if(tex) {
                m_texName=tex->getAttribute("url");
            }
            ve::xml * texTransf=xs.parent()->subTag("TextureTransform");
            if(texTransf) {
                vector<float> vF;
                s2f(texTransf->getAttribute("scale"),vF);
                if(vF.size()>1) m_texCoordScale.set(vF[0],vF[1]);
            }
        }
    }
    m_vCoord.assign(m_dimX*m_dimY,vec3f(0,0,0));
    for(unsigned int j=0; j<m_dimY; j++)
        for(unsigned int i=0; i<m_dimX; i++)
            m_vCoord[i+m_dimX*j].set(i*m_spaceX, j*m_spaceY, vHeight[i+m_dimX*(m_dimY-1-j)]);
    if(!m_vCoord.size()) m_state=ERR_WARNING;
}

void geoElevationGrid::initGraphics() {
    // calculate normals:
    m_vNormal.assign(m_dimX*m_dimY,vec3f(0,0,0));
    unsigned int i, j;
    for(j=0; j<m_dimY-1; j++)
        for(i=0; i<m_dimX-1; i++) {
            triangle tr0(m_vCoord[i+m_dimX*(j+1)], m_vCoord[i+m_dimX*j], m_vCoord[i+1+m_dimX*j]);
            triangle tr1(m_vCoord[i+m_dimX*j], m_vCoord[i+1+m_dimX*j], m_vCoord[i+1+m_dimX*(j+1)]);
            vec3f n0=tr0.normalVector();
            vec3f n1=tr1.normalVector();
            m_vNormal[i+m_dimX*(j+1)]+=n0; m_vNormal[i+m_dimX*j]+=n0; m_vNormal[i+1+m_dimX*j]+=n0;
            m_vNormal[i+m_dimX*j]+=n1; m_vNormal[i+1+m_dimX*j]+=n1; m_vNormal[i+1+m_dimX*(j+1)]+=n1;
        }
    for(j=0; j<m_dimY; j++)
        for(i=0; i<m_dimX; i++) if(m_vNormal[i+m_dimX*j][X]||m_vNormal[i+m_dimX*j][Y]||m_vNormal[i+m_dimX*j][Z])
            m_vNormal[i+m_dimX*j].normalize();
        else m_vNormal[i+m_dimX*j].set(0.0f,0.0f,1.0f);
    // calculate texture coordinates:
    if(m_texName.size()) {
        int texWidth, texHeight, byteDepth;
        // upload texture and get m_texId:
        if(glTexture::load(m_texName,m_texId,byteDepth,texWidth,texHeight,true)) {
            cerr << "WARNING geoElevationGrid::initGraphics(): failed to open texture " << m_texName << endl;
        }
        else {
            m_vTexCoord.assign(m_dimX*m_dimY,vec2f(0,0));
            for(j=0; j<m_dimY; j++)
                for(i=0; i<m_dimX; i++)
                    m_vTexCoord[i+m_dimX*j].set(m_texCoordScale[X]*float(i)/float(m_dimX-1),
                                                m_texCoordScale[Y]*float(j)/float(m_dimY-1));
            if(!(byteDepth%2)) m_isTransp=true;
        }
    }
    if(m_color[3]<1.0) m_isTransp=true;
}

void geoElevationGrid::draw() {
#ifdef _HAVE_GL
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    if(m_texId) {
        glEnable           ( GL_TEXTURE_2D );
        glBindTexture      ( GL_TEXTURE_2D, m_texId );
        glEnableClientState( GL_TEXTURE_COORD_ARRAY) ;
        glTexCoordPointer(2, GL_FLOAT, 0, &m_vTexCoord[0]);
    }
    glVertexPointer  (3, GL_FLOAT, 0, &m_vCoord[0]);
    glNormalPointer  (   GL_FLOAT, 0, &m_vNormal[0]);

    glColor4fv(&m_color[0]);

    for(unsigned int j=0; j<m_dimY-1; j++) {
        glBegin(GL_QUAD_STRIP);
        for(unsigned int i=0; i<m_dimX; i++) {
            glArrayElement(i+m_dimX*(j+1));
            glArrayElement(i+m_dimX* j);
        }
        glEnd();
    }
    if(m_texId) {
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
        glDisable(GL_TEXTURE_2D);
    }
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
#endif // _HAVE_GL
}

void geoElevationGrid::triangles(vector<triangle> & tr) const {
    unsigned int startSize = static_cast<unsigned int>(tr.size());
    for(unsigned int j=0; j<m_dimY-1; j++)
        for(unsigned int i=0; i<m_dimX-1; i++) {
            tr.push_back(triangle(m_vCoord[i+m_dimX*(j+1)], m_vCoord[i+m_dimX*j], m_vCoord[i+1+m_dimX*(j+1)]));
            tr.push_back(triangle(m_vCoord[i+m_dimX*j], m_vCoord[i+1+m_dimX*j],m_vCoord[i+1+m_dimX*(j+1)]));
        }
    // apply transformations:
    mat4f m;
    geoGroup * pParent=m_pParent;
    while(pParent!=0) {
        m=pParent->transform()*m;
        pParent=pParent->parent();
    }
    m.transform(&tr[startSize][0][X],(static_cast<unsigned int>(tr.size())-startSize)*3);
}

void geoElevationGrid::calcBounding() {
    if(!m_vCoord.size()) return;
    vec3f pMin(m_vCoord[0]);
    vec3f pMax(pMin);
    unsigned int i;
    // calculate bounding box parallel to coordinate system:
    for(i=1; i<m_vCoord.size(); i++) {
        if(m_vCoord[i][X]<pMin[X]) pMin[X]=m_vCoord[i][X];
        else if(m_vCoord[i][X]>pMax[X]) pMax[X]=m_vCoord[i][X];
        if(m_vCoord[i][Y]<pMin[Y]) pMin[Y]=m_vCoord[i][Y];
        else if(m_vCoord[i][Y]>pMax[Y]) pMax[Y]=m_vCoord[i][Y];
        if(m_vCoord[i][Z]<pMin[Z]) pMin[Z]=m_vCoord[i][Z];
        else if(m_vCoord[i][Z]>pMax[Z]) pMax[Z]=m_vCoord[i][Z];
    }
    // search for minimal radius from center of bounding box:
    vec3f c((pMin+pMax)*0.5f);
    float rSquared=0.0f;
    for(i=0; i<m_vCoord.size(); i++) {
        float currDist=c.sqrDistTo(m_vCoord[i]);
        if(currDist>rSquared) rSquared=currDist;
    }
    m_bndSphere=sphere(c,sqrt(rSquared));
}

float geoElevationGrid::elevation(float x, float y) const {
    // apply transformations:
    mat4f m;
    geoGroup * pParent=m_pParent;
    while(pParent!=0) {
        m=pParent->transform()*m;
        pParent=pParent->parent();
    }
    // FIXME: test correctness of inverse transformation
    m.inverse();
    if(m.isNan()) return 0.0f;
    vec3f vertex(x,y,0);
    vertex.transform(m);
    x=vertex[X]; y=vertex[Y];
    if((x<0.0f)||(y||0.0f)||(x>(m_dimX-1)*m_spaceX)||(y>(m_dimY-1)*m_spaceY))
        return 0.0f;

    int x0=int(x/m_spaceX);
    if(x0<0) x0=0;
    else if((unsigned int)x0>=m_dimX) x0=m_dimX-1;
    int x1=int(x/m_spaceX)+1;
    if(x1<0) x1=0;
    else if((unsigned int)x1>=m_dimX) x1=m_dimX-1;

    int y0=int(y/m_spaceY);
    if(y0<0) y0=0;
    else if((unsigned int)y0>=m_dimY) y0=m_dimY-1;
    int y1=int(y/m_spaceY)+1;
    if(y1<0) y1=0;
    else if((unsigned int)y1>=m_dimY) y1=m_dimY-1;

    float fracX=fmod(x,m_spaceX)/m_spaceX;
    float fracY=fmod(y,m_spaceY)/m_spaceY;
    // do interpolation:
    return (1.0f-fracX)*(1.0f-fracY)*m_vCoord[int(x0)*m_dimX+int(y0)][Z]
        + fracX*(1.0f-fracY)*m_vCoord[int(x1)*m_dimX+int(y0)][Z]
        + (1.0f-fracX)*fracY*m_vCoord[int(x0)*m_dimX+int(y1)][Z]
        + fracX*fracY*m_vCoord[int(x1)*m_dimX+int(y1)][Z];
}



//--- cvs history log ---------------------------------------------- /*FOLD00*/
/*
 * $Log: veGeoObj.cpp,v $
 * Revision 2.10  2005/01/17 09:28:31  gf
 * namespace quirks of plugins solved
 *
 * Revision 2.9  2005/01/10 16:53:05  franck
 * *** empty log message ***
 *
 * Revision 2.8  2005/01/03 10:53:24  gf
 * glBoxtree functionality now part of geoGroup
 *
 * Revision 2.7  2004/12/23 16:44:08  gf
 * - all error codes are now positive integers
 * - VRML/X3D loaders updated, now normals are interpreted if available
 * - matStack4f matrix stack class added
 * - Merry Christmas!
 *
 * Revision 2.6  2004/12/22 13:05:28  gf
 * initial transforms are now included into the vertex data
 *
 * Revision 2.5  2004/12/15 14:23:03  gf
 * Now geoObj make internally use of transformation matrices instead of
 * sixdofs. Some corresponding adaptations in various files.
 *
 * Revision 2.4  2004/12/07 13:44:29  gf
 * - mat4f is internally and externally conformant to OpenGL Matrices
 * - transformations of ElevationGrids should be handled correctly
 *
 * Revision 2.3  2004/12/06 11:19:17  gf
 * ongoing renovations of the file io framework
 *
 * Revision 2.2  2004/12/01 10:11:24  weyel
 * added load-time texture compression
 *
 * Revision 2.1  2004/11/26 16:43:16  weyel
 * fixed bug in texture path adding
 *
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 */
