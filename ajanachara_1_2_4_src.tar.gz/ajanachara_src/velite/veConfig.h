#ifndef _VE_CONFIG_H
#define _VE_CONFIG_H
/** @file veConfig.h
 \brief Central configuration file for the Virtual Environments Library (veLib).

 This file is the central configuration instance for all external library
 bindings of veLib. Here you can define which external libraries veLib
 should use and should provide interfaces. Its standard settings are fairly
 traditional and should work with all existing veLib programs.

 Important note: If you manually edit this file, it might be necessary
 to adjust the library linking options in the file
 VELIB_TOP_DIR/src/Malerules. Further advice is given at the particular
 defines that follow.
 
 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author  gf

 $Revision: 1.25 $
 */

//@{

#ident "$Id: veConfig.h,v 1.25 2004/02/11 16:25:39 gf Exp $"

/**
 Do we have ACE? Undef this if you don't have or plan to use ACE,
 and veLib will lack all its network communication and debugging
 abilities. If you do so, don't expect much support from our side.
 The Adaptive Communication Environment (ACE) is open source and
 free software, and can be found at
 http://www.cs.wustl.edu/~schmidt/ACE.html
 */
#undef _HAVE_ACE

/**
 Do we have OpenGL? Undef this if you don't have or plan to use OpenGL,
 and veLib will not work. ;-) Sorry, OpenGL is currently mandatory.
 More Information about OpenGL can be found at
 http://www.opengl.org
 */
#define _HAVE_GL 1

/**
 Do we have SDL? Undef this if you don't have or plan to use
 SDL, a cross-platform windowing and input handling toolkit,
 and veSDL will not be built.
 SDL is open source and free software. It can be obtained from
 http://www.libsdl.org.
 SDL support is currently experimental!
 If this option is used, the applications have also to be linked with
 -lSDL and correct library path settings.
 */
//#define _HAVE_SDL 1

/**
 Do we have libPNG?
 This free image library allows veImage to load PNG files
 together with zlib (needs -lpng -lz linking options).
 The homepage of libPNG is http://www.libpng.org/pub/png/ .
 */
#define _HAVE_LIBPNG 1

/**
 Do we have zLib?
 zLib is a free compression library (.gz) that for instance
 is used by libPNG, or by veGeoObj to load compressed VRML files.
 zLib needs the -lz linking option and can be obtained from
 http://www.gzip.org/zlib/ .
 */
#define _HAVE_LIBZ 1

/**
 Do we have libJPEG?
 This free image library allows veImage to load jpeg images
 (needs -ljpeg linking option).
 libJPEG can be found at http://www.ijg.org/ .
 */
#define _HAVE_LIBJPEG 1

/** different compilers under windows have different names for the same thing... */
#ifndef WIN32
#  ifdef _WIN32
#    define WIN32 1
#  endif
#endif

/**
 Do we have X-Window support ? This is set automatically 
 if you are not using a Win32-Compiler. Under Win32, veDeviceKbdX
 and veDeviceMouseX will not be built.
 */
#ifndef WIN32
#  define _HAVE_X 1
#else
#  undef _HAVE_X
#endif

/**
 Do we have DirectX?
 DirextX is a library for programming Multimedia applications
 for Windows operating systems. Actually, the veLib uses 
 DX for handling input devices on Windows machines. If you
 are working with another OS, _HAVE_DX is automatically set
 to 0 and all veDevice*Win and veDeviceDirectX will not be built.
 Otherwise you can choose if you want to use it by 
 altering the second define. To use the veLibs DX-functionality,
 you need the DirectX (9a or higher Version) runtime library installed
 on your Windows Machine. For development you need the DX SDK 
 (Software Development Kit).
 Both can be found at http://msdn.microsoft.com/directx .
 */
#ifndef WIN32
#  undef _HAVE_DX
#else
#  define _HAVE_DX 1
#endif

/**
 Do we have OpenAL? Undef this if you don't have or plan to use
 OpenAL, a cross-platform 3D audio library,
 and ve::deviceAudioAL will not be built.
 OpenAL is open source and free software, it can be obtained from
 http://www.openal.org.
 If this option is used, the applications have also to be linked with
 -lopenal under UNIX and -lopenal32 under Windows, and correct
 library path settings are required.
 */
//#define _HAVE_OPEN_AL 1


//@}

/* #[ cvs history log : *///----------------------------------------- /*FOLD00*/
/*
 * $Log: veConfig.h,v $
 * Revision 1.25  2004/02/11 16:25:39  gf
 * _HAVE_PERFORMER undefined
 *
 * Revision 1.24  2004/02/06 18:28:15  gf
 * - veConfig _HAVE_3DSOUND undefined
 * - ve::dataContainer access methods added, corresp. enums defined
 * - deviceGraphicsX3D now interprets basic messages in dataContainer
 *
 * Revision 1.23  2004/02/06 13:16:23  raths
 * no message
 *
 * Revision 1.22  2004/01/23 14:07:27  weyel
 * removed _HAVE_PLATFORM switch, because devicePlatform is
 * no longer part of veLib core
 *
 * Revision 1.21  2004/01/21 16:43:35  gf
 * - ve::motionXXX framework remodeled. Is now multi-user capable
 * - lippng, libjpeg, zlib now included as standard
 *
 * Revision 1.20  2004/01/12 15:54:12  gf
 * - veConfig documentation reference to Makerules added
 * - veDeviceGraphics3dPf dependencies on veVisibility removed
 * - veVisibility et al. moved to modules
 * - veCollisionPfPoygon removed, use veCollisionTriangle instead
 *
 * Revision 1.19  2004/01/08 15:58:21  gf
 * ve::deviceAudioSDL added
 *
 * Revision 1.18  2003/12/12 22:11:54  gf
 * any dependencies on GLFW removed. Slight improvements for the libSDL subsystem.
 *
 * Revision 1.17  2003/12/09 13:30:40  gf
 * _HAVE_SDL switch added
 *
 * Revision 1.16  2003/10/28 14:29:28  mvdh
 * docu updated
 *
 * Revision 1.15  2003/10/28 09:33:21  weyel
 * _HAVE_3DSOUND 0
 *
 * Revision 1.14  2003/08/15 13:06:03  raths
 * no message
 *
 * Revision 1.13  2003/07/24 10:00:04  gf
 * copyright updated
 *
 * Revision 1.12  2003/07/22 14:47:25  weyel
 * added _HAVE_3DSOUND switch
 *
 * Revision 1.11  2003/07/04 13:13:57  weyel
 * leave the _HAVE_PLATFORM switch at 0 unless
 * you really want the motion platform
 *
 * Revision 1.10  2003/07/01 12:53:02  weyel
 * added documentation
 *
 * Revision 1.9  2003/06/27 15:16:01  weyel
 * added _HAVE_PLATFORM
 *
 * Revision 1.8  2003/06/24 14:22:44  weyel
 * added docu
 *
 * Revision 1.7  2003/06/05 15:23:44  weyel
 * added _HAVE_DX switch
 *
 * Revision 1.6  2003/06/03 14:21:59  weyel
 * added more documentation
 *
 * Revision 1.5  2003/05/30 08:32:05  mvdh
 * added more documentation
 *
 * Revision 1.4  2003/05/22 15:13:38  weyel
 * added _HAVE_X switch
 */
/* #] history : */
#endif // _VE_CONFIG_H
