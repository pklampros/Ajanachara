#include "veStd.h"

#ifdef _HAVE_GL
extern "C" {
#  include <GL/gl.h>
#  include <GL/glu.h>
}
#endif

#if defined(_HAVE_LIBPNG) && defined(_HAVE_LIBZ)
extern "C" {
#  include <zlib.h>
#  include <png.h>
}
#endif

#ifdef _HAVE_LIBJPEG
extern "C" {
#if defined WIN32 || defined __WIN32__
//libjpeg defines FAR on WIN32, and so does MSVC
#ifdef FAR
#undef FAR
#endif
#endif
#  include <jpeglib.h>
}
#endif 

#ifdef _HAVE_SDL
extern "C" {
#  include <SDL.h>
}
#endif 

#include "veImage.h"
#include "veUtils.h"
#include "veGlUtils.h"

#include "GL/glext.h"

#include<map>

using namespace std;
using namespace ve;

//--- class ve::image ---------------------------------------------- /*fold00*/

image::image(const string & filename) {
    Width =  Height = 0;
    BytesPerPixel   = 0;
    Data            = NULL;
    if(filename.size()) read(filename);
}

image::image(const unsigned char * pData, unsigned int w, unsigned int h, unsigned int byteDepth) {
    Width         = w;
    Height        = h;
    BytesPerPixel = byteDepth;
    Data=NULL;
    unsigned int size = Width * Height * BytesPerPixel;
    Data = new unsigned char [size]; // allocate memory for image data
    if( Data == NULL ) {
        cerr << "ve::image constructor ERROR: could not allocate image memory.\n";
        Width=Height=BytesPerPixel=0;
        return;
    }
    memcpy(Data,pData,size);
}

image::image(const char **ch) {
    unsigned int nColors, charsPerPixel;
    sscanf(ch[0],"%d%d%d%d", &Width, &Height, &nColors, &charsPerPixel);
    //cout << Width << ' ' << Height << ' ' << nColors << ' ' << charsPerPixel << endl;
    // read colors:
    map<string,unsigned int> colorMap;
    unsigned int i;
    for(i=0; i<nColors; ++i) {
        //cout << "[" << ch[i+1] << "]" << endl;
        vector<string> vStr;
        split(ch[i+1],vStr);
        if(vStr.size()>2) {
            string colStr(vStr[2]);
            unsigned int color=0;
            if(colStr[0]=='#') colStr=colStr.substr(1);
            if((toLower(colStr)!="none")&&(toLower(colStr)!="background")) {
                if((colStr.size()!=6)&&(colStr.size()!=12)) {
                    cerr << "XPM interpreter WARNING: color map value has incorrect length.\n";
                    continue;
                }
                unsigned int szChunk=colStr.size()/3;
                unsigned int r=hex2ui(colStr.substr(0,2));
                unsigned int g=hex2ui(colStr.substr(szChunk,2));
                unsigned int b=hex2ui(colStr.substr(2*szChunk,2));
                // FIXME: take care of endian and byte order issues
                color= 255*256*256*256 + b*256*256 + g*256 + r;
            }
            colorMap.insert(make_pair(vStr[0],color));
        }
    }

    BytesPerPixel=4;
    Data=NULL;
    unsigned int size = Width * Height * BytesPerPixel;
    Data = new unsigned char [size]; // allocate memory for image data
    if( Data == NULL ) {
        cerr << "ve::image constructor ERROR: could not allocate image memory.\n";
        Width=Height=BytesPerPixel=0;
        return;
    }
    
    // read image:
    for(i=0; i<Height; ++i) {
        //cout << "[" << ch[i+1+nColors] << "]" << endl;
        string currLine(ch[i+1+nColors]);
        for(unsigned int j=0; j<Width, j<currLine.size()/charsPerPixel; ++j) {
            string currStr=currLine.substr(j*charsPerPixel,charsPerPixel);
            memcpy(&Data[((Height-i-1)*Width+j)*BytesPerPixel],&(colorMap[currStr]),BytesPerPixel);
        }
    }
}


image::~image() {
    if( Data != NULL ) delete [] Data;
}

const image & image::operator=(const image & source) {
    if (this==&source) return *this;   // first test for self reference
    if( Data != NULL ) delete [] Data; // cleanup
    Width         = source.w();
    Height        = source.h();
    BytesPerPixel = source.bytesPerPixel();
    Data=NULL;
    unsigned int size = Width * Height * BytesPerPixel;
    Data = new unsigned char [size]; // allocate memory for image data
    if( Data == NULL ) {
        cerr << "ve::image copy constructor ERROR: could not allocate image memory.\n";
        Width=Height=BytesPerPixel=0;
        return *this;
    }
    memcpy(Data,source.data(),size);
    return *this;
}

unsigned int image::pixel(unsigned int x, unsigned int y) const {
    if((x>=Width)||(y>=Height)) return 0;
    unsigned int pix=0;
    switch( BytesPerPixel ) {
    case 1:
        pix=Data[(Width*y)+x];
        break;
    default:
        for(unsigned int i=0; i<BytesPerPixel; i++) {
            unsigned int value=Data[((Width*y)+x)*BytesPerPixel+i];
            pix+=value<<(8*i);
        }
    }
    return pix;
}

void image::pixel(unsigned int x, unsigned int y, unsigned int value) {
    if((x>=Width)||(y>=Height)) return;
    switch( BytesPerPixel ) {
    case 1:
        Data[(Width*y)+x]=(unsigned char)value;
        break;
    default:
        for(unsigned int i=0; i<BytesPerPixel; i++)
            Data[((Width*y)+x)*BytesPerPixel+i]
                =(unsigned char)((value &(0xFF<<(8*i)))>>(8*i));
    }
}


unsigned int image::valueAt(float x, float y) const {
    // compute nearest indices and ratios:
    float pixX = static_cast<float>(Width) * x - 0.5f;
    float pixY = static_cast<float>(Height) * y - 0.5f;
    float weightX = pixX - (int)pixX;
    float weightY = pixY - (int)pixY;

    int x0, x1, y0, y1;
    x0=(int)pixX;
    if(x0<0) x0=0;
    else if(x0>=(int)Width) x0=Width-1;
    x1=int(pixX+1.0f);
    if(x1<0) x1=0;
    else if(x1>=(int)Width) x1=Width-1;
    y0=(int)pixY;
    if(y0<0) y0=0;
    else if(y0>=(int)Height) y0=Height-1;
    y1=int(pixY+1.0f);
    if(y1<0) y1=0;
    else if(y1>=(int)Height) y1=Height-1;
    // cout << "x0:" << x0 << " x1:" << x1 << " y0:" << y0 << " y1:" << y1 << endl;
    // cout << "p00:" << pixel(x0,y0) << " p10:" << pixel(x1,y0) << " p01:" << pixel(x0,y1) << " p11:" << pixel(x1,y1) << endl;

    unsigned int result=0;
    for(unsigned int i=0; i<BytesPerPixel; i++) {
        unsigned int mask=0xFF << (8*i);
        double p00=(pixel(x0,y0)&mask)>>(8*i);
        double p01=(pixel(x0,y1)&mask)>>(8*i);
        double p10=(pixel(x1,y0)&mask)>>(8*i);
        double p11=(pixel(x1,y1)&mask)>>(8*i);
        //cout << "\tp00:" << p00 << " p10:" << p10 << " p01:" << p01 << " p11:" << p11 << endl;
        result+=(unsigned int)((1.0-weightX)*(1.0-weightY)*double(p00)
                               +weightX*(1.0-weightY)*double(p10)
                               +(1.0-weightX)*weightY*double(p01)
                               +weightX*weightY*double(p11))<< (8*i);
    }
    return result;
}

void image::rgb2gray() {
    if(BytesPerPixel<3) return; // image is already grayscale
    // allocate memory for new  image data:
    unsigned char * data = new unsigned char[Width * Height];
    if( data == NULL ) return;

    // copy old image Data to new image data:
    for(unsigned int y=0; y<Height; y++) for(unsigned int x=0; x<Width; x++) // factors NOT correct!
        data[(Width*y)+x]=(unsigned char)(0.212671*(float)Data[((Width*y)+x)*BytesPerPixel]
                                         +0.715160*(float)Data[((Width*y)+x)*BytesPerPixel+1]
                                         +0.072169*(float)Data[((Width*y)+x)*BytesPerPixel+2]+0.5);

    delete [] Data;  // free memory for old image data (not needed anymore)
    Data = data; // set pointer to new image data
    BytesPerPixel=1;
}

void image::resize(unsigned int sizeX, unsigned int sizeY) {
    if((sizeX==Width)&&(sizeY==Height)) return;
    image tmpImg(*this);

    Width         = sizeX;
    Height        = sizeY;
    if( Data != NULL ) delete [] Data; // cleanup
    Data=NULL;
    unsigned int size = Width * Height * BytesPerPixel;
    Data = new unsigned char [size]; // allocate memory for image data
    if( Data == NULL ) {
        cerr << "ve::image::resize(" << sizeX << "," << sizeY
            << ") ERROR: could not allocate image memory.\n";
        Width=Height=BytesPerPixel=0;
        return;
    }
    for(unsigned int x=0; x<Width; x++)
        for(unsigned int y=0; y<Height; y++) {
            //cout << "(" << (float(x)+0.5f)/Width << "|" << (float(y)+0.5f)/Height << "):" << tmpImg.valueAt((float(x)+0.5f)/Width,(float(y)+0.5f)/Height) << endl;
            pixel(x,y,tmpImg.valueAt((float(x)+0.5f)/Width,(float(y)+0.5f)/Height));
        }
}


int image::save(const string & filename) const {
    // create tga header:
    unsigned char hdr[18];
    hdr [0] = 0;  // no id field
    hdr [1] = 0;  // no colormap
    hdr [2] = (BytesPerPixel==1) ? 3 : 2; // either RGB or gray uncompreesd

    hdr [3] = 0;  // color map details, ignored.
    hdr [4] = 0;
    hdr [5] = 0;
    hdr [6] = 0;
    hdr [7] = 0;

    hdr [8] = 0; // x origin
    hdr [9] = 0;
    hdr[10] = 0; // y origin
    hdr[11] = 0;
    hdr[12] = Width & 0x00FF; // image width
    hdr[13] =(Width & 0xFF00) / 256;
    hdr[14] = Height& 0x00FF; // image height
    hdr[15] =(Height& 0xFF00) / 256;
    hdr[16] = BytesPerPixel*8; // pixel depth (8,24,32)
    hdr[17] = 0; // image descriptor byte. if bit5 is 0, origin is lower left, otherwise upper left

#ifdef __sgi
    ofstream file(filename.c_str(), std::ios::out );
#else
    ofstream file(filename.c_str(), ios::out|ios::binary );
#endif
    if (!file.good()) {
        cerr << "ERROR ve::image::save(): " << filename.c_str() << " write file error!"<< endl;
        return 1;
    }
    unsigned int i;
    file.write((const char *)hdr,18); // write header
    switch(BytesPerPixel) { // write pixel data:
    default: // gray
        file.write((const char *)Data,Height*Width);
        break;
    case 3:  // rgb
        for(i=0; i<Height*Width; i++) {
            file << Data[i*3+2];
            file << Data[i*3+1];
            file << Data[i*3+0];
        }
        break;
    case 4:  // rgba
        for(i=0; i<Height*Width; i++) {
            file << Data[i*4+2];
            file << Data[i*4+1];
            file << Data[i*4+0];
            file << Data[i*4+3];
        }
    }
    file.close();
    return 0;
}

int image::read(const std::string & filename) {
    // first test file type:
    string suffix=filename.substr(filename.rfind('.')+1);

    if((suffix=="BMP")||(suffix=="bmp"))
        return readBmp(filename);

    FILE *fp;
    if ((fp = fileIo::open(filename, "rb")) == NULL) { // open the file
        cerr << "ve::image::constructor ERROR: open " << filename << " failed.\n";
        return 1;
    }
    int res=1;
    if((suffix=="PNG")||(suffix=="png"))
        res=readPng(fp);
    else if((suffix=="JPG")||(suffix=="jpg")||(suffix=="jpeg")||(suffix=="JPEG"))
        res=readJpg(fp);
    else cerr << "ve::image constructor ERROR: unknown filetype " << suffix << ".\n";
    fileIo::close(fp);
    return res;
}


#if defined(_HAVE_LIBPNG) && defined(_HAVE_LIBZ)
int image::readPng(FILE * fp) {
    // setup the PNG data structures:
    png_structp pp = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop info = png_create_info_struct(pp);
    png_init_io(pp, fp); // initialize the PNG read engine

    // get the image dimensions and convert to grayscale or RGB:
    png_read_info(pp, info);
    if (info->color_type == PNG_COLOR_TYPE_PALETTE) png_set_expand(pp);
    if (info->color_type & PNG_COLOR_MASK_COLOR) BytesPerPixel = 3;
    else BytesPerPixel = 1;
    if ((info->color_type & PNG_COLOR_MASK_ALPHA) || info->num_trans)
        BytesPerPixel ++;
    Width  = (unsigned int)(info->width);
    Height = (unsigned int)(info->height);
    if (info->bit_depth < 8) {
        png_set_packing(pp);
        png_set_expand(pp);
    }
    else if (info->bit_depth == 16) png_set_strip_16(pp);

    // handle transparency:
    if (png_get_valid(pp, info, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(pp);

    if(Data) {
        delete [] Data;
        Data=0;
    }
    Data = new unsigned char[Width * Height * BytesPerPixel];
    if(!Data) {
        cerr << "ve::image::readPng() ERROR: could not allocate image memory.\n";
        return 1;
    }

    // allocate pointers:
    png_bytep  *rows = new png_bytep[Height];
    unsigned int i;
    for (i = 0; i < Height; i ++) rows[Height-1-i] = (png_bytep)(Data + i * Width * BytesPerPixel);
    // read the image, handling interlacing as needed:
    for (i = png_set_interlace_handling(pp); i > 0; i --)
        png_read_rows(pp, rows, NULL, Height);
    delete[] rows;

    png_read_end(pp, info);
    png_destroy_read_struct(&pp, &info, NULL);
    return 0;
#else
int image::readPng(FILE * ) {
    cerr << "ve::image::readPng() ERROR: cannot load file without libpng and zlib.\n";
    return 1;
#endif
}

#ifdef _HAVE_LIBJPEG
int image::readJpg(FILE * fp) {
    struct jpeg_decompress_struct	cinfo;		// decompressor info
    struct jpeg_error_mgr		jerr;		// error handler info
    JSAMPROW	                 	row;		// sample row pointer

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, fp);
    jpeg_read_header(&cinfo, 1);

    cinfo.quantize_colors      = (boolean)FALSE;
    cinfo.out_color_space      = JCS_RGB;
    cinfo.out_color_components = 3;
    cinfo.output_components    = 3;
    jpeg_calc_output_dimensions(&cinfo);
    Width=cinfo.output_width;
    Height=cinfo.output_height;
    BytesPerPixel=cinfo.output_components;

    if(Data) {
        delete [] Data;
        Data=0;
    }
    Data = new unsigned char[Width * Height * BytesPerPixel];
    if(!Data) {
        cerr << "ve::image::readJpg() ERROR: could not allocate image memory.\n";
        return 1;
    }

    jpeg_start_decompress(&cinfo);
    while (cinfo.output_scanline < cinfo.output_height) {
        row = (JSAMPROW)(Data +  Width * Height * BytesPerPixel -
                         (cinfo.output_scanline+1) * cinfo.output_width *
                         cinfo.output_components);
        jpeg_read_scanlines(&cinfo, &row, (JDIMENSION)1);
    }

    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return 0;
#else
int image::readJpg(FILE * ) {
    cerr << "ve::image::readJpg() ERROR: cannot load file without libjpeg.\n";
    return 1;
#endif // _HAVE_LIBJPEG
}

#ifdef _HAVE_SDL
int image::readBmp(const string & fileName) {
    SDL_Surface *pBitmap;

    pBitmap = SDL_LoadBMP(fileName.c_str());
    if(pBitmap == NULL) {
        cerr << "ve::image::readBmp() ERROR : Failed loading " << fileName << " : " << SDL_GetError() << endl;
        return 1;
    }

    Width  = pBitmap -> w;
    Height = pBitmap -> h;
    BytesPerPixel = pBitmap -> format -> BytesPerPixel;

    if(Data) {
        delete [] Data;
        Data=0;
    }
    Data = new unsigned char[Width * Height * BytesPerPixel];
    if(!Data) {
        cerr << "ve::image::readBmp() ERROR: could not allocate image memory.\n";
        return 1;
    }
    memcpy(Data,pBitmap -> pixels,Width * Height * BytesPerPixel);

    // swap rows:
    for(unsigned int i = 0 ; i < (Height / 2) ; ++i )
        for(unsigned int j = 0 ; j < Width * BytesPerPixel; j += BytesPerPixel )
            for(unsigned int k = 0; k < BytesPerPixel; ++k) {
                unsigned char & a=Data[ (i * Width * BytesPerPixel) + j + k];
                unsigned char & b=Data[ ( (Height - i - 1) * Width * BytesPerPixel ) + j + k];
                unsigned char temp = a;
                a    = b;
                b    = temp;
            }
    // swap BGR(A) to RGB(A):
    if(BytesPerPixel>2) {
        for(unsigned int i = 0 ; i < Height ; ++i )
            for(unsigned int j = 0 ; j < Width; ++j ) {
                unsigned char & a=Data[(i * Width + j)*BytesPerPixel];
                unsigned char & b=Data[(i * Width + j)*BytesPerPixel+2];
                unsigned char temp = a;
                a    = b;
                b    = temp;
            }
    }
    SDL_FreeSurface(pBitmap);       
    return 0;
#else
int image::readBmp(const string & ) {
    cerr << "ve::image::readBmp() ERROR: cannot load file without libSDL.\n";
    return 1;
#endif
}


std::ostream & operator<<(std::ostream & os, const image & img) {
    os << "image(" << img.w() << '|' << img.h() << '|' << img.bytesPerPixel() << ") [\n";
    for(unsigned int y=0; y<img.h(); y++) {
        for(unsigned int x=0; x<img.w(); x++)
            os << '\t' << img.pixel(x,y);
        os << '\n';
    }
    os << "]\n";
    return os;
}


//--- class ve::glTexture ------------------------------------------ /*fold00*/
// (c) 2002 by Gerald.Franz@tuebingen.mpg.de

std::vector<glTexture> glTexture::table;
std::vector<string> glTexture::texPath;
bool glTexture::m_bCompressTextures = false;

void glTexture::enableTextureCompression(bool enable)
{
  if(enable == true)
  {
    string version = (char*)glGetString(GL_VERSION);
    int major = atoi(version.substr(0).c_str());
    int minor = atoi(version.substr(2).c_str());
    //all gl versions higher than 1.2 support compressed textures
    if((major == 1 && minor>=3) || major == 2)
      m_bCompressTextures = true;
    //else check for texture compression extension
    else
    {
      if(hasGlExtension("GL_ARB_texture_compression")) // Check for texture compression extension
        m_bCompressTextures = true;
      else
      {
        m_bCompressTextures = false;
        cerr << "glTexture : Graphics card doesn't support compressed textures, loading uncompressed images." << endl;
      }
    }
  }
  else
    m_bCompressTextures = false;
}



int glTexture::load(const string & name, unsigned int & id, int & bytesPerPixel, int & width, int & height, bool isRepeated) {
    unsigned int i;
    // first look whether texture is already loaded:
    for(i=0; i<glTexture::table.size(); i++)
        if(glTexture::table[i].url==name) {
            id        = glTexture::table[i].id;
            bytesPerPixel = glTexture::table[i].bytesPerPixel;
            width     = glTexture::table[i].width;
            height    = glTexture::table[i].height;
            glTexture::table[i].nRefs++;
            return 0;
        }

     // check existence, if not try search path:
    string fileName=name;
    if(!fileIo::fileExist(fileName)) {
        for(i=0; i<texPath.size(); i++) {
            fileName=texPath[i]+'/'+name;
            if(fileIo::fileExist(fileName)) break;
        }
    }

    // read image from file:
    image img(fileName);
    if(!img.data()) {
        cerr << "ve::glTexture::load() ERROR: loading of " << fileName.c_str() << " failed.\n";
        return 1;
    }
    load(name,id,img,isRepeated);

    width     = img.w();
    height    = img.h();
    bytesPerPixel = img.bytesPerPixel();
    return 0;
}

int glTexture::load(const string & name, unsigned int & id, const image & img, bool isRepeated) {
    unsigned int i;
    // first look whether texture is already loaded:
    for(i=0; i<glTexture::table.size(); i++)
        if(glTexture::table[i].url==name) {
            id        = glTexture::table[i].id;
            glTexture::table[i].nRefs++;
            return 0;
        }

    // rescale image to a suitable size for a texture:
    int maxSize;
    glGetIntegerv(GL_MAX_TEXTURE_SIZE,&maxSize);
    unsigned int newW=1;
    while((newW<img.w())&&(newW<(unsigned int)maxSize)) newW<<=1; // calculate next larger 2^N width
    unsigned int newH=1;
    while((newH<img.h())&&(newH<(unsigned int)maxSize)) newH<<=1; // calculate next larger 2^N width
    bool isResized=false;
    image * pImg=(image *)&img;
    if((newW!=img.w())||(newH!=img.h())) {
        pImg=new image(img);
        if((pImg==&img)||(pImg==NULL)) return 1;
        pImg->resize(newW,newH);
        isResized=true;
    }
#ifdef _HAVE_GL
    // now upload texture to OpenGL:
    glGenTextures(1,&id);
    glBindTexture (GL_TEXTURE_2D, id);

    // set unpack alignment to one byte:
    GLint   UnpackAlignment;
    glGetIntegerv( GL_UNPACK_ALIGNMENT, &UnpackAlignment );
    glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );

    int imgFormat=0;
    // interpret BytesPerPixel as an OpenGL format:
    switch( pImg->bytesPerPixel() ) {
    case 1:
        imgFormat = GL_LUMINANCE;
        break;
    case 3:
        imgFormat = GL_RGB;
        break;
    case 4:
        imgFormat = GL_RGBA;
        break;
    default:
        cerr << "ve::glTexture::load() ERROR: cannot interpret bytesPerPixel of " << name.c_str() << ".\n";
        if(isResized) delete pImg;
        return 1;
    }

    if(m_bCompressTextures == true)
    {
      int compressed = 0;
      int internalFormat=0;
      switch(pImg->bytesPerPixel()) {
#ifdef GL_COMPRESSED_RGB
      case 3: internalFormat=GL_COMPRESSED_RGB; break;
#endif
#ifdef GL_COMPRESSED_RGBA
      case 4: internalFormat=GL_COMPRESSED_RGBA; break;
#endif
      default: 
        internalFormat=pImg->bytesPerPixel();
      }


      gluBuild2DMipmaps ( GL_TEXTURE_2D, internalFormat, // upload to texture memory
                       pImg->w(), pImg->h(),(GLenum)imgFormat,
                       GL_UNSIGNED_BYTE, (void*) pImg->data());
      glPixelStorei( GL_UNPACK_ALIGNMENT, UnpackAlignment ); // restore old unpack alignment
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, isRepeated ? GL_REPEAT : GL_CLAMP);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, isRepeated ? GL_REPEAT : GL_CLAMP);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

      //glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_COMPRESSED_ARB, &compressed);
      //if(compressed)
      //{
        //int compressedSize = 0;
        //glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_INTERNAL_FORMAT, &internalFormat);
        //if (internalFormat == GL_COMPRESSED_RGB_S3TC_DXT1_EXT)
          //int dududu = 1;
        //glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_COMPRESSED_IMAGE_SIZE_ARB, &compressedSize);
        //cout << "size : " << compressedSize << endl;
        
      //}
    }
    else
    {
      gluBuild2DMipmaps ( GL_TEXTURE_2D, pImg->bytesPerPixel(), // upload to texture memory
                       pImg->w(), pImg->h(),(GLenum)imgFormat,
                       GL_UNSIGNED_BYTE, (void*) pImg->data());
      glPixelStorei( GL_UNPACK_ALIGNMENT, UnpackAlignment ); // restore old unpack alignment

      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, isRepeated ? GL_REPEAT : GL_CLAMP);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, isRepeated ? GL_REPEAT : GL_CLAMP);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    }
#endif
    // register in texture table:
    glTexture tex;
    tex.url=name;
    tex.width     = pImg->w();
    tex.height    = pImg->h();
    tex.bytesPerPixel = pImg->bytesPerPixel();
    tex.repeat    = isRepeated;
    tex.id        = id;
    tex.nRefs     = 1;
    glTexture::table.push_back(tex);
    if(isResized) delete pImg;
    return 0;
}

int glTexture::load(const string & name) {
    // dummy variables:
    int byte, width, height;
    unsigned int texId;
    if(load(name,texId,byte,width,height,true)!=0)
        return -1;
    return (int)texId;
}

void glTexture::del(unsigned int id) {
    for(vector<glTexture>::iterator i=table.begin(); i<table.end(); i++)
        if(i->id==id) {
            table.erase(i);
            break;
        }
#ifdef _HAVE_GL
    glDeleteTextures(1,&id);
#endif
}

void glTexture::clear() {
    for(vector<glTexture>::iterator i=table.begin(); i<table.end(); i++)
#ifdef _HAVE_GL
        glDeleteTextures(1,&i->id);
#endif
    table.clear();
}

int glTexture::grabScreen(const string & fileName, unsigned int screenW, unsigned int screenH) {
#ifdef _HAVE_GL
    unsigned int nBytes = 3 * screenW * screenH;   // compute needed memory
    unsigned char *pPixelData = new unsigned char[nBytes]; // reserve memory

    glReadBuffer(GL_FRONT);
    glReadPixels(0,0,screenW,screenH,GL_RGB,GL_UNSIGNED_BYTE,pPixelData);
    glReadBuffer(GL_BACK);
    image img(pPixelData,screenW,screenH,3);
    img.save(fileName);

    delete [] pPixelData;
    return 0;
#else
    return 1;
#endif
}

void glTexture::addSearchPath(const std::string & path) {
    string s=fileIo::unifyPath(path);
    for(unsigned int i=0; i<texPath.size(); i++)
        if(texPath[i]==s) return;
    texPath.push_back(s);
}


glTexture * glTexture::get(const string & name) {
    for(unsigned int i=0; i<glTexture::table.size(); i++)
        if(glTexture::table[i].url==name) return &table[i];
    return NULL;
}


//--- cvs history log : -------------------------------------------- /*FOLD00*/
/*
 * $Log: veImage.cpp,v $
 * Revision 2.4  2005/01/03 09:42:25  gf
 * XPM interpreter abilities added
 *
 * Revision 2.3  2004/12/06 11:17:13  gf
 * texture compression constants are avoided if not available
 *
 * Revision 2.2  2004/12/01 13:14:51  weyel
 * -include GL/glext.h
 * -OpenGL version checking before enabling texture compression
 *
 * Revision 2.1  2004/12/01 10:11:23  weyel
 * added load-time texture compression
 *
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 */
