#include "veConfig.h"

#ifdef _HAVE_ACE
#  include "ace/OS.h"
   static char *rcsid = "$Id: veUtils.cpp,v 2.0 2004/11/01 12:40:13 gf Exp $";
#  include "veDebug.h"
   DO_SOME_DEBUGGING;
#else
#  if defined (__GNUC__) && !defined (WIN32)
#    include <netinet/in.h>
#    include <sys/time.h>
#  elif defined (_MSC_VER)
#    include <time.h>
#  endif
#  ifdef _HAVE_SDL
#    include <SDL.h>
#  endif
#endif

#if !defined (WIN32)
#  include <sys/time.h>
#  include <unistd.h>
#endif

#include <sys/timeb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <algorithm>
#include <cmath>

#include "veStd.h"
#include "veTypes.h"
#include "veUtils.h"
#include "veMath.h"
#include "veStrUtils.h"

using namespace std;
using namespace ve;

//--- various functions and definitions ---------------------------- /*fold00*/

short ve::net2hosts (const char *buffer) {
  int len = sizeof(short);
  short result;
  memcpy((void*)(&result), buffer, len);
  byteSwap((char*)(&result), len);
  return result;
}

long ve::net2hostl (const char *buffer) {
  int len = sizeof(long);
  long result;
  memcpy((void*)(&result), buffer, len);
  byteSwap((char*)(&result), len);
  return result;
}

int ve::host2nets (char *buffer, short number) {
  int len = sizeof(short);
  memcpy(buffer, (void*)(&number), len);
  byteSwap(buffer, len);
  return len;
}

int ve::host2netl (char *buffer, long number) {
  int len = sizeof(long);
  memcpy(buffer, (void*)(&number), len);
  byteSwap(buffer, len);
  return len;
}

float ve::net2hostf (const char *buffer) {
  int len = sizeof(float);
  float result;
  memcpy((void*)(&result), buffer, len);
  byteSwap((char*)(&result), len);
  return result;
};

int ve::host2netf (char *buffer, float number) {
  int len = sizeof(float);
  memcpy(buffer, (void*)&number, len);
  byteSwap(buffer, len);
  return len;
};

double ve::net2hostd (const char *buffer) {
  int len = sizeof(double);
  double result;
  memcpy((double*)(&result), buffer, len);
  byteSwap((char*)(&result), len);
  return result;
};

int ve::host2netd (char *buffer, double number) {
  int len = sizeof(double);
  memcpy(buffer, (void*)&number, len);
  byteSwap(buffer, len);
  return len;
};

void ve::byteSwap(char *b, int n)
{
   register int i = 0;
   register int j = n-1;
   while (i<j)
   {
     char test = b[i];
     std::swap(b[i], b[j]);
     if(b[j] != test)
     {
       cout << "????" << endl << "orig : " << test << ", after conv : " << b[j] << endl;
     }
     i++, j--;
   }
}


//--- timer class -------------------------------------------------- /*fold00*/
namespace ve {

double time::stamp()
{
#if defined (WIN32)
  __int64 freq, count;
  //check for high resolution timer
  if(QueryPerformanceFrequency((LARGE_INTEGER*)&freq)) {
    //high resolution timer available - use it!
    double dResolution = 1.0 / (double)freq;
    QueryPerformanceCounter((LARGE_INTEGER*)&count);
    double dSeconds = (double)count * dResolution;
    static long secsFirstCall = (long)dSeconds;
    return dSeconds - (double)secsFirstCall;
  }
  else
  {
    struct timeb tp;
    ftime(&tp);
    return double(tp.time)+0.001*double(tp.millitm);
  }
#else
  static struct timeval time;
  gettimeofday(&time, 0);
  static long secsFirstCall=time.tv_sec;
  return (double)(time.tv_sec-secsFirstCall) + (double)time.tv_usec/(1000.0*1000.0);
#endif
}

string time::date() {
    time_t rawTime;
#if defined WIN32 || defined __WIN32__
    ctime(&rawTime);
#else
    std::time(&rawTime);
#endif
    tm *now =gmtime(&rawTime);

    string ret="";
    string s;

    s=i2s(now->tm_year-100);
    if(s.size()<2)s="0"+s;
    ret+=s;
    s=i2s(now->tm_mon+1);
    if(s.size()<2)s="0"+s;
    ret+=s;
    s=i2s(now->tm_mday);
    if(s.size()<2)s="0"+s;
    ret+=s;
    ret+='_';
    s=i2s(now->tm_hour);
    if(s.size()<2)s="0"+s;
    ret+=s;
    s=i2s(now->tm_min);
    if(s.size()<2)s="0"+s;
    ret+=s;
    s=i2s(now->tm_sec);
    if(s.size()<2)s="0"+s;
    ret+=s;

    return ret;
}

void time::sleep(double sec) {
#ifdef _HAVE_ACE
    ACE_Time_Value length = 0;
    // set sec and usec
    length.set(veRound(floor(sec)),veRound((sec-floor(sec))*1000000.0));
    talk2(6,"should sleep for %i sec and %i msec now",length.sec(),length.msec());
    ACE_OS::sleep(length);
#else
#  ifdef _HAVE_SDL
    if(!SDL_WasInit(SDL_INIT_EVERYTHING)) SDL_Init(SDL_INIT_TIMER);
    else if(!SDL_WasInit(SDL_INIT_TIMER)) SDL_InitSubSystem(SDL_INIT_TIMER);
    SDL_Delay((unsigned int)(sec*1000.0));
#  endif
#endif
}

} // namespace ve

//--- struct zipHeader --------------------------------------------- /*fold00*/

/// describes a zipped file header
typedef struct zipHeader_s {
    unsigned long ident;
    unsigned short version;
    unsigned short flags;
    unsigned short compression;
    unsigned short modtime;
    unsigned short moddate;
    unsigned short crc32_1;
    unsigned short crc32_2;
    unsigned short compressedSize_1;
    unsigned short compressedSize_2;
    unsigned short uncompressedSize_1;
    unsigned short uncompressedSize_2;
    unsigned short filenameLength;
    unsigned short extraFieldLength;

} zipHeader;

//--- class fileIo ------------------------------------------------- /*fold00*/

FILE * fileIo::zipFile=0;
std::vector<fileInfo> fileIo::zipDir;
unsigned int fileIo::zipFileId=0;


string fileIo::exec(const string & cmdName, const string & cmdArgs, const string & cmdPath) {
#ifdef _MSC_VER
    cerr << "This function is not yet implemented for _MSC_VER-compilers";
    return "";
#else
    string cmd;
#if defined __WIN32__ || defined WIN32
    cmd=replaceAll(cmdPath,"/","\\")+cmdName+".exe";
#else
    cmd=cmdPath+cmdName;
#endif
    cmd+=' '+cmdArgs;
    FILE *myPipe=NULL;
    myPipe=popen(cmd.c_str(),"r");
    if(!myPipe) return "";

    string returnStr;
    char buffer[256];
    while(fgets(buffer,256,myPipe)) returnStr+=buffer;

    pclose(myPipe);
    return returnStr;
#endif //_MSC_VER
}


bool fileIo::wildcardMatch(const std::string & fname, const std::string & filter) {
    if(!filter.size()) return true;
    bool openStart=filter[0]=='*';
    bool openEnd=filter[filter.size()-1]=='*';
    vector<string> parts;
    split(filter,parts,"*");
    if(!parts.size()) return true;

    unsigned int currPos=0;
    unsigned int matchPos;
    for(unsigned int i = 0; i < static_cast<unsigned int>(parts.size()); i++) {
        matchPos=static_cast<unsigned int>(fname.substr(currPos).find(parts[i]));
        if(matchPos>fname.size()) return false; // part not included
        if(!i&&!openStart&&matchPos) return false; // parts[0] has to be at the start
        currPos+=matchPos+parts[i].size();
        if((i==parts.size()-1)&&!openEnd&&currPos<fname.size()) return false;
    }
    return true;
}


int fileIo::dir(vector<std::string> & target, const std::string & path, const std::string & filter) {
#ifdef _MSC_VER
    WIN32_FIND_DATA findFileData;
    HANDLE hFind;

    string tmp = path;
    tmp.append("\\*.*");
    hFind = FindFirstFile(tmp.c_str(), &findFileData);
    if (hFind == INVALID_HANDLE_VALUE)
    {
        cerr << "Invalid File Handle.";
        return 1;
    }

    while(FindNextFile(hFind, &findFileData))
    {
        if(findFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
        {
            string s(findFileData.cFileName);
            if((s==".")||(s=="..")) continue;
            if(wildcardMatch(s,filter)) target.push_back(s);
        }
    }
    bool bClosed;
    if(bClosed = FindClose(hFind) == false)
    {
        cerr << "Unable to close file handle.";
        return 1;
    }
#else
    DIR *dir;
    struct dirent *ent;

    if ((dir = opendir(path.c_str())) == NULL) {
        cerr << "ERROR fileIo::dir: unable to open directory " << path << endl;
        return 1;
    }
    while ((ent = readdir(dir)) != NULL) {
        string s(ent->d_name);
        if((s==".")||(s=="..")) continue;
        if(wildcardMatch(s,filter)) target.push_back(s);
    }
    if (closedir(dir) != 0) {
        cerr << "ERROR fileIo::dir: unable to close directory " << path << endl;
        return 1;
    }
#endif
    sort(target.begin(),target.end());
    return 0;
}

bool fileIo::isDir(const std::string & path) {
#ifdef _MSC_VER
    struct _stat buf;
    if ( _stat(path.c_str(),&buf) == 0 )
    {
      if(buf.st_mode & _S_IFDIR)
        return true;
      else
        return false;
    }
#else
    struct stat buf ;
    if ( stat(path.c_str(),&buf) == 0 )
        return buf.st_mode & S_IFDIR;
#endif
    return false ;
}

int fileIo::openZip(const std::string & path) {
  string s = unifyPath(path); 
  if(zipFile) closeZip();
  zipFile = fopen(s.c_str(), "rb");
  if (!zipFile) return 1;
  readZipDir(zipFile,zipDir);
  zipFileId = static_cast<unsigned int>(zipDir.size()); // beyond existing files means not active
  return 0;
}

int fileIo::closeZip() {
    if(!zipFile) return 1;
    zipDir.clear();
    fclose(zipFile);
    zipFile=0;
    zipFileId=0;
    return 0;
}

FILE* fileIo::open(const std::string & path, const char *mode) {
  string s = unifyPath(path); 
  if(zipFile) if((string(mode)=="r")||(string(mode)=="rb"))
    for(unsigned int i=0; i<zipDir.size(); i++)
      if(zipDir[i].name==s) {
        fseek(zipFile,zipDir[i].offset,SEEK_SET);
        zipFileId=i;
        return zipFile;
      }
  return fopen(s.c_str(),mode);
}

int fileIo::close(FILE* stream) {
    if(stream == zipFile) {
        zipFileId = static_cast<unsigned int>(zipDir.size());
        return 0;
    }
    return fclose(stream);
}

int fileIo::eof(FILE* stream) {
    if((stream==zipFile)&&(zipFileId<zipDir.size())) {
        if((unsigned int)(ftell(stream))<zipDir[zipFileId].offset+zipDir[zipFileId].size)
            return 0;
        return 1;
    }
    return feof(stream);
}

unsigned int fileIo::getline(FILE* fp, std::string & s) {
    s.erase();
    const unsigned int bufSz=4096;
    char chbuf[bufSz];
    chbuf[0]=0;
    fgets(chbuf,bufSz,fp);
    if(strlen(chbuf)) {
        s+=chbuf;
        while((s[s.size()-1]!='\n')&&!feof(fp)) {
            fgets(chbuf,bufSz,fp);
            if(strlen(chbuf)) s+=chbuf;
        }
        if(s[s.size()-1]=='\n') s.erase(s.size()-1,1);
    }
    return static_cast<unsigned int>(s.size());
}

bool fileIo::fileExist(const string & filename) {
    if(zipFile) for(unsigned int i=0; i<zipDir.size(); i++)
        if(zipDir[i].name==filename) return true;
    ifstream file(filename.c_str(), ios::in);
    return file.good();
}

unsigned int fileIo::fileSize(FILE* fp) {
    if((fp==zipFile)&&(zipFileId<zipDir.size()))
        return zipDir[zipFileId].size;
    long currPos=ftell(fp);
    fseek( fp, 0, SEEK_END);
    unsigned int size=ftell(fp);
    fseek( fp, currPos, SEEK_SET);
    return size;
}

int fileIo::readZipDir(FILE * fp, std::vector<fileInfo> & vZip) {
    zipHeader pakHeader;
    bool firstTime=true;
    fseek( fp, 0, SEEK_SET);
    while(!feof(fp)) {
        fread(&pakHeader, 30, 1, fp); //get the local header of the file.

        // check if finished with pak file item collection:
        if (pakHeader.ident == ZIP_DIR_ID) {
            fseek( fp, 0, SEEK_SET);
            return 0;
        }
        // check if header signature is correct for the first item.
        if ((pakHeader.ident != ZIP_HEADER_ID) && firstTime) {
            cerr << "file is not a zipfile" << endl;
            return 1;
        }
        firstTime=false;

        fileInfo zf;

        zf.isCompressed=false;
        // check if compression is used or any flags are set.
        if ((pakHeader.compression != 0) || (pakHeader.flags != 0))
            zf.isCompressed=true;
        // get length of data area:
        zf.size = (unsigned int)pakHeader.compressedSize_1+65536*(unsigned int)pakHeader.compressedSize_2;
        // get the data areas filename and add \0 to the end:
        char *fileName = new char[pakHeader.filenameLength+1];
        fread( fileName, pakHeader.filenameLength, 1, fp);
        fileName[pakHeader.filenameLength] = 0;
        zf.name=fileName;
        delete[] fileName;
        // get the offset of the data area:
        zf.offset = (ftell(fp) + pakHeader.extraFieldLength);

        vZip.push_back(zf);
        // goto next header:
        fseek( fp, (zf.size + zf.offset), SEEK_SET);
    }
    return 0;
}

string fileIo::unifyPath(const string & source)
{
  string s(source);
  //turn all slashes into unix notation because windows doesn't care...
  s = replaceAll(s, "\\", "/");
#ifdef WIN32
  //...except if you want to access files over the net like \\uni\home\... the first two
  //slashes than need to be "\\" instead of "//".
  s = replaceAll(s, "//", "\\\\");
  //then make sure there are no two slashes next to each other
  s = replaceAll(s, "//", "/");
#else
  //on Linux, make sure there are no two slashes next to each other
  s = replaceAll(s, "//", "/");
#endif
  return s;
}

unsigned int fileIo::mime(const std::string & filename) {
    string suffix=filename.substr(filename.rfind('.')+1);
    if((suffix=="BMP")||(suffix=="bmp"))
        return MIME_IMAGE_BMP;
    else if((suffix=="PNG")||(suffix=="png"))
        return MIME_IMAGE_PNG;
    else if((suffix=="JPG")||(suffix=="jpg")||(suffix=="jpeg")||(suffix=="JPEG"))
        return MIME_IMAGE_JPEG;
    else if((suffix=="SVG")||(suffix=="svg"))
        return MIME_IMAGE_SVG;
    else if((suffix=="TXT")||(suffix=="txt"))
        return MIME_TEXT_PLAIN;
    else if((suffix=="WRL")||(suffix=="wrl"))
        return MIME_MODEL_VRML;
    else if((suffix=="x3D")||(suffix=="x3d"))
        return MIME_MODEL_X3D;
    else if((suffix=="3DS")||(suffix=="3ds"))
        return MIME_APPLICATION_3DS;
    else if((suffix=="WAV")||(suffix=="wav"))
        return MIME_AUDIO_WAV;
    else if((suffix=="TXF")||(suffix=="txf"))
        return MIME_FONT_TXF;
    return MIME_NONE;
}

string fileIo::cwd() {
    char buf[1024];
#ifdef _MSC_VER
    return unifyPath(_getcwd ( buf, 1023 ));
#else
    return unifyPath(getcwd ( buf, 1023 ));
#endif
}


//--- class cmdLine ------------------------------------------------ /*fold00*/

vector<string> cmdLine::vArg;
vector<string> cmdLine::vOpt;
string cmdLine::ownDir="";
string cmdLine::ownCmd="";
bool cmdLine::isParsed=false;

string cmdLine::name_="";
string cmdLine::author_="";
string cmdLine::version_="";
string cmdLine::date_="";
string cmdLine::shortDescr_="";
string cmdLine::descr_="";
string cmdLine::usage_="";

void cmdLine::interpret( int argc, char **argv, bool optsAsArgs ) {
    if(isParsed) return;
    isParsed=true;
#if defined __WIN32__ || defined WIN32
    char delimiter='\\';
#else
    char delimiter='/';
#endif
    string arg0=argv[0];
    ownDir=arg0.substr(0,arg0.rfind(delimiter)+1);
    ownCmd=arg0.substr(arg0.rfind(delimiter)+1);

    for(int i=1; i<argc; i++) { // parse args and options
        if(optsAsArgs) {
            vArg.push_back(argv[i]);
            continue;
        }
        if((strcmp(argv[i],"--help")==0)||(strcmp(argv[i],"-h")==0)) {
            if(usage_.size()) {
                cerr << help() << endl;
                exit(1);
            }
        }
        if(argv[i][0]=='-') vOpt.push_back(&argv[i][1]);
        else vArg.push_back(argv[i]);
    }
    if(name_=="") name_=ownCmd;
}

bool cmdLine::opt(char c) {
    for(unsigned int i=0; i<vOpt.size(); i++)
        if(vOpt[i][0]==c) return true;
    return false;
}

string cmdLine::optArg(char c) {
    for(unsigned int i=0; i<vOpt.size(); i++)
        if(vOpt[i][0]==c) return vOpt[i].substr(1);
    return "";
}

const string cmdLine::help() {
    string s="\n"+name_ +" - " + shortDescr_
        +"\n\nversion "+version_+" (c) "+date_+" by "+author_
        +"\n\nusage: "+cmd()+" [-h(elp)] "+usage_+"\n";
    if(descr_!="") s+="\n"+descr_+"\n";
    return s;
}


//--- history ------------------------------------------------------ /*FOLD00*/
/*
 * $Log: veUtils.cpp,v $
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.64  2004/11/01 10:50:23  gf
 * - cleanup dependencies
 * - ovlLabel now complete
 *
 * Revision 1.63  2004/10/29 09:39:36  weyel
 * fixed a WIN32 specific error
 *
 * Revision 1.62  2004/10/28 14:55:57  gf
 * small bugfix and renaming of ve::timer to ve::time
 *
 * Revision 1.61  2004/10/28 13:29:01  weyel
 * - timer class added
 * - bugfixing in network connection handling
 *
 * Revision 1.60  2004/10/27 12:01:10  gf
 * timeStamp is now initialized to zero seconds on first call
 *
 * Revision 1.59  2004/10/18 11:10:14  gf
 * - mime type for txf fonts added
 * - framework for handling multiple fonts added, not completely implemented
 * - dataContainer::type() now changeable after construction
 *
 * Revision 1.58  2004/10/15 15:26:33  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.57  2004/10/04 09:38:11  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.56  2004/09/28 12:20:37  gf
 * fileIo::mime() method added
 *
 * Revision 1.55  2004/09/24 16:08:59  gf
 * - cleanup of unused and old methods
 * - small bugfixes in the network device
 * -><F2> final adjustments to publish version 1.0.beta1
 *
 * Revision 1.54  2004/09/24 10:25:01  weyel
 * - interfaces of ACE networkDevice and BSD networkDevice unified
 * - documentation updated
 *
 * Revision 1.53  2004/09/15 15:08:57  weyel
 * fixed some errors
 *
 * Revision 1.52  2004/09/15 14:52:48  weyel
 * - network constants now in namespace ve
 * - fixed some VC compiler warnings
 * - Linux timestamp now always uses gettimeofday()
 *
 * Revision 1.51  2004/09/14 15:37:48  weyel
 * - network header files now included in veUtils.h
 *
 * Revision 1.50  2004/09/14 12:35:07  weyel
 * - veDeviceNetworkUDP.cpp and .h removed, now in veDeviceNetwork.*
 * - class deviceNetworkUDP renamed to deviceNetwork, depending on
 * _HAVE_ACE either the old or new one is used
 *
 * Revision 1.49  2004/09/13 08:31:24  gf
 * fileIo::cwd() methods (get current working directory) added
 *
 * Revision 1.48  2004/09/10 09:56:11  gf
 * cross dependencies solved
 *
 * Revision 1.47  2004/09/08 09:31:51  weyel
 * -veDeviceNetworkUDP optimized
 * -veLib now compiles without ACE on windows and linux
 *
 * Revision 1.46  2004/08/22 20:07:38  gf
 * order of command line parsing functions is now more flexible
 *
 * Revision 1.45  2004/08/09 09:30:16  gf
 * use of const reference instead of local copy
 *
 * Revision 1.44  2004/08/03 12:56:08  weyel
 * - fileIo::unifyPath() added do deal with slashes in filepaths
 * - collisionTriangle::altitude() added, returns height over a surface
 * - slight adaptations in some other files
 *
 * Revision 1.43  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.42  2004/07/01 15:25:27  gf
 * handling of filename filters (e.g., *.cpp) for fileio::dir() improved
 *
 * Revision 1.41  2004/06/30 09:06:46  franck
 * All the ntohX and htonX functions have been rewritten. They now use the sizeof()
 * function instead of hardcoded data length, and they write to/read from the buffer
 * themselves rather than return values. Overall, this is more elegant, safier and
 * possibly faster. Conversion functions for double variables have been added so that
 * the new timeStamp format can be sent accross the network.
 *
 * Revision 1.40  2004/04/27 13:43:47  weyel
 * - fixed a bug in host2netf and net2hostf
 * - floats now coverted correctly for network transfer
 * - changed include order in some files (MS VC wants windows.h in front of
 *   any GL-includings)
 *
 * Revision 1.39  2004/04/13 11:37:29  weyel
 * - clock sync for network communication added
 * - motion prediction on base of synchronized clock
 * - font size for ovlText now read from ini-file
 *
 * Revision 1.37  2004/03/22 19:45:25  gf
 * veIo and veUtils reunited in veUtils
 *
 * Revision 1.36  2004/03/04 14:26:07  gf
 * final attempt to fix the time2string bug - next time the function will be removed...
 *
 * Revision 1.35  2004/03/04 14:00:21  gf
 * memory bug in time2string fixed
 *
 * Revision 1.34  2004/03/03 15:08:27  gf
 * time2string() now works hopefully
 *
 * Revision 1.33  2004/02/24 13:33:33  gf
 * - ve::vec (veMath.h) renamed to ve::vec3f
 * - VEEC_XYZ (veTypes.h) error codes renamed to ve::ERR_XYZ
 *
 * Revision 1.32  2004/01/21 16:43:36  gf
 * - ve::motionXXX framework remodeled. Is now multi-user capable
 * - lippng, libjpeg, zlib now included as standard
 *
 * Revision 1.31  2004/01/11 21:39:20  gf
 * - talk.h renamed to veDebug.h
 * - veDevice moved to namespace ve and renamed to ve::device
 *
 * Revision 1.30  2004/01/09 10:26:14  weyel
 * major changes and interface simplifications to veData and veDevice, included SDL and removed old input devices and other unused classes. Please watch out for errors and report bugs immediatly.
 *
 * Revision 1.29  2003/12/12 22:11:54  gf
 * any dependencies on GLFW removed. Slight improvements for the libSDL subsystem.
 *
 * Revision 1.28  2003/12/12 16:39:22  gf
 * just small changes, leading to hours of unproductive work: definitions
 * ubited in veTypes.h some #defines moved to const unsigned int
 *
 * Revision 1.27  2003/12/09 13:36:11  gf
 * timing methods renamed from prefixes to suffixes
 *
 * Revision 1.26  2003/12/02 16:09:20  gf
 * _glfwInitialized is no tested before calling glfw methods
 *
 * Revision 1.25  2003/12/01 17:05:06  gf
 * adaptions to major veUtils revision:
 * - error methods moved to talk
 * - time functions unified and improved
 *
 * Revision 1.24  2003/11/17 15:44:40  gf
 * random functions moved to veRnd (in veMath.h)
 *
 * Revision 1.23  2003/10/27 13:59:03  weyel
 * reorganized talklevels
 *
 * Revision 1.22  2003/09/15 10:13:25  weyel
 * replaced itoa in time2String
 *
 * Revision 1.21  2003/08/26 14:47:58  weyel
 * added time2String function
 *
 * Revision 1.20  2003/08/15 15:28:43  weyel
 * veGetHighTime now uses Windows high resolution
 * timer if available
 *
 * Revision 1.19  2003/07/25 10:57:15  mvdh
 * random methods from veMath transfered
 *
 * Revision 1.18  2003/07/02 09:14:06  weyel
 * now using the veConfig switches (e.g. #if  _HAVE_ACE instead of
 * #if defined (HAVEACE).
 */
