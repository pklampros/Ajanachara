#include "veStd.h"
# include <GL/gl.h>
# include <GL/glu.h>

# include "veImage.h"
# include "veStrUtils.h"
# include "veGeoObj.h"
# include "veIo3ds.h"

using namespace std;
using namespace ve;

//--- internal 3ds data structures --------------------------------- /*fold00*/

_materialInfo::_materialInfo() {
    matName[0]=0;
    fileName[0]=0;
    color[0]=color[1]=color[2]=255;
    opacity=1.0f;
}

/// this struct holds a 3ds chunk info
struct _chunk {
    /// the chunk's ID
    unsigned short int ID;
    /// the length of a chunk
    unsigned int length;
    /// the amount of bytes read within that chunk
    unsigned int bytesRead;
};

//--- 3ds chunk ids and names -------------------------------------- /*fold00*/
//>------ Primary Chunk, at the beginning of each file
#define PRIMARY       0x4D4D

#define CHUNK_PERCENT_INT   0x0030
#define CHUNK_PERCENT_FLOAT 0x0031

//>------ Main Chunks
#define OBJECTINFO    0x3D3D                // This gives the version of the mesh and is found right before the material and object information
#define VERSION       0x0002                // This gives the version of the .3ds file
#define EDITKEYFRAME  0xB000                // This is the header for all of the key frame info

//>------ sub defines of OBJECTINFO
#define MATERIAL      0xAFFF                // This stored the texture info
#define OBJECT        0x4000                // This stores the faces, vertices, etc...

//>------ sub defines of MATERIAL
#define MATNAME       0xA000                // This holds the material name
#define MATDIFFUSE    0xA020                // This holds the color of the object/material
#define MATTRANSP     0xA050                // This holds the transparency of the material
#define MATMAP        0xA200                // This is a header for a new material
#define MATMAPFILE    0xA300                // This holds the file name of the texture

#define OBJECT_MESH   0x4100                // This lets us know that we are reading a new object

//>------ sub defines of OBJECT_MESH
#define OBJECT_VERTICES     0x4110          // The objects vertices
#define OBJECT_FACES        0x4120          // The objects faces
#define OBJECT_MATERIAL     0x4130          // This is found if the object has a material, either texture map or color
#define OBJECT_UV           0x4140          // The UV texture coordinates


//--- 3dsLoaderClass definition ------------------------------------ /*fold00*/
// This class includes all the code needed to load a .3DS file.
// It is heavily based on a tutorial by
//
// Ben Humphrey (DigiBen)
// DigiBen@GameTutorials.com


///   This constructor initializes the _chunk data
io3ds::io3ds() {
    m_CurrentChunk = 0;
    m_TempChunk = 0;
}

///   this method is called to open the .3ds file, read it, then clean up
int io3ds::load(const std::string & strFileName, std::vector<ve::geoObj*> & vMesh) {
    m_FilePointer = fopen(strFileName.c_str(), "rb");
    if(!m_FilePointer) {
        cerr << "ERROR: Unable to find the file: " << strFileName << endl;
        return 1;
    }

    m_CurrentChunk = new _chunk;
    m_TempChunk = new _chunk;
    vChildren.clear();
    vMaterial.clear();

    // read the first chuck of the file to see if it's a 3DS file
    readChunk(m_CurrentChunk);

    // Make sure this is a 3DS file
    if (m_CurrentChunk->ID != PRIMARY) {
        cerr << "Unable to load PRIMARY chuck from file: %s!" << strFileName << endl;
        cleanUp();
        return 1;
    }

    // Begin loading objects, by calling this recursive function
    processNextChunk(m_CurrentChunk);
    cleanUp();

    // transfer into geoMeshes:
    for(unsigned int i=0; i<vChildren.size(); i++) {
        if(vChildren[i].vMaterial.size()<2) {
            geoMesh * pMesh=new geoMesh;
            pMesh->coords()=vChildren[i].vCoords;
            pMesh->texCoords()=vChildren[i].vTexCoords;
            pMesh->name(vChildren[i].objName);
            pMesh->indices()=vChildren[i].vIndices;
            pMesh->faceEnds()=vChildren[i].vFaceEnds;

            if(vChildren[i].vMaterial.size()) {
                for(unsigned int j = 0; j < vMaterial.size(); j++) {
                    if(strcmp(vChildren[i].vMaterial[0].matName, vMaterial[j].matName) == 0) {
                        // Now that we found the material, check if it's a texture map.
                        // If the fileName has a string length of 1 and over it's a texture
                        if(strlen(vMaterial[j].fileName) > 0) {
                            pMesh->textureFileName()=vMaterial[j].fileName;
                            pMesh->textureRepeat()=true;
                            //cout << '\t' << pMesh->textureFileName() << endl;
                        }
                        pMesh->color().set(float(vMaterial[j].color[0])/255.0f, float(vMaterial[j].color[1])/255.0f, float(vMaterial[j].color[2])/255.0f,vMaterial[j].opacity);
                        break;
                    }
                }
            }
            vMesh.push_back(pMesh);
        }
        else for(unsigned int k=0; k<vChildren[i].vMaterial.size(); k++) {
            geoMesh * pMesh=new geoMesh;
            pMesh->coords()=vChildren[i].vCoords;
            pMesh->texCoords()=vChildren[i].vTexCoords;
            pMesh->name(vChildren[i].objName+i2s(k));
            unsigned int j;
            for(j = 0; j < vChildren[i].vMaterial[k].vFace.size(); j++) {
                pMesh->indices().push_back(vChildren[i].vIndices[vChildren[i].vMaterial[k].vFace[j]*3]);
                pMesh->indices().push_back(vChildren[i].vIndices[vChildren[i].vMaterial[k].vFace[j]*3+1]);
                pMesh->indices().push_back(vChildren[i].vIndices[vChildren[i].vMaterial[k].vFace[j]*3+2]);
                pMesh->faceEnds().push_back(j*3+2);
            }

            for(j = 0; j < vMaterial.size(); j++) {
                if(strcmp(vChildren[i].vMaterial[k].matName, vMaterial[j].matName) == 0) {
                    // Now that we found the material, check if it's a texture map.
                    // If the fileName has a string length of 1 and over it's a texture
                    if(strlen(vMaterial[j].fileName) > 0) {
                        pMesh->textureFileName()=vMaterial[j].fileName;
                        pMesh->textureRepeat()=true;
                        //cout << '\t' << pMesh->textureFileName() << endl;
                    }
                    pMesh->color().set(float(vMaterial[j].color[0])/255.0f, float(vMaterial[j].color[1])/255.0f, float(vMaterial[j].color[2])/255.0f,vMaterial[j].opacity);
                    break;
                }
            }
            vMesh.push_back(pMesh);
        }
    }
    return 0;
}

///   This function cleans up our allocated memory and closes the file
void io3ds::cleanUp() {
    fclose(m_FilePointer);
    delete m_CurrentChunk;
    delete m_TempChunk;
}


///   This function reads the main sections of the .3DS file, then dives deeper with recursion
void io3ds::processNextChunk(_chunk *pPreviousChunk) {
    _3dsObject newObject;                  // This is used to add to our object list
    _materialInfo newTexture;             // This is used to add to our material list
    unsigned int version = 0;                   // This will hold the file version

    m_CurrentChunk = new _chunk;                // Allocate a new chunk

    while (pPreviousChunk->bytesRead < pPreviousChunk->length) {
        // read next Chunk
        readChunk(m_CurrentChunk);

        // Check the chunk ID
        switch (m_CurrentChunk->ID) {
        case VERSION:                           // This holds the version of the file
            // read the file version and add the bytes read to our bytesRead variable
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(&version, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            // If the file version is over 3, give a warning that there could be a problem
            if (version > 0x03)
                cerr << "This 3DS file is over version 3 so it may load incorrectly" << endl;
            break;

        case OBJECTINFO:                        // This holds the version of the mesh
            // This chunk holds the version of the mesh.  It is also the head of the MATERIAL
            // and OBJECT chunks.  From here on we start reading in the material and object info.
            // read the next chunk
            readChunk(m_TempChunk);
            // Get the version of the mesh
            m_TempChunk->bytesRead += static_cast<unsigned int>(fread(&version, 1, m_TempChunk->length - m_TempChunk->bytesRead, m_FilePointer));
            // Increase the bytesRead by the bytes read from the last chunk
            m_CurrentChunk->bytesRead += m_TempChunk->bytesRead;
            // Go to the next chunk, which is the object has a texture, it should be MATERIAL, then OBJECT.
            processNextChunk(m_CurrentChunk);
            break;

        case MATERIAL:                          // This holds the material information
            // This chunk is the header for the material info chunks
            // Add a empty texture structure to our texture list.
            vMaterial.push_back(newTexture);
            // Proceed to the material loading function
            processNextMaterialChunk(m_CurrentChunk);
            break;

        case OBJECT:                            // This holds the name of the object being read
            // This chunk is the header for the object info chunks.  It also
            // holds the name of the object.
            // Add a new tObject node to our list of objects (like a link list)
            vChildren.push_back(newObject);
            // Get the name of the object and store it, then add the read bytes to our byte counter.
            m_CurrentChunk->bytesRead += getString(vChildren[vChildren.size() - 1].objName);
            // Now proceed to read in the rest of the object information
            processNextObjectChunk(&vChildren[vChildren.size()-1], m_CurrentChunk);
            break;

        case EDITKEYFRAME:
        default:
            // If we didn't care about a chunk, then we get here.  We still need
            // to read past the unknown or ignored chunk and add the bytes read to the byte counter.
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(buffer, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            break;
        }
        // Add the bytes read from the last chunk to the previous chunk passed in.
        pPreviousChunk->bytesRead += m_CurrentChunk->bytesRead;
    }
    // Free the current chunk and set it back to the previous chunk (since it started that way)
    delete m_CurrentChunk;
    m_CurrentChunk = pPreviousChunk;
}


///   This function handles all the information about the objects in the file
void io3ds::processNextObjectChunk(_3dsObject *pObject, _chunk *pPreviousChunk) {
    // Allocate a new chunk to work with
    m_CurrentChunk = new _chunk;

    // Continue to read these chunks until we read the end of this sub chunk
    while (pPreviousChunk->bytesRead < pPreviousChunk->length) {
        // Read the next chunk
        readChunk(m_CurrentChunk);

        // Check which chunk we just read
        switch (m_CurrentChunk->ID) {
        case OBJECT_MESH:
            // We found a new object, so let's read in it's info using recursion
            processNextObjectChunk(pObject, m_CurrentChunk);
            break;
        case OBJECT_VERTICES:
            readVertices(pObject, m_CurrentChunk);
            break;
        case OBJECT_FACES:
            readVertexIndices(pObject, m_CurrentChunk);
            break;
        case OBJECT_MATERIAL:
            // We now will read the name of the material assigned to this object
            readObjectMaterial(pObject, m_CurrentChunk);
            break;
        case OBJECT_UV:
            // This chunk holds all of the UV coordinates for our object.  Let's read them in.
            readUVCoordinates(pObject, m_CurrentChunk);
            break;
        default:
            // read past the ignored or unknown chunks
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(buffer, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            break;
        }
        // Add the bytes read from the last chunk to the previous chunk passed in.
        pPreviousChunk->bytesRead += m_CurrentChunk->bytesRead;
    }

    // Free the current chunk and set it back to the previous chunk (since it started that way)
    delete m_CurrentChunk;
    m_CurrentChunk = pPreviousChunk;
}


///   This function handles all the information about the material (Texture)
void io3ds::processNextMaterialChunk(_chunk *pPreviousChunk) {
    // Allocate a new chunk to work with
    m_CurrentChunk = new _chunk;

    // Continue to read these chunks until we read the end of this sub chunk
    while (pPreviousChunk->bytesRead < pPreviousChunk->length) {
        // read the next chunk
        readChunk(m_CurrentChunk);

        // Check which chunk we just read in
        switch (m_CurrentChunk->ID) {
        case MATNAME:                           // This chunk holds the name of the material
            // Here we read in the material name
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(vMaterial[vMaterial.size() - 1].matName, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            break;
        case MATDIFFUSE:                        // This holds the R G B color of our object
            readColorChunk(&(vMaterial[vMaterial.size() - 1]), m_CurrentChunk);
            break;
        case MATMAP:                            // This is the header for the texture info
            // Proceed to read in the material information
            processNextMaterialChunk(m_CurrentChunk);
            break;
        case MATMAPFILE:                        // This stores the file name of the material
            // Here we read in the material's file name
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(vMaterial[vMaterial.size() - 1].fileName, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            break;
        case MATTRANSP:
            readTranspChunk(&(vMaterial[vMaterial.size() - 1]), m_CurrentChunk);
            break;
        default:
            // Read past the ignored or unknown chunks
            m_CurrentChunk->bytesRead += static_cast<unsigned int>(fread(buffer, 1, m_CurrentChunk->length - m_CurrentChunk->bytesRead, m_FilePointer));
            break;
        }

        // Add the bytes read from the last chunk to the previous chunk passed in.
        pPreviousChunk->bytesRead += m_CurrentChunk->bytesRead;
    }

    // Free the current chunk and set it back to the previous chunk (since it started that way)
    delete m_CurrentChunk;
    m_CurrentChunk = pPreviousChunk;
}

///   This function reads in a chunk ID and it's length in bytes
void io3ds::readChunk(_chunk *pChunk) {
    // This reads the chunk ID which is 2 bytes.
    // The chunk ID is like OBJECT or MATERIAL.  It tells what data is
    // able to be read in within the chunks section.
    pChunk->bytesRead = static_cast<unsigned int>(fread(&pChunk->ID, 1, 2, m_FilePointer));
    // Then, we read the length of the chunk which is 4 bytes.
    // This is how we know how much to read in, or read past.
    pChunk->bytesRead += static_cast<unsigned int>(fread(&pChunk->length, 1, 4, m_FilePointer));
}

///   This function reads in a string of characters
int io3ds::getString(char *pBuffer) {
    int index = 0;
    // Read 1 byte of data which is the first letter of the string
    fread(pBuffer, 1, 1, m_FilePointer);
    // Loop until we get NULL
    while (*(pBuffer + index++) != 0)
        // Read in a character at a time until we hit NULL.
        fread(pBuffer + index, 1, 1, m_FilePointer);

    // Return the string length, which is how many bytes we read in (including the NULL)
    return static_cast<int>(strlen(pBuffer)) + 1;
}


///   This function reads in the RGB color data
void io3ds::readColorChunk(_materialInfo *pMaterial, _chunk *pChunk) {
    // read the color chunk info
    readChunk(m_TempChunk);
    // read in the R G B color (3 bytes - 0 through 255)
    m_TempChunk->bytesRead += static_cast<unsigned int>(fread(pMaterial->color, 1, m_TempChunk->length - m_TempChunk->bytesRead, m_FilePointer));
    // Add the bytes read to our chunk
    pChunk->bytesRead += m_TempChunk->bytesRead;
}


///  this method reads transparency data
void io3ds::readTranspChunk(_materialInfo *pMaterial, _chunk *pChunk) {
    readChunk(m_TempChunk);
    float percent=0;
    switch (m_TempChunk->ID) {
    case CHUNK_PERCENT_INT: {// int format
        int i=0;
        m_TempChunk->bytesRead += static_cast<unsigned int>(fread(&i, 1, 2, m_FilePointer));
        percent = (float)i;
        break;
    }
    case CHUNK_PERCENT_FLOAT: // float format
        m_TempChunk->bytesRead += static_cast<unsigned int>(fread(&percent, 1, 4, m_FilePointer));
        break;
    default:
        break;
    }
    pMaterial->opacity=1.0f-(percent/100.0f);
    // Add the bytes read to our chunk
    pChunk->bytesRead += m_TempChunk->bytesRead;
}


///   This function reads in the indices for the vertex array
void io3ds::readVertexIndices(_3dsObject *pObject, _chunk *pCurrChunk) {
    // read in the number of faces that are in this object (int)
    int numFaces=0;
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&numFaces, 1, 2, m_FilePointer));

    // Alloc enough memory for the faces and initialize the structure
    pObject->vIndices.clear();
    pObject->vIndices.assign((unsigned int)numFaces*3,0);
    pObject->vFaceEnds.clear();
    pObject->vFaceEnds.assign((unsigned int)numFaces,0);

    unsigned short index=0;
    // Go through all of the faces in this object
    for(unsigned int i = 0; i < (unsigned int)numFaces; i++) {
        // Next, we read in the A then B then C index for the face, but ignore the 4th value.
        // The fourth value is a visibility flag for 3D Studio Max, we don't care about this.
        for(int j = 0; j < 4; j++) {
            // read the first vertex index for the current face
            pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&index, 1, sizeof(index), m_FilePointer));
            if(j < 3)  // Store the index in our face structure.
                pObject->vIndices[i*3+j]=index;
        }
        pObject->vFaceEnds[i]=i*3+2;
    }
}


void io3ds::readUVCoordinates(_3dsObject *pObject, _chunk *pCurrChunk) {
    // read in the number of UV coordinates there are (int)
    int numTexVertex=0;
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&numTexVertex, 1, 2, m_FilePointer));
    // Allocate memory to hold the UV coordinates
    pObject->vTexCoords.clear();
    pObject->vTexCoords.assign((unsigned int)numTexVertex,vec2f(0,0));
    // read in the texture coodinates (an array 2 float)
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&pObject->vTexCoords[0], 1, pCurrChunk->length - pCurrChunk->bytesRead, m_FilePointer));
}


void io3ds::readVertices(_3dsObject *pObject, _chunk *pCurrChunk) {
    // read in the number of vertices (int)
    int numVerts=0;
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&numVerts, 1, 2, m_FilePointer));
    // Allocate the memory for the verts and initialize the structure
    pObject->vCoords.clear();
    pObject->vCoords.assign(static_cast<unsigned int>(numVerts),vec3f(0,0,0));
    // read in the array of vertices (an array of 3 floats)
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&pObject->vCoords[0], 1, pCurrChunk->length - pCurrChunk->bytesRead, m_FilePointer));
}


///   This function reads in the material name assigned to the object and sets the materialID
void io3ds::readObjectMaterial(_3dsObject *pObject, _chunk *pCurrChunk) {
    _materialRef currMaterial;
    // here we read the material name
    pCurrChunk->bytesRead += getString(currMaterial.matName);
    // read face references:
    int numEntries=0;
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&numEntries, 1, 2, m_FilePointer));
    currMaterial.vFace.assign(static_cast<unsigned int>(numEntries),0);
    pCurrChunk->bytesRead += static_cast<unsigned int>(fread(&currMaterial.vFace[0], 1, numEntries*sizeof(unsigned short), m_FilePointer));
    pObject->vMaterial.push_back(currMaterial);
}

//--- cvs history log : -------------------------------------------- /*FOLD00*/
/*
 * $Log: veIo3ds.cpp,v $
 * Revision 1.2  2004/12/15 14:23:03  gf
 * Now geoObj make internally use of transformation matrices instead of
 * sixdofs. Some corresponding adaptations in various files.
 *
 * Revision 1.1  2004/12/06 11:16:09  gf
 * load3ds renamed to io3ds in order to fit better into the upcoming loader
 * structure of veGeoObj
 *
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.7  2004/10/27 12:47:58  gf
 * documentation updates and naming conventions unified
 *
 * Revision 1.6  2004/10/15 15:26:33  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.5  2004/10/04 09:38:11  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.4  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.3  2004/04/27 13:43:47  weyel
 * - fixed a bug in host2netf and net2hostf
 * - floats now coverted correctly for network transfer
 * - changed include order in some files (MS VC wants windows.h in front of
 *   any GL-includings)
 *
 * Revision 1.2  2004/04/20 10:16:45  gf
 * - 3ds loader now interprets transparency
 * - better compatibility to X3D, but translation not yet finished!
 *
 * Revision 1.1  2004/04/16 13:34:39  gf
 * - basic 3dsLoader for ve::geoMeshes added, some corresponding adaptations
 * - some VC6 trash undone
 */
