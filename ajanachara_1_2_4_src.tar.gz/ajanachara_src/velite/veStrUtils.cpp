#include "veStd.h"
#include "veStrUtils.h"

using namespace std;
using namespace ve;

//--- string utility functions -------------------------------------- /*FOLD00*/
namespace ve {

unsigned int split(const string & input, vector<string> & output, const string & separators) {
    unsigned int numberOfElements=0;
    unsigned int start, stop;
    start = static_cast<unsigned int>(input.find_first_not_of(separators));
    while (start < input.size()) {
        stop = static_cast<unsigned int>(input.find_first_of(separators, start));
        if (stop > static_cast<unsigned int>(input.size())) stop = static_cast<unsigned int>(input.size());
        output.push_back(input.substr(start, stop - start));
        numberOfElements++;
        start = static_cast<unsigned int>(input.find_first_not_of(separators, stop+1));
    }
    return numberOfElements;
}

string trim(const string & s, const string & pattern) {
    if(s.size() == 0) return s;
    unsigned int b = static_cast<unsigned int>(s.find_first_not_of(pattern));
    unsigned int e = static_cast<unsigned int>(s.find_last_not_of(pattern));
    if(b > s.size()) return "";
    return string(s, b, e - b + 1);
}

string replaceAll(string s, const string & search, const string & repl) {
    unsigned int found = static_cast<unsigned int>(s.find(search));
    while(found <s.size()) {
        s.replace(found, search.size(), repl);
        found = static_cast<unsigned int>(s.find(search,found+repl.size()));
    }
    return s;
}

void operator-=(string & s, unsigned int n) {
    s.erase(s.size()-n,n);
}

string i2s(long i) {
    char buf[32];
    sprintf(buf,"%li",i);
    return string(buf);;
}

string f2s(double f) {
    char buf[32];
    sprintf(buf,"%f",f);
    string ret(buf);
    return ret.substr(0,ret.find_last_not_of("0")+2);
}

string f2s(double f, unsigned short nDigits) {
    char buf[32];
    string fmt="%.0"+i2s(nDigits)+'f';
    sprintf(buf,fmt.c_str(),f);
    return string(buf);;
}

string b2s(bool b, bool asText) {
    if(asText) {
        if(b) return "true";
        else return "false";
    }
    if(b) return "1";
    return "0";
}

string c2s(char ch) {
    string s("x");
    s[0]=ch;
    return s;
}

int s2i(const string & s) {
    return atoi(s.c_str());
}

unsigned int s2ui(const string & s) {
    return (unsigned int)atoi(s.c_str());
}


float s2f(const string & s) {
    return static_cast<float>(atof(s.c_str()));
}

bool s2b(const string & s) {
    if(s=="true") return true;
    if(s=="TRUE") return true;
    if(atoi(s.c_str())>0) return true;
    return false;
}

bool isWhiteSpace(char ch) {
    switch(ch) {
    case ' ':
    case '\n':
    case '\t':
    case '\015':
        return true;
    }
    return false;
}

unsigned int s2f(const string & s, vector<float> & vFloat, const string & separators) {
    vector<string> words;
    vFloat.reserve(split(s,words,separators));
    for(unsigned int i=0; i<words.size(); i++)
        vFloat.push_back(static_cast<float>(atof(words[i].c_str())));
    return static_cast<unsigned int>(words.size());
}

unsigned int s2i(const string & s, vector<int> & vInt, const string & separators) {
    vector<string> words;
    vInt.reserve(split(s,words,separators));
    for(unsigned int i=0; i<words.size(); i++)
        vInt.push_back(atoi(words[i].c_str()));
    return static_cast<unsigned int>(words.size());
}

unsigned int s2ui(const string & s, vector<unsigned int> & vUInt, const string & separators) {
    vector<string> words;
    vUInt.reserve(split(s,words,separators));
    for(unsigned int i=0; i<words.size(); i++)
        vUInt.push_back((unsigned int)atoi(words[i].c_str()));
    return static_cast<unsigned int>(words.size());
}

unsigned int s2b(const string & s, vector<bool> & vBool, const string & separators) {
    vector<string> words;
    vBool.reserve(split(s,words,separators));
    for(unsigned int i=0; i<words.size(); i++)
        vBool.push_back(s2b(words[i]));
    return static_cast<unsigned int>(words.size());
}

string toUpper(const string & s) {
    string retStr(s);
    for(unsigned int i=0; i<s.size(); i++)
        retStr[i]=static_cast<char>(toupper(retStr[i]));
    return retStr;
}

string toLower(const string & s) {
    string retStr(s);
    for(unsigned int i=0; i<s.size(); i++)
        retStr[i]=static_cast<char>(tolower(retStr[i]));
    return retStr;
}

unsigned int hex2ui(const string & s) {
    unsigned int factor=1;
    unsigned int ret=0;
    for(unsigned int i=0; i<s.size(); ++i) {
        unsigned int value=0;
        if(s[s.size()-i-1]>='a')
            value=10+s[s.size()-i-1]-'a';
        else if(s[s.size()-i-1]>='A')
            value=10+s[s.size()-i-1]-'A';
        else value=s[s.size()-i-1]-'0';
        ret+=value*factor;
        factor*=16;
    }
    return ret;
}

}

//--- cvs history log : --------------------------------------------- /*FOLD00*/
/*
 * $Log: veStrUtils.cpp,v $
 * Revision 2.1  2005/01/03 09:41:42  gf
 * hex2ui conversion function added
 *
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.21  2004/10/25 11:54:35  gf
 * toLower and toUpper functions added
 *
 * Revision 1.20  2004/10/04 09:38:11  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.19  2004/09/28 12:19:26  gf
 * string_npos constant removed
 *
 * Revision 1.18  2004/09/13 08:30:06  gf
 * function c2s() (char to string conversion) added
 *
 * Revision 1.17  2004/08/04 12:19:14  gf
 * s2b() methods now tolerant to upper/lowercase
 *
 * Revision 1.16  2004/01/26 09:10:44  gf
 * - simple remapping mechanism implemented
 * - dynamic scenegraph objects have now a local coordinate system for speed
 *
 * Revision 1.15  2003/12/01 16:58:16  gf
 * string conversion functions: long instead of int, double instead of float
 *
 * Revision 1.14  2003/10/28 14:43:56  mvdh
 * operator-=() improved
 *
 * Revision 1.13  2003/09/23 16:35:19  gf
 * operator-=(string & s, unsigned int n) added
 *
 * Revision 1.12  2003/07/29 10:38:45  gf
 * - veGlUtils: the bad cocnept of fontScale removed
 * - veStrUtils: function s2b(vector<bool>,...) added
 *
 * Revision 1.11  2003/07/25 11:09:40  gf
 * senseless docu removed (now exclusively in veStrUtils.h)
 *
 * Revision 1.9  2003/03/31 16:19:52  gf
 * namespace ve added. Should be consequently used instead of VE_ etc.
 *
 * Revision 1.8  2003/03/25 17:29:00  mvdh
 * major changes in most files - cebit version from MvdH now in action - please watch out for eventual errors and conflicts - now windows and linux support
 *
 * Revision 1.7  2003/03/21 16:33:03  gf
 * - s2f, s2i for vectors added
 * - documentation update
 * - split() slightly optimized
 *
 * Revision 1.6  2003/02/26 12:50:10  gf
 * some parameters now const
 *
 * Revision 1.5  2002/12/17 15:47:02  gf
 * function f2s(float,precision) added
 *
 * Revision 1.4  2002/07/29 09:36:54  gf
 * methods for handling bool variables added
 *
 * Revision 1.3  2002/05/06 15:47:45  gf
 * senseless comments removed
 *
 * Revision 1.2  2002/04/23 13:19:47  gf
 * added some consts and infinite recursive call for replaceAll fixed
 *
 * Revision 1.1  2002/04/11 13:06:19  gf
 * some convenient c++ string utility functions, formerly part of veXml,
 * now separated in its own files
 */
