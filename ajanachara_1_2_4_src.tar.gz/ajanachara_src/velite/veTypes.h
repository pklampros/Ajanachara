#ifndef _VE_TYPES_H
#define _VE_TYPES_H
/** @file veTypes.h
 \brief Central repository for defined simple types.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author gf

 $Revision: 2.1 $
 */

//@{

#include"veStd.h"
#include"veStrUtils.h"

//--- basic definitions and constants ------------------------------ /*fold00*/

/// veLib standard namespace
/**
 This namespace is distributed across several *.h files. However, the
 main documentation is written here (in file veStd.h). We try to cover
 all general enums and defines with this namespace top avoid
 name clashes with other libraries, tools and compiler defaults.
 */
namespace ve {
/** @name definitions and constants
 * some handy definitions of bitmasks and bytemasks
 * for packing multiple flags into variables.
 */
//@{
/// this array defines names for all 32 bits of an unsigned int
const unsigned int BIT[]= {
    0x1,0x2,0x4,0x8, 0x10,0x20,0x40,0x80, 0x100,0x200,0x400,0x800,
    0x1000,0x2000,0x4000,0x8000, 0x10000,0x20000,0x40000,0x80000,
    0x100000,0x200000,0x400000,0x800000, 0x1000000,0x2000000,
    0x4000000,0x8000000, 0x10000000,0x20000000,0x40000000,0x80000000 };

/// this array defines names for all 4 bytes of an unsigned int
const unsigned int BYTE[]= { 0xFF, 0xFF00, 0xFF0000, 0xFF000000 };
//@}


//--- key and button identifiers ----------------------------------- /*fold00*/
/// large enum for communicating input device states and standard events.
/** No id's beyond 127 are allowed. */
typedef enum {
        // the keyboard syms have been chosen to widely map to ASCII
        BUTTON_ID_FIRST         = 0,
        KEY_FIRST		= 0,
        BUTTON_0                       = 0,
        KEY_F1	           	       = 0,
        BUTTON_1                       = 1,
	KEY_F2			       = 1,
        BUTTON_2                       = 2,
	KEY_F3			       = 2,
        BUTTON_3                       = 3,
	KEY_F4			       = 3,
        BUTTON_4                       = 4,
	KEY_F5			       = 4,
        BUTTON_5                       = 5,
	KEY_F6			       = 5,
        BUTTON_6                       = 6,
	KEY_F7			       = 6,
        BUTTON_7                       = 7,
	KEY_F8			       = 7,
	KEY_BACKSPACE		= 8,
	KEY_TAB	                = 9,
	KEY_RSHIFT	               = 10,
	KEY_LSHIFT	               = 11,
	KEY_CLEAR		= 12,
	KEY_RETURN		= 13,
	KEY_RCTRL	      	       = 14,
	KEY_LCTRL		       = 15,
	KEY_RALT		       = 16,
	KEY_LALT		       = 17,
	KEY_MODE	               = 18,   // "Alt Gr" key
	KEY_PAUSE		= 19,
        BUTTON_8                       = 20,
	KEY_F9			       = 20,
        BUTTON_9                       = 21,
	KEY_F10			       = 21,
        BUTTON_10                      = 22,
	KEY_F11			       = 22,
        BUTTON_11                      = 23,
	KEY_F12			       = 23,
        BUTTON_12                      = 24,
	KEY_F13			       = 24,
        BUTTON_13                      = 25,
	KEY_F14			       = 25,
        BUTTON_14                      = 26,
	KEY_F15			       = 26,
        BUTTON_15                      = 27,
	KEY_F16			       = 27,
        KEY_ESCAPE		= 27,
        EVT_TERM                       = 27,
	KEY_RWIN           	       = 28,   // right "Windows" key
        KEY_LWIN		       = 29,   // left  "Windows" key
        KEY_ACCENT                     = 30,
        EVT_ERROR                      = 31,
	KEY_SPACE		= 32,
	KEY_EXCLAIM		= 33,
	KEY_QUOTEDBL		= 34,
	KEY_HASH		= 35,
	KEY_DOLLAR		= 36,
	KEY_AMPERSAND		= 38,
	KEY_QUOTE		= 39,
	KEY_LEFTPAREN		= 40,
	KEY_RIGHTPAREN		= 41,
	KEY_ASTERISK		= 42,
	KEY_PLUS		= 43,
	KEY_COMMA		= 44,
	KEY_MINUS		= 45,
	KEY_PERIOD		= 46,
	KEY_SLASH		= 47,
	KEY_0			= 48,
	KEY_1			= 49,
	KEY_2			= 50,
	KEY_3			= 51,
	KEY_4			= 52,
	KEY_5			= 53,
	KEY_6			= 54,
	KEY_7			= 55,
	KEY_8			= 56,
	KEY_9			= 57,
	KEY_COLON		= 58,
	KEY_SEMICOLON		= 59,
	KEY_LESS		= 60,
	KEY_EQUALS		= 61,
	KEY_GREATER		= 62,
	KEY_QUESTION		= 63,
	KEY_AT			= 64,
        // use uppercase letters for other keys:
        // cursor keys:
	KEY_UP			       = 65,
	KEY_DOWN		       = 66,
	KEY_RIGHT		       = 67,
	KEY_LEFT		       = 68,
	KEY_INSERT		       = 69,
	KEY_HOME		       = 70,
	KEY_END		               = 71,
	KEY_PAGEUP		       = 72,
	KEY_PAGEDOWN		       = 73,
        // numeric keypad:
	KEY_KP0	                       = 74,
	KEY_KP1			       = 75,
	KEY_KP2			       = 76,
	KEY_KP3			       = 77,
	KEY_KP4			       = 78,
	KEY_KP5			       = 79,
	KEY_KP6			       = 80,
	KEY_KP7			       = 81,
	KEY_KP8			       = 82,
	KEY_KP9			       = 83,
	KEY_KP_PERIOD		       = 84,
	KEY_KP_DIVIDE		       = 85,
	KEY_KP_MULTIPLY	               = 86,
	KEY_KP_MINUS		       = 87,
	KEY_KP_PLUS		       = 88,
	KEY_KP_ENTER		       = 89,
	KEY_KP_EQUALS		       = 90,

	KEY_LEFTBRACKET  	= 91,
	KEY_BACKSLASH		= 92,
	KEY_RIGHTBRACKET	= 93,
	KEY_CARET		= 94,
	KEY_UNDERSCORE		= 95,
	KEY_BACKQUOTE		= 96,
	KEY_a			= 97,
	KEY_b			= 98,
	KEY_c			= 99,
	KEY_d			= 100,
	KEY_e			= 101,
	KEY_f			= 102,
	KEY_g			= 103,
	KEY_h			= 104,
	KEY_i			= 105,
	KEY_j			= 106,
	KEY_k			= 107,
	KEY_l			= 108,
	KEY_m			= 109,
	KEY_n			= 110,
	KEY_o			= 111,
	KEY_p			= 112,
	KEY_q			= 113,
	KEY_r			= 114,
	KEY_s			= 115,
	KEY_t			= 116,
	KEY_u			= 117,
	KEY_v			= 118,
	KEY_w			= 119,
	KEY_x			= 120,
	KEY_y			= 121,
        KEY_z			= 122,
        KEY_AUML                       = 123,
        KEY_OUML                       = 124,
        KEY_UUML                       = 125,
        KEY_SZLIG                      = 126,
	KEY_DELETE		= 127,
        // do not go beyond this!!
        BUTTON_ID_MAX           = 127
} buttonId;


//--- class flag128 ------------------------------------------------ /*fold00*/
    /// a class for storing a large number of flags.
    /** This small inline class is mainly designed to store a complete state of any
     input device, e.g., all keys of a keyboard. 
     To allow effective memory packing and copying, no virtual methods or
     additional variables should be added. */
    class flag128 {
    public:
        /// default constructor
        flag128() { clear(); };
        /// returns value n.
        /** \return bool value of flag n or false if n is out of range. */
        bool operator[](unsigned int n) const {
          return n>=size() ? false : (word_[n/32]&ve::BIT[n%32] ? true : false); };
        /// comparison operator equality
        bool operator==(const ve::flag128 & f) const {
            return ((word_[0]==f.word_[0])&&(word_[1]==f.word_[1])&&
                    (word_[2]==f.word_[2])&&(word_[3]==f.word_[3])); };
        /// comparison operator inequality
        bool operator!=(const ve::flag128 & f) const { return !(operator==(f)); };
        /// turns flag n on
        void on(unsigned int n) {
            if(n<size()) word_[n/32]|=ve::BIT[n%32]; };
        /// turns flag n off
        void off(unsigned int n) {
            if(n<size()) if(operator[](n)) word_[n/32]-=ve::BIT[n%32]; };
        /// sets all flags to false
        void clear() { word_[0]=word_[1]=word_[2]=word_[3]=0; };
        /// returns number of flags in one object
        unsigned int size() const { return 128; };
        /// allows direct access to the unsigned ints, no range check!
        unsigned int & word(unsigned int n) { return word_[n]; };
        /// allows direct reading of the unsigned ints, no range check!
        unsigned int word(unsigned int n) const { return word_[n]; };
        /// returns the number of words needed to store a flag128 object
        unsigned int nWords() const { return 4; };
        /// returns a string containing all data
        std::string str() const { return ve::i2s(word_[0])+'\t'+ve::i2s(word_[1])+'\t'+ve::i2s(word_[2])+'\t'+ve::i2s(word_[3]); };
    protected:
        /// stores the flags
        unsigned int word_[4];
    };


//--- definitions concerning the ve::dataContainer ----------------- /*fold00*/

/// the number of buttons in the veData class.
const unsigned int DC_NUM_BUTTONS=ve::BUTTON_ID_MAX + 1;

//const unsigned int MAX_OVERLAY_FREETEXT_LENGTH=60;

/// this enum defines meaningful names for the kind of information a data container contains
enum dataContainerType {
    DC_OBJECT = 0,
    DC_CHAR,
};

/// number of sixdofs in a data container (currently 3 : position, velocity, acceleration)
const unsigned int DC_NUM_SIXDOFS = 4;

/// The number of axes in the veData class.
const unsigned int DC_NUM_AXES=6 * ve::DC_NUM_SIXDOFS;

/// this enum gives the 4 sixdofs of a data container meaningful names
enum dcAxesType {
    DC_AXES_INPUT = 0,
    DC_AXES_POS,
    DC_AXES_VEL,
    DC_AXES_ACC,
};

/// this enum gives the flag containers of the data container meaningful names
enum dcFlagsType {
    DC_FLAGS_INPUT = 0,
    DC_FLAGS_STATE,
};

/// this enum gives the ids of the data container meaningful names
enum dcIdType {
    DC_ID_COMMAND   = 0,
    DC_ID_CLASS     = 1,
    DC_ID_OBJECT    = 2,
    DC_ID_SENDER    = 3,
    DC_ID_RECEIVER  = 4,
    DC_ID_TRANSFER  = 5,
    DC_ID_CONTAINER = 6,
    DC_ID_MAX       = 6,
    DC_NUM_IDS      = 7,
};

/// this enum gives common commands (e.g., in the data container) meaningful names
enum dcCommandType {
    /// sets object data (position, velocity, etc.)
    CMD_OBJECT_SET = 0,
    /// adds an object to a scene/device
    CMD_OBJECT_ADD,
    /// removes an object from a scene/device
    CMD_OBJECT_DROP,

    /// sets the observer id, the camera will be bound to this object
    CMD_OBSERVERID_SET,

    /// not yet implemented!
    CMD_SCENE_CLEAR,
    /// not yet implemented!
    CMD_SCENE_LOAD,
    /// not yet implemented!
    CMD_SCENE_RESET,

    /// updates a resource definition
    CMD_RESOURCE_SET,
    /// adds a resource definition
    CMD_RESOURCE_ADD,
    /// drops a resource definition
    CMD_RESOURCE_DROP,

    /// terminates a device
    CMD_DEVICE_TERM,
    /// requests the current status of a device
    CMD_DEVICE_STATUS,
    ///\internal used internally for networking
    CMD_PING,
    ///\internal used internally for networking
    CMD_NEW_CONNECTION,
    ///\internal used internally for networking
    CMD_ACK,
};

/// these constants define a bitmask for restricting overwriting a dataContainer
enum dcMaskType {
    /// the dataContainer might be completely overwritten
    DC_MASK_ALL   = 0,
    /// only input axes and flags are overwritten
    DC_MASK_INPUT = 1,
    /// all non-input data fields are overwritten
    DC_MASK_STATE = 2,
};

/// defines names for how the dataContainer should be transfered over the network(e.g. should it arrive for sure?)
enum dcTransfer
{
    DC_TRANSFER_REDUNDANT = 0,
    DC_TRANSFER_MANDATORY,
};

/// constants for the mime types that identify the resources in the xml ini files
enum mimeType {
    /// resource is a not identified
    MIME_NONE = 0,
    /// resource is a png image (imgae/png)
    MIME_IMAGE_PNG,
    /// resource is a jpeg image (image/jpeg)
    MIME_IMAGE_JPEG,
    /// resource is a (windows) bitmap (image/x-bmp)
    MIME_IMAGE_BMP,
    /// resource is a svg image (image/svg+xml)
    MIME_IMAGE_SVG,
    /// resource is plain ascii text (text/plain)
    MIME_TEXT_PLAIN,
    /// resource is a vrml model (model/vrml)
    MIME_MODEL_VRML,
    /// resource is a X3D model (model/x3d)
    MIME_MODEL_X3D,
    /// resource is a 3D Studio mesh (application/x-3ds)
    MIME_APPLICATION_3DS,
    /// resource is a wave audio file (audio/wav)
    MIME_AUDIO_WAV,
    /// resource is a rectangle geometry object (geometry/rectangle)
    /** this is not an official mime type, but introduced in order to
     allow dynamic resource management of overlay rectangles. */
    MIME_GEOM_RECT,
    /// resource is a txf texture font (font/txf)
    MIME_FONT_TXF,
};

//--- definitions for ve::device ----------------------------------- /*fold00*/

/** \brief device identifiers
  This enum defines the different veDeviceIds. Those ids are used to
  identify the class of a device. It is usually combined with a
  identifying tag as a veDeviceId (see veData.h).
*/
typedef enum {
  /// no device at all
  DEV_NO_DEVICE = 0x1,
  /// no specific device, but at least device
  DEV_UNKNOWN = 0x2,
  /// some unspecific input device
  DEV_INPUT = 0x4,
  /// some unspecific output device
  DEV_OUTPUT = 0x8,

  // unspecific devices

  /// some unspecific mouse device
  DEV_MOUSE = 0x10,
  /// some unspecific keyboard device
  DEV_KEYBOARD = 0x20,
  /// some unspecific joystick device
  DEV_JOYSTICK = 0x40,
  /// some unspecific tracker device
  DEV_TRACKER = 0x80,
  /// some unspecific network device
  DEV_NETWORK = 0x100,
  /// some unspecific simulation device
  DEV_SIMULATION = 0x200,
  /// some unspecific sound device
  DEV_SOUND = 0x400,
  /// some unspecific combined window device integrating mouse and keyboard
  DEV_WINDOW = 0x800,
  /// some unspecific graphic device
  DEV_GRAPHICS = 0x1000,
  /// some virtual container device
  DEV_CONTAINER = 0x2000,

  // special VR equipment:
  ///\internal the motion platform (Maxcue)
  DEV_PLATFORM = 0x4000,

  /// combines all device ids, e.g., for dataContainer filter masks
  DEV_ALL = 0xFFFFFFFF,
} deviceId;

//--- error codes -------------------------------------------------- /*fold00*/
/** \brief Definition of error codes

 The error codes are globally defined to provide a framework of
 unique and useful error numbers reporting what was right and wrong in
 the functions. By the way, many functions return the number of errors which
 occurred during the execution.
*/
enum errorCodes {
  /// everything ok.
  ERR_OK=0,
  /// some unspecific error
  ERR_ERROR,
  /// we warn, but everything may work.
  ERR_WARNING,
  /// something unspecific, but fatal
  ERR_FATAL,
  /// current operation failed probably due to overload, but device may work correctly
  ERR_DEVICE_BUSY,
  /// device does not work at all, and probably will not work again without proper reinitialization
  ERR_DEVICE_NOT_WORKING,
  /// no dynamic memory available
  ERR_OUT_OF_MEMORY,
  /// input/output (e.g., file operation) failed
  ERR_IO,
};

} // namespace ve


//@}

//--- history : ---------------------------------------------------- /*FOLD00*/
/*
 * $Log: veTypes.h,v $
 * Revision 2.1  2004/12/23 16:44:08  gf
 * - all error codes are now positive integers
 * - VRML/X3D loaders updated, now normals are interpreted if available
 * - matStack4f matrix stack class added
 * - Merry Christmas!
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.44  2004/10/26 12:40:04  weyel
 * - transferSetting default changed to DC_TRANSFER_REDUNDANT
 * - added getConnectionStatus() for network device
 *
 * Revision 1.43  2004/10/25 11:55:21  gf
 * error codes cleaned up
 *
 * Revision 1.42  2004/10/18 11:10:14  gf
 * - mime type for txf fonts added
 * - framework for handling multiple fonts added, not completely implemented
 * - dataContainer::type() now changeable after construction
 *
 * Revision 1.41  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.40  2004/10/08 20:01:40  weyel
 * - data container size increased to 256 bytes
 * - VRML USE keyword substitution now at token level
 * - error checking in initGraphics() improved
 *
 * Revision 1.39  2004/10/08 17:37:37  gf
 * MIME_GEOM_RECT added
 *
 * Revision 1.38  2004/10/04 09:38:43  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.37  2004/09/28 12:22:50  gf
 * - ongoing changes for dynamic resource handling
 * - CMD_XYZ_OBJECT renamed to CMD_OBJECT_XYZ
 *
 * Revision 1.36  2004/09/24 16:08:58  gf
 * - cleanup of unused and old methods
 * - small bugfixes in the network device
 * -><F2> final adjustments to publish version 1.0.beta1
 *
 * Revision 1.35  2004/09/13 17:54:40  gf
 * - deviceContainer now ignores devices where the attribute
 *   deviceContainer="false" is set in the xml statement
 * - flag128::str() method for debug purposes added
 *
 * Revision 1.34  2004/08/24 16:26:41  gf
 * - deviceContainer access methods (device,size) added
 * - xmlIni include file parsing bug fixed
 *
 * Revision 1.33  2004/08/20 08:48:10  gf
 * - VECERR replaced by std::cerr
 * - dynamic overlay text implemented, affecting veDeviceSDL, veGlUtils, veTypes, veDataContainer
 *
 * Revision 1.32  2004/08/03 12:57:47  weyel
 * - fileIo::unifyPath() added do deal with slashes in filepaths
 * - collisionTriangle::altitude() added, returns height over a surface
 * - slight adaptations in some other files
 * - added deviceNetworkUDP, still based on SDLNet but will be
 *   changed to BSD sockets soon
 *
 * Revision 1.31  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.30  2004/04/13 11:38:00  weyel
 * - clock sync for network communication added
 * - motion prediction on base of synchronized clock
 * - font size for ovlText now read from ini-file
 *
 * Revision 1.29  2004/04/05 11:14:36  gf
 * - loading of bmp files added (via libSDL), mime type added
 * - vec2f class added
 *
 * Revision 1.28  2004/04/02 13:06:52  gf
 * unknown change
 *
 * Revision 1.27  2004/03/12 12:21:21  weyel
 * -added ovlRect for single-color overlay rectangles
 * -changed network code, dataContainers now have a transfer flag (MANDATORY/REDUNDANT)
 * -overlays now dynamic, color, size and pos may be changed at runtime
 *
 * Revision 1.26  2004/03/11 12:09:20  gf
 * memory leaks fixed and device types corrected
 *
 * Revision 1.25  2004/03/10 11:19:35  weyel
 * -handling of overlay objects improved
 * -they can now be switched on and off using command ADD_ and DROP_OBJECT
 *
 * Revision 1.24  2004/03/08 09:53:38  gf
 * comands renamed
 *
 * Revision 1.23  2004/03/04 18:51:21  gf
 * small adaptations towards interpreting more than one container
 *
 * Revision 1.22  2004/03/01 10:32:28  gf
 * docu updated
 *
 * Revision 1.21  2004/03/01 10:05:25  gf
 * - MT_ constants renamed to MIME_
 * - overlay runs again like before
 *
 * Revision 1.20  2004/02/28 13:47:57  gf
 * - syntax of dataContainer/device::setOutput simplified
 * - observer() methods (formerly followObject) and command handling added
 * - VEK_ constants renamed to KEY_ constants
 *
 * Revision 1.19  2004/02/27 16:53:52  gf
 * - dataContainer completely remodeled
 * - xmlIni::subTag() methods added
 * - update() interface for devices unified
 * - deviceGraphicsX3D::followObject() bug fixed
 *
 * Revision 1.18  2004/02/26 19:59:39  weyel
 * added resource types
 *
 * Revision 1.17  2004/02/26 14:26:36  gf
 * dataContainer renovated, some adaptations
 *
 * Revision 1.16  2004/02/24 13:33:33  gf
 * - ve::vec (veMath.h) renamed to ve::vec3f
 * - VEEC_XYZ (veTypes.h) error codes renamed to ve::ERR_XYZ
 *
 * Revision 1.15  2004/02/18 14:09:41  gf
 * veError codes moved to veTypes, adaptations to that
 *
 * Revision 1.14  2004/02/13 08:35:44  weyel
 * Device Id's changed so they can be set bitwise in one integer
 *
 * Revision 1.13  2004/02/10 11:51:17  gf
 * ve::device::getInput() improvement: it is now user definable which part of
 * information is goint to be overwritten
 *
 * Revision 1.12  2004/02/09 14:25:36  weyel
 * first version of new deviceNetwork
 *
 * Revision 1.11  2004/02/09 11:46:06  gf
 * - all enums in veTypes.h now consequently in capital letters
 * - dataContainer has now an additional constructor
 *
 * Revision 1.10  2004/02/06 18:28:15  gf
 * - veConfig _HAVE_3DSOUND undefined
 * - ve::dataContainer access methods added, corresp. enums defined
 * - deviceGraphicsX3D now interprets basic messages in dataContainer
 *
 * Revision 1.9  2004/01/20 14:23:11  weyel
 * - first version of new data container, messages removed
 * - container usage as other than dcStandard not testet yet!
 * - removed "handleMessage()" from pertained classes
 *
 * Revision 1.8  2004/01/15 14:33:05  gf
 * veData renamed to ve::dataContainer
 *
 * Revision 1.7  2004/01/12 10:35:55  gf
 * - veData && ve::device interface simplified
 * - bike related files moved to the contrib directory
 *
 * Revision 1.6  2004/01/11 21:39:20  gf
 * - talk.h renamed to veDebug.h
 * - veDevice moved to namespace ve and renamed to ve::device
 *
 * Revision 1.5  2004/01/09 10:17:27  weyel
 * major changes and interface simplifications to veData and veDevice, included SDL and removed old input devices and other unused classes. Please watch out for errors and report bugs immediatly.
 *
 * Revision 1.4  2003/12/15 12:45:28  gf
 * documentation update
 *
 * Revision 1.3  2003/12/15 10:38:53  gf
 * - veDeviceSDL now ready for integration
 * - small adpations from int to unsigned int
 *
 * Revision 1.2  2003/12/12 22:11:54  gf
 * any dependencies on GLFW removed. Slight improvements for the libSDL subsystem.
 *
 * Revision 1.1  2003/12/12 16:39:22  gf
 * just small changes, leading to hours of unproductive work: definitions
 * collected in veTypes.h some #defines moved to const unsigned int
 */
#endif //  _VE_TYPES_H
