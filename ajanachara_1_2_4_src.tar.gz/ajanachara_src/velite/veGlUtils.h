#ifndef _VE_GL_UTILS_H
#define _VE_GL_UTILS_H

/** @file veGlUtils.h
 \brief A collection of OpenGL auxilliary classes.

 glText     an abstract base class for OpenGL font renderers\n
 glTextTxf  loading and low level rendering of txf texture fonts\n
 ovlPlane   framework for managing overlay objects\n
 ovlObj     parent class for overlay 2d objects\n
 ovlLabel   single line text rendering\n
 ovlRect    display of 2D rectangles\n
 ovlImage   display of images.\n

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author gf

 $Revision: 2.0 $ 
 */

#ifdef WIN32
#  include <windows.h>
#endif

#include <GL/gl.h>

#include "veStd.h"
#include "veTypes.h"
#include "veMath.h"

class TexFont;

// veLib standard namespace - look into veStd.h for more documentation
namespace ve {
    class xmlIni;
    class image;

//--- definitions and constants ------------------------------------ /*fold00*/

/// symbolic names for the alignment of overlay objects and text
enum align_t{ ALIGN_LEFT, ALIGN_CENTER, ALIGN_RIGHT,
               ALIGN_BOTTOM, ALIGN_TOP } ;

//--- functions ---------------------------------------------------- /*fold00*/
/// checks whether a certain gl extension is available
bool hasGlExtension(const std::string & which);


//--- class glText ------------------------------------------------- /*fold00*/
/// an abstract base class for OpenGL font renderers.
class glText {
public:
    /// constructor.
    /**
     \param fontName defines font file name and path,
     \param fontSize (optional, default=24) defines font size.
     */
    glText(const std::string & fontName, float fontSize);
    /// draws string s at position x|y|z.
    virtual void draw(const std::string & s, float x, float y, float z=0)=0;
    /// draws a string containing new lines at position x|y|z.
    virtual void multiLineDraw(const std::string & s, float x, float y, float z=0, ve::align_t align=ve::ALIGN_LEFT)=0;
    /// returns width of a string
    virtual float w(const std::string & str) const=0;
    /// returns maximum ascent of the current font
    float ascent() const { return maxAscent; };
    /// returns maximum descent of the current font
    float descent() const { return maxDescent; };
    /// returns font size in point
    float fontSize() const { return fntSize; };
protected:
    /// stores font size
    float fntSize;
    /// stores maxAscent of the font.
    float maxAscent;
    /// stores maxDescent of the font.
    float maxDescent;
};

//--- class glTextTxf ---------------------------------------------- /*fold00*/

/// a class for rendering txf texture fonts in OpenGL.
/**
 This class is mainly an improved wrapper for MJKs standard C txf functions.
 For more information about the txf format in general,
 also about the creation of font sets, see
 http://www.sgi.com/software/opengl/examples/glut/texfont/

 The original license statement of MJK:\n
 This program part is freely distributable without licensing
 fees and is provided without guarantee or warrantee expressed or implied.
 This program part is -not- in the public domain.

 Copyright (c) partially by Mark J. Kilgard, 1997\n
 Copyright (c) partially by Gerald Franz, 2002

 \author  gf, based on the work of Mark J. Kilgard
 $Revision: 2.0 $
 */

class glTextTxf : public ve::glText {
public:
    /// constructor.
    /**
     \param fontName defines font file name and path,
     \param fontSize (optional, default=24) defines font size.
     */
    glTextTxf(const std::string & fontName, float fontSize=24);
    /// destructor
    virtual ~glTextTxf();
    /// draws the string str at position x|y|z.
    virtual void draw(const std::string & s, float x, float y, float z=0);
    /// draws a string containing new lines at position x|y|z.
    virtual void multiLineDraw(const std::string & s, float x, float y, float z=0, ve::align_t align=ve::ALIGN_LEFT);
    /// returns width of a string
    virtual float w(const std::string & str) const;
protected:
    /// pointer to the internal TexFont class
    TexFont *txf;
};


//--- struct _ovlResource ------------------------------------------ /*fold00*/

///\internal a helper struct storing resource definitions
struct _ovlResource {
    unsigned int id;
    unsigned int mime;
    std::string str;
};

//--- class ovlPlane ----------------------------------------------- /*fold00*/
class ovlObj;

/// a class for managing overlay objects derived from ovlObj.
class ovlPlane {
public:
  friend class ve::ovlObj;
    /** \brief constructor.
     \param ini is an xmlStatement containing additional descriptions,
     \param iniSectionId (optional) defines which deviceWindow of the inifile should be interpreted. */
    ovlPlane(ve::xmlIni & ini, unsigned int iniSectionId=0);
    /// destructor
    ~ovlPlane();
    /// sets output of device
    /** In this case the method tells the overlay plane about the
     current input device state for interactive overlay objects. */
    int setOutput(const ve::vec6f & inputAxes, const ve::flag128 & inputState);
    /// draws overlay plane
    void draw();

    /// adds an overlay object
    /** \param resourceId a unique id for the resource
     \param objectId a unique id for the object
     \param xPos (optional) x position in overlay coordinates
     \param yPos (optional) y position in overlay coordinates
     \param width (optional) width in overlay coordinates
     \param height (optional) height position in overlay coordinates
     \param alH (optional) horizontal alignment
     \param alV (optional) vertical alignment
     \param r (optional) RGBA red color value
     \param g (optional) RGBA green color value
     \param b (optional) RGBA blue color value
     \param a (optional) RGBA alpha component
     \param uiParam0 (optional) for text labels this parameter denotes the font resource id, otherwise unused
     \param uiParam1 (optional) currently unused
     \param lifespan (optional) the life expectancy of this object, use 0.0 for unlimited
     \param fParam1 (optional)  currently unused
     \return 0 in case of success. */
    int addObject(unsigned int resourceId, unsigned int objectId, float xPos=0.0f, float yPos=0.0f,
                  float width=1.0f, float height=1.0f, align_t alH=ALIGN_CENTER, align_t alV=ALIGN_CENTER,
                  float r=0.0f, float g=0.0f, float b=0.0f, float a=0.0f,
                  unsigned int uiParam0=0, unsigned int uiParam1=0,
                  float lifespan=0.0f, float fParam1=0.0f);
    /// removes an object instance from the overlay plane.
    /** \param objectId identifies the object instance.
     \return 0 in case of success. */
    int dropObject(unsigned int objectId);
    /// updates an overlay object
    /** \param objectId a unique id for the object
     \param xPos (optional) x position in overlay coordinates
     \param yPos (optional) y position in overlay coordinates
     \param width (optional) width in overlay coordinates
     \param height (optional) height position in overlay coordinates
     \param alH (optional) horizontal alignment
     \param alV (optional) vertical alignment
     \param r (optional) RGBA red color value
     \param g (optional) RGBA green color value
     \param b (optional) RGBA blue color value
     \param a (optional) RGBA alpha component
     \param uiParam0 (optional) currently unused
     \param uiParam1 (optional) currently unused
     \param fParam0  (optional) currently unused
     \param fParam1  (optional) currently unused
     \return 0 in case of success. */
    int updateObject(unsigned int objectId, float xPos=0.0f, float yPos=0.0f, 
                     float width=1.0f, float height=1.0f, align_t alH=ALIGN_CENTER, align_t alV=ALIGN_CENTER,
                     float r=0.0f, float g=0.0f, float b=0.0f, float a=0.0f,
                     unsigned int uiParam0=0, unsigned int uiParam1=0,
                     float fParam0=0.0f, float fParam1=0.0f);
    /// adds a resource at runtime
    /**
     \param resourceId a unique id for the resource
     \param str      a url defining the resource file or the string to be displayed
     \param mime     the mime-type of the resource
     \param uiParam1 (optional) currently unused
     \param fParam0 (optional)  currently unused
     \param fParam1 (optional)  currently unused
     \return 0 in case of success. */
    int addResource(unsigned int resourceId,
                    const std::string & str,
                    unsigned int mime,
                    unsigned int uiParam1=0,
                    float fParam0=1.0f,
                    float fParam1=1.0f);
    /// updates an overlay (label text) resource
    /** \param resourceId identifies the resource,
     \param newText the text to be set,
     \return 0 in case of success. */
    int setResource(unsigned int resourceId, const std::string & newText);

    /// adds an overlay object
    /** this method should not be called directly but by ovlObj::activate()
     or via addObject(). */
    void addObj(ovlObj * ovlObject);
    /// drops an overlay object
    /** this method should not be called directly but by ovlObj::deactivate()
     or via dropObject(). */
    void dropObj(ovlObj * ovlObject);
    /// drops all overlay objects
    void clear();

    /// makes input device state available for interactive overlay objects
    const ve::flag128 & inputState() const { return inputStatus; };
    /// returns mouse x position in ovl coordinates
    float mouseX() const { return mouseXPos; };
    /// returns mouse y position in ovl coordinates
    float mouseY() const { return mouseYPos; };
    /// transforms x overlay ordinate in x screen ordinate
    float screenX(float x) const { return m_winSizeX*(x-x0)/(x1-x0); };
    /// transforms y overlay ordinate in y screen ordinate
    float screenY(float y) const { return m_winSizeY*(y-y0)/(y1-y0); };
    /// transforms x screen ordinate in x ovl ordinate
    float ovlX(float x) const { return x0+(x/m_winSizeX)*(x1-x0); };
    /// transforms y overlay ordinate in y ovl ordinate
    float ovlY(float y) const { return y0+(y/m_winSizeY)*(y1-y0); };
    /// returns minimum x coordinate
    float minX() const { return x0; };
    /// returns minimum x coordinate
    float minY() const { return y0; };
    /// returns maximum x coordinate
    float maxX() const { return x1; };
    /// returns maximum x coordinate
    float maxY() const { return y1; };
    /// returns width
    float w() const { return x1-x0; };
    /// returns height
    float h() const { return y1-y0; };
    /// sets standard foreground color
    void fgNormalColor(float r, float g, float b, float a=1.0f );
    /// sets standard background color
    void bgNormalColor(float r, float g, float b, float a=1.0f );
    /// sets selected foreground color
    void fgSelectColor(float r, float g, float b, float a=1.0f );
    /// sets selected background color
    void bgSelectColor(float r, float g, float b, float a=1.0f );
    /// returns standard foreground color
    const float * fgNormalColor() const { return fgNormalCol; };
    /// returns standard background color
    const float * bgNormalColor() const { return bgNormalCol; };
    /// returns selected foreground color
    const float * fgSelectColor() const { return fgSelectCol; };
    /// returns selected background color
    const float * bgSelectColor() const { return bgSelectCol; };
    /// returns pointer to text renderer with suitable id, or a default text renderer if available, otherwise 0
    ve::glText * textRenderer(unsigned int id);
protected:
    /// stores pointers to overlay object resources
    std::vector <ve::_ovlResource> vResource;
    /// stores pointers to overlay objects that are drawn
    std::vector <ve::ovlObj *> vObject;
    /// vector for storing the object ids of the current scene object instances
    std::vector<unsigned int> vObjectId; // should be better a hash table?
    /// vector for storing the resource ids of the current scene object instances
    std::vector<unsigned int> vObjectResourceId; 
    /// vector for storing expiring times
    std::vector<double> vExpire;

    /// stores window width
    unsigned int m_winSizeX;
    /// stores window height
    unsigned int m_winSizeY;
    /// stores viewport minimum x ordinate
    float x0;
    /// stores viewport minimum y ordinate
    float y0;
    /// stores viewport maximum x ordinate
    float x1;
    /// stores viewport maximum y ordinate
    float y1;
    /// stores standard foreground (font) color
    float fgNormalCol[4];
    /// stores selected foreground (font) color
    float fgSelectCol[4];
    /// stores standard background color
    float bgNormalCol[4];
    /// stores selected background color
    float bgSelectCol[4];
    /// stores mouse x position in ovl coordinates
    float mouseXPos;
    /// stores mouse y position in ovl coordinates
    float mouseYPos;
    /// stores input state
    ve::flag128 inputStatus;
    /// stores pointers to text renderers which are used for overlay labels
    std::vector<ve::glText *> vTxtRenderer;
    /// stores ids of text renderers
    std::vector<unsigned int> vTxtRendererId;
};

//--- class ovlObj ------------------------------------------------- /*fold00*/

/// parent class for 2D overlay objects.
/** Its subclasses allow to build a simple but very portable GUI
 entirely based on OpenGL. ovlObj are always managed by an ovlPlane object.
 */
class ovlObj {
public:
    /// constructor
    ovlObj(ve::ovlPlane * plane, float xPos=0, float yPos=0, ve::align_t alH=ve::ALIGN_LEFT, ve::align_t alV=ve::ALIGN_BOTTOM);
    /// destructor
    virtual ~ovlObj() { if(pOvl) pOvl->dropObj(this); };
    /// draws widget dummy
    virtual void draw() { ; };
    /// returns x position
    virtual float x() const { return m_x; };
    /// returns y position
    virtual float y() const { return m_y; };
    /// sets x position
    virtual void x(float xPos) { m_x=xPos; };
    /// sets y position
    virtual void y(float yPos) { m_y=yPos; };
    /// returns width
    virtual float w() const { return m_w; };
    /// returns height
    virtual float h() const { return m_h; };
     /// sets width
    virtual void w(float width) { m_w=width; ovlObj::init(); };
    /// sets height
    virtual void h(float height) { m_h=height; ovlObj::init(); };
     /// sets horizontal alignment
    virtual void alH(ve::align_t hAl) { alignH=hAl; ovlObj::init(); };
    /// sets vertical alignment
    virtual void alV(ve::align_t vAl) { alignV=vAl; ovlObj::init(); };

    /// handles events, interface definition
    /** automatically called by overlay plane */
    virtual void update() { ; };
    /// activates widget (standard is off).
    /** It gets drawn and events are handled. */
    virtual void activate();
    /// deactivates widget
    /** It does not get drawn and events are not handled. */
    virtual void deactivate();
    /// returns state of activity
    bool active() const { return isActive; };
    /// returns reference to overlay plane.
    ovlPlane * & overlay() { return pOvl; };
protected:
    /// performs internal initializations, e. g. computes alignment values
    virtual void init();
    /// stores x position
    float m_x;
    /// stores y position
    float m_y;
    /// stores width
    float m_w;
    /// stores height
    float m_h;
    /// stores horizontal alignment state
    ve::align_t alignH;
    /// stores vertical alignment state
    ve::align_t alignV;
    /// stores actual horizontal translation caused by alignment
    float dAlignH;
    /// stores actual vertical translation caused by alignment
    float dAlignV;
    /// stores pointer to current overlay plane
    ve::ovlPlane * pOvl;
    /// stores state of activity
    bool isActive;
};

//--- class ovlLabel ----------------------------------------------- /*fold00*/

/// a single line text overlay widget.
class ovlLabel : public ovlObj {
public:
    /// constructor
    /** \param plane pointer to the ovlPlane
     \param str (optional) initial string
     \param xPos (optional) x position in overlay coordinates
     \param yPos (optional) y position in overlay coordinates
     \param width (optional) width in overlay coordinates, use 0.0 for automatic width according to initial string
     \param height (optional) height in overlay coordinates, use 0.0 for automatic height
     \param alH (optional) horizontal align
     \param alV (optional) vertical align
     \param textRendererId (optional) resource id of font
     */
    ovlLabel(ve::ovlPlane * plane, const std::string & str="", float xPos=0, float yPos=0, float width=0.0f, float height=0.0f,
             ve::align_t alH=ve::ALIGN_LEFT, ve::align_t alV=ve::ALIGN_BOTTOM, unsigned int textRendererId=0);
    /// draws widget
    virtual void draw();
    /// returns current label text
    virtual const std::string & str() const { return text; };
    /// sets current label text
    virtual void str(const std::string & txt);
    /// sets text color
    void fgNormalColor(float r, float g, float b, float a=1.0f );
    /// sets background color
    void bgNormalColor(float r, float g, float b, float a=1.0f );
    /// sets selected foreground color
    void fgSelectColor(float r, float g, float b, float a=1.0f );
    /// sets selected background color
    void bgSelectColor(float r, float g, float b, float a=1.0f );
    /// returns standard foreground color
    const float * fgNormalColor() const { return fgNormalCol; };
    /// returns standard background color
    const float * bgNormalColor() const { return bgNormalCol; };
    /// returns selected foreground color
    const float * fgSelectColor() const { return fgSelectCol; };
    /// returns selected background color
    const float * bgSelectColor() const { return bgSelectCol; };
    /// returns true if widget is currently selected, otherwise false
    bool isSelected() const { return m_selected; };
protected:
    /// stores currently displayed text
    std::string text;
    /// stores text color
    float fgNormalCol[4];
    /// stores text background color, only used in derived classes
    float bgNormalCol[4];
    /// selected background color, only used in derived classes
    float bgSelectCol[4];
    /// foreground color when selected, only used in derived classes
    float fgSelectCol[4];
    /// stores pointer to suitable text renderer
    ve::glText * m_pTextRenderer;
    /// stores state of selection
    bool m_selected;
};

//--- class ovlRect ------------------------------------------------ /*fold00*/

/// a class for displaying untextextured rectangles in the overlay plane.
class ovlRect: public ovlObj {
public:
    /// standard constructor without texture.
    ovlRect(ve::ovlPlane * plane, float xPos=0, float yPos=0, float width=1.0, float height=1.0,
            ve::align_t alH = ve::ALIGN_LEFT, ve::align_t alV = ve::ALIGN_BOTTOM, float r = 1.0, float g = 0.0, float b = 1.0, float a = 1.0);
    /// draws widget
    virtual void draw();
    /// sets color
    void color(float r, float g, float b, float a=1.0f );
    /// returns the texture filename
protected:
      /// is true if size of object is absolute, otherwise false
    bool sizeAbs;
    /// current color of widget
    float col[4];
};
//--- class ovlImage ----------------------------------------------- /*fold00*/
/// a class for displaying images in the overlay plane.
class ovlImage: public ovlRect {
public:
    /// constructor with texture file.
    ovlImage(ve::ovlPlane * plane, const std::string & filename, float xPos=0, float yPos=0, float width=1.0, float height=1.0,
              ve::align_t alH=ve::ALIGN_LEFT, ve::align_t alV=ve::ALIGN_BOTTOM, bool repeat=true );
    /// constructor with texture file, image will be display unscaled.
    ovlImage(ve::ovlPlane * plane, const std::string & filename, float xPos, float yPos,
              ve::align_t alH=ve::ALIGN_LEFT, ve::align_t alV=ve::ALIGN_BOTTOM, bool repeat=true );
    /// constructor taking texture from veImage object.
    ovlImage(ve::ovlPlane * plane, const ve::image & img, float xPos, float yPos, float width, float height,
              ve::align_t alH=ve::ALIGN_LEFT, ve::align_t alV=ve::ALIGN_BOTTOM, bool repeat=true );
    /// draws widget
    virtual void draw();
    /// returns the texture filename
    virtual const std::string & filename() const { return strFile; };

protected:
    /// stores byte depth of texture
    int byteDepth;
    /// stores texture id
    unsigned int texId;
    /// stores existence of texture
    int textured;
    /// stores the texture filename
    std::string strFile;
};

} // namespace ve

//--- cvs history log ---------------------------------------------- /*FOLD00*/
/*
 * $Log: veGlUtils.h,v $
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.65  2004/11/01 10:50:23  gf
 * - cleanup dependencies
 * - ovlLabel now complete
 *
 * Revision 1.64  2004/10/27 12:47:58  gf
 * documentation updates and naming conventions unified
 *
 * Revision 1.63  2004/10/20 12:14:08  gf
 * ovlLabels are now truncated to fit to the initially given width and height
 *
 * Revision 1.62  2004/10/19 12:47:20  gf
 * - individual device::id() added, old id is now called typeId()
 * - dataContainer now has a counter variable
 * - handling of multiple fonts in overlay completed
 *
 * Revision 1.61  2004/10/18 11:10:14  gf
 * - mime type for txf fonts added
 * - framework for handling multiple fonts added, not completely implemented
 * - dataContainer::type() now changeable after construction
 *
 * Revision 1.60  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.59  2004/10/14 14:56:56  gf
 * - nasty little bug in veGlUtils, ovl::dropObj() fixed
 * - some doxygen warnings removed
 *
 * Revision 1.58  2004/10/08 17:36:58  gf
 * cleanup of unused classes
 *
 * Revision 1.57  2004/10/04 09:38:43  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.56  2004/09/28 12:21:47  gf
 * ovlLabels are now rendered identically to ovlButtons (to come)
 *
 * Revision 1.55  2004/09/24 07:46:32  gf
 * unused methods of overlay plane removed
 *
 * Revision 1.54  2004/09/23 15:08:46  gf
 * - resourceIdMax and objectIdMax variables and methods added for devices
 * - dynamic overlay text now uses correct updateResource mechanism
 *
 * Revision 1.53  2004/09/14 15:32:01  gf
 * vec6f + and - operators added, small interface change in ovlObj
 *
 * Revision 1.52  2004/09/13 08:32:46  gf
 * ovlObj alignment now reacts to resize
 *
 * Revision 1.51  2004/08/20 08:48:10  gf
 * - VECERR replaced by std::cerr
 * - dynamic overlay text implemented, affecting veDeviceSDL, veGlUtils, veTypes, veDataContainer
 *
 * Revision 1.50  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.49  2004/07/01 15:33:48  gf
 * - deviceXYZ::update() methods are now unified
 */
#endif // _VE_GL_UTILS_H
