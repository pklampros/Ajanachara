#ifndef _VE_LOAD3DS_H
#define _VE_LOAD3DS_H

/** @file veLoad3ds.h
 \brief A basic 3ds loader class

 This file is substancially based on a tutorial by

 Ben Humphrey (DigiBen)\n
 Game Programmer\n
 DigiBen@GameTutorials.com\n
 Co-Web Host of www.GameTutorials.com\n

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author gf

 $Revision: 1.1 $ 
 */

#include<veStd.h>
#include<veMath.h>

// forward declaration
struct _chunk;

namespace ve {
//--- internal data structures ------------------------------------- /*fold00*/
/// \internal This class holds the information for a material.
/** \internal It may be a texture map of a color.
 Some of these are not used, but I left them because you will want to eventually
 read in the UV tile ratio and the UV tile offset for some models. */
class _materialInfo {
public:
    /// default constructor
    _materialInfo();
    /// the texture name
    char  matName[255];
    /// the texture file name (If this is set it's a texture map)
    char  fileName[255];
    /// the color of the object (R, G, B)
    unsigned char color[3];
    /// the opacity of the object (A)
    float opacity;
} ;

/// \internal this class stores a material reference
class _materialRef {
public:
    /// default constructor
    _materialRef() { matName[0]=0; };
    /// The material name of the object
    char matName[255];
    /// stores face indices
    std::vector<unsigned short> vFace;
};

/// \internal This class holds all the information of a part of our model
class _3dsObject {
public:
    /// default constructor
    _3dsObject() { objName[0]=0; };
    /// The name of the object
    char objName[255];

    /// The object's vertices
    std::vector<ve::vec3f> vCoords;
    /// The texture's UV coordinates
    std::vector<ve::vec2f> vTexCoords;

    /// stores indices
    std::vector<unsigned int> vIndices;
    /// stores indices of face ends
    std::vector<unsigned int> vFaceEnds;
    /// stores assigned materials
    std::vector<_materialRef> vMaterial;
};


//--- 3dsLoaderClass declaration ----------------------------------- /*fold00*/
    class geoObj;

/// this class handles the loading of 3ds files
class io3ds {
public:
    /// constructor initializing the data members
    io3ds();
    /// this method loads the 3ds geometry
    int load(const std::string & strFileName, std::vector<ve::geoObj*> & vMesh);
protected:
    /// stores children
    std::vector<_3dsObject> vChildren;
    /// stores materials
    std::vector<_materialInfo> vMaterial;

    /// This reads in a string and saves it in the char array passed in
    int getString(char *);
    /// This reads the next chunk
    void readChunk(_chunk *);
    /// This reads the next large chunk
    void processNextChunk(_chunk *);
    /// This reads the object chunks
    void processNextObjectChunk(_3dsObject *pObject, _chunk *);
    /// This reads the material chunks
    void processNextMaterialChunk(_chunk *);
    /// This reads the RGB value for the object's color
    void readColorChunk(_materialInfo *pMaterial, _chunk *pChunk);
    ///  this method reads transparency data
    void readTranspChunk(_materialInfo *pMaterial, _chunk *pChunk);
    /// This reads the objects vertices
    void readVertices(_3dsObject *pObject, _chunk *);
    /// This reads the objects face information
    void readVertexIndices(_3dsObject *pObject, _chunk *);
    /// This reads the texture coodinates of the object
    void readUVCoordinates(_3dsObject *pObject, _chunk *);
    /// This reads in the material name assigned to the object and sets the materialID
    void readObjectMaterial(_3dsObject *pObject, _chunk *pPreviousChunk);
    /// This frees memory and closes the file
    void cleanUp();

    /// The file pointer
    FILE *m_FilePointer;
    /// this pointer is used through the loading process to hold the chunk information
    _chunk *m_CurrentChunk;
    /// this pointer is used through the loading process to hold the chunk information
    _chunk *m_TempChunk;
    /// this buffer is used to skip unwanted data when reading
    int buffer[50000];
};

} // namespace ve

//--- cvs history log: --------------------------------------------- /*FOLD00*/
/*
 * $Log: veIo3ds.h,v $
 * Revision 1.1  2004/12/06 11:16:09  gf
 * load3ds renamed to io3ds in order to fit better into the upcoming loader
 * structure of veGeoObj
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.7  2004/10/27 12:47:58  gf
 * documentation updates and naming conventions unified
 *
 * Revision 1.6  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.5  2004/10/04 09:38:43  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.4  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.3  2004/04/28 14:19:06  gf
 * adaptations to version 0.9
 *
 * Revision 1.2  2004/04/20 10:16:45  gf
 * - 3ds loader now interprets transparency
 * - better compatibility to X3D, but translation not yet finished!
 *
 * Revision 1.1  2004/04/16 13:34:39  gf
 * - basic 3dsLoader for ve::geoMeshes added, some corresponding adaptations
 * - some VC6 trash undone
 */
#endif
