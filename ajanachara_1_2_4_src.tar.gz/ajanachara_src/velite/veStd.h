#ifndef INCLUDED_VESTD
#define INCLUDED_VESTD
/** @file veStd.h
 \brief Central definition of included standard headers.

 This file hides platform dependent naming differences of C++ standard
 headers from the user. It should be used instead of direct includes.
 
 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author mvdh

 $Revision: 2.0 $
 */

#ifdef _MSC_VER // MS Visual C++
// disable warning C4786: symbol greater than 255 character,
// okay to ignore
#pragma warning(disable: 4786)
#endif

#include "veConfig.h"

#ifdef _HAVE_ACE
#  include <ace/OS.h>
#  include <ace/Log_Msg.h>
#endif

#if defined __WIN32__ || defined WIN32
#define _WINSOCKAPI_
#  include <windows.h>
#endif

#ifdef _MSC_VER // MS Visual C++
// disable warning C4786: symbol greater than 255 character,
// okay to ignore
#pragma warning(disable: 4786)
#endif

#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cassert>

// using namespace std; // please include in all cpp files where this file is also included...

/// Additions to the standard namespace
/**
 In many classes (p.e. veMath, veXml, ...) the standard output
 operator<<() is overloaded.
 */
namespace std {
}

//--- cvs history log --------------------------------------------- /*FOLD00*/
/*
 * $Log: veStd.h,v $
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.26  2004/10/27 12:47:58  gf
 * documentation updates and naming conventions unified
 *
 * Revision 1.25  2004/10/04 09:38:43  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.24  2004/09/08 09:30:24  weyel
 * -veDeviceNetworkUDP optimized
 * -veLib now compiles without ACE on windows and linux
 *
 * Revision 1.23  2004/08/20 08:48:10  gf
 * - VECERR replaced by std::cerr
 * - dynamic overlay text implemented, affecting veDeviceSDL, veGlUtils, veTypes, veDataContainer
 *
 * Revision 1.22  2004/04/02 13:06:52  gf
 * unknown change
 *
 * Revision 1.21  2004/01/12 17:13:11  gf
 * documentation updated
 *
 * Revision 1.20  2003/12/12 16:39:22  gf
 * just small changes, leading to hours of unproductive work: definitions
 * ubited in veTypes.h some #defines moved to const unsigned int
 *
 * Revision 1.19  2003/12/12 12:55:30  gf
 * second intermediate step towards integrating libSDL into veLib
 *
 * Revision 1.18  2003/12/01 17:02:04  gf
 * improvements of non-ACE functionality
 *
 * Revision 1.17  2003/11/27 16:23:32  gf
 * some paradox dependencies from ACE resolved
 *
 * Revision 1.16  2003/11/24 17:34:28  mvdh
 * veMath: include <cmath> added; veIO: small bug reading zip directories corrected;
 * veStd.h: some constants for ALT, CTRL, SHIFT added (gf)
 *
 * Revision 1.15  2003/11/17 15:57:02  mvdh
 * adaptio to removal of veUtils class
 *
 * Revision 1.14  2003/10/28 14:34:15  gf
 * some handy constants added, maybe not the most perfect place, but 
 * the veLib currently lacks sometihing like a veTypes.h or veDefs.h or veConsts.h
 *
 * Revision 1.13  2003/07/25 13:52:57  weyel
 * replaced HAVEACE with _HAVE_ACE
 *
 * Revision 1.12  2003/07/25 10:37:24  mvdh
 * sstream not longer part of veStd. Since it does not work correctly under IRIX,
 * it should be generally avoided.
 *
 * Revision 1.11  2003/07/04 12:19:15  mvdh
 * simple debug output without ACE
 *
 * Revision 1.10  2003/06/24 14:22:12  weyel
 * ignore "#ident ignored" warning from MSVC compiler
 *
 * Revision 1.9  2003/06/23 14:57:12  weyel
 * made it compile with new talk version
 *
 * Revision 1.8  2003/06/02 07:44:42  mvdh
 * added sstream for strstream (string streams)
 *
 * Revision 1.7  2003/05/26 10:39:10  mvdh
 * more documentation
 *
 * Revision 1.6  2003/05/21 09:15:23  mvdh
 * fixed several doxygen errors and warnings
 *
 * Revision 1.5  2003/05/16 16:09:11  mvdh
 * some changes to make the version compile on IRIX and run on Linux
 *
 * Revision 1.4  2003/04/22 17:15:16  gf
 * documentation update
 *
 * Revision 1.3  2003/04/01 09:57:57  gf
 * instead of WIN32 use of _MSC_VER, for keeping MinGW compatibility. If this
 * does not work under Visual C++ pleas let me know to find a better solution!
 *
 * Revision 1.2  2003/03/25 21:33:32  mvdh
 * doxygenify most standard doc++ statements
 *
 * Revision 1.1  2003/03/25 17:29:00  mvdh
 * major changes in most files - cebit version from MvdH now in action - please watch out for eventual errors and conflicts - now windows and linux support
 */
#endif // INCLUDED_VESTD
