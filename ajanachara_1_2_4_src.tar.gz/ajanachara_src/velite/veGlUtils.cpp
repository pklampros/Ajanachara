// veGlUtils auxilliary functions
// started 2002 by Gerald.Franz@tuebingen.mpg.de

#include "veStd.h"

#include <GL/gl.h>
#include <GL/glu.h>
#include <typeinfo>

#include "veStrUtils.h"
#include "veGlUtils.h"
#include "veUtils.h"
#include "veImage.h"
#include "veXml.h"
#include "veStrUtils.h"

using namespace std;
using namespace ve;

//--- functions ---------------------------------------------------- /*fold00*/

bool ve::hasGlExtension(const string & which) {
   string extStr((const char *)glGetString ( GL_EXTENSIONS ));
   vector<string> extensions;
   split(extStr,extensions);
   for(unsigned int i=0; i<extensions.size(); i++)
       if(which==extensions[i]) return true;
   return false;
}

//--- txf functions (c) mainly Mark J. Kilgard, 1997 --------------- /*fold00*/

/* This program part (txf...) is freely distributable without licensing
 fees and is provided without guarantee or warrantee expressed or implied.
 This program part (txf...) is -not- in the public domain. */

#define TXF_FORMAT_BYTE		0
#define TXF_FORMAT_BITMAP	1

typedef struct {
  unsigned short c;       /* Potentially support 16-bit glyphs. */
  unsigned char width;
  unsigned char height;
  signed char xoffset;
  signed char yoffset;
  signed char advance;
  char dummy;           /* Space holder for alignment reasons. */
  short x;
  short y;
} TexGlyphInfo;

typedef struct {
  GLfloat t0[2];
  GLshort v0[2];
  GLfloat t1[2];
  GLshort v1[2];
  GLfloat t2[2];
  GLshort v2[2];
  GLfloat t3[2];
  GLshort v3[2];
  GLfloat advance;
} TexGlyphVertexInfo;

class TexFont {
public:
    GLuint texobj;
    int tex_width;
    int tex_height;
    int max_ascent;
    int max_descent;
    int num_glyphs;
    int min_glyph;
    int range;
    unsigned char *teximage;
    TexGlyphInfo *tgi;
    TexGlyphVertexInfo *tgvi;
    TexGlyphVertexInfo **lut;
};

int useLuminanceAlpha = 1;

/* byte swap a 32-bit value */
#define SWAPL(x, n) { \
    n = ((char *) (x))[0];\
    ((char *) (x))[0] = ((char *) (x))[3];\
    ((char *) (x))[3] = n;\
    n = ((char *) (x))[1];\
    ((char *) (x))[1] = ((char *) (x))[2];\
    ((char *) (x))[2] = n; }

/* byte swap a short */
#define SWAPS(x, n) { \
    n = ((char *) (x))[0];\
    ((char *) (x))[0] = ((char *) (x))[1];\
    ((char *) (x))[1] = n; }

static char *lastError;

char *txfErrorString(void) {
    return lastError;
}

TexFont *txfLoadFont(const char *filename) {
    TexFont *txf;
    FILE *file;
    GLfloat w, h, xstep, ystep;
    char fileid[4], tmp;
    unsigned char *texbitmap;
    int min_glyph, max_glyph;
    int endianness, swap, format, stride, width, height;
    int i, j, got;

    txf = NULL;
    file = fopen(filename, "rb");
    if (file == NULL) {
        lastError = "file open failed.";
        goto error;
    }
    txf = (TexFont *) malloc(sizeof(TexFont));
    if (txf == NULL) {
        lastError = "out of memory.";
        goto error;
    }
    /* For easy cleanup in error case. */
    txf->tgi = NULL;
    txf->tgvi = NULL;
    txf->lut = NULL;
    txf->teximage = NULL;

    txf->texobj=0; // by GF, otherwise not initialized

    got = static_cast<int>(fread(fileid, 1, 4, file));
    if (got != 4 || strncmp(fileid, "\377txf", 4)) {
        lastError = "not a texture font file.";
        goto error;
    }
    assert(sizeof(int) == 4);  /* Ensure external file format size. */
    got = static_cast<int>(fread(&endianness, sizeof(int), 1, file));
    if (got == 1 && endianness == 0x12345678) {
        swap = 0;
    } else if (got == 1 && endianness == 0x78563412) {
        swap = 1;
    } else {
        lastError = "not a texture font file.";
        goto error;
    }
#define EXPECT(n) if (got != n) { lastError = "premature end of file."; goto error; }
    got = static_cast<int>(fread(&format, sizeof(int), 1, file));
    EXPECT(1);
    got = static_cast<int>(fread(&txf->tex_width, sizeof(int), 1, file));
    EXPECT(1);
    got = static_cast<int>(fread(&txf->tex_height, sizeof(int), 1, file));
    EXPECT(1);
    got = static_cast<int>(fread(&txf->max_ascent, sizeof(int), 1, file));
    EXPECT(1);
    got = static_cast<int>(fread(&txf->max_descent, sizeof(int), 1, file));
    EXPECT(1);
    got = static_cast<int>(fread(&txf->num_glyphs, sizeof(int), 1, file));
    EXPECT(1);

    if (swap) {
        SWAPL(&format, tmp);
        SWAPL(&txf->tex_width, tmp);
        SWAPL(&txf->tex_height, tmp);
        SWAPL(&txf->max_ascent, tmp);
        SWAPL(&txf->max_descent, tmp);
        SWAPL(&txf->num_glyphs, tmp);
    }
    txf->tgi = (TexGlyphInfo *) malloc(txf->num_glyphs * sizeof(TexGlyphInfo));
    if (txf->tgi == NULL) {
        lastError = "out of memory.";
        goto error;
    }
    assert(sizeof(TexGlyphInfo) == 12);  /* Ensure external file format size. */
    got = static_cast<int>(fread(txf->tgi, sizeof(TexGlyphInfo), txf->num_glyphs, file));
    EXPECT(txf->num_glyphs);

    if (swap) {
        for (i = 0; i < txf->num_glyphs; i++) {
            SWAPS(&txf->tgi[i].c, tmp);
            SWAPS(&txf->tgi[i].x, tmp);
            SWAPS(&txf->tgi[i].y, tmp);
        }
    }
    txf->tgvi = (TexGlyphVertexInfo *)
        malloc(txf->num_glyphs * sizeof(TexGlyphVertexInfo));
    if (txf->tgvi == NULL) {
        lastError = "out of memory.";
        goto error;
    }
    w = static_cast<float>(txf->tex_width);
    h = static_cast<float>(txf->tex_height);
    xstep = 0.5f / w;
    ystep = 0.5f / h;
    for (i = 0; i < txf->num_glyphs; i++) {
        TexGlyphInfo *tgi;

        tgi = &txf->tgi[i];
        txf->tgvi[i].t0[0] = tgi->x / w + xstep;
        txf->tgvi[i].t0[1] = tgi->y / h + ystep;
        txf->tgvi[i].v0[0] = tgi->xoffset;
        txf->tgvi[i].v0[1] = tgi->yoffset;
        txf->tgvi[i].t1[0] = (tgi->x + tgi->width) / w + xstep;
        txf->tgvi[i].t1[1] = tgi->y / h + ystep;
        txf->tgvi[i].v1[0] = tgi->xoffset + tgi->width;
        txf->tgvi[i].v1[1] = tgi->yoffset;
        txf->tgvi[i].t2[0] = (tgi->x + tgi->width) / w + xstep;
        txf->tgvi[i].t2[1] = (tgi->y + tgi->height) / h + ystep;
        txf->tgvi[i].v2[0] = tgi->xoffset + tgi->width;
        txf->tgvi[i].v2[1] = tgi->yoffset + tgi->height;
        txf->tgvi[i].t3[0] = tgi->x / w + xstep;
        txf->tgvi[i].t3[1] = (tgi->y + tgi->height) / h + ystep;
        txf->tgvi[i].v3[0] = tgi->xoffset;
        txf->tgvi[i].v3[1] = tgi->yoffset + tgi->height;
        txf->tgvi[i].advance = tgi->advance;
    }

    min_glyph = txf->tgi[0].c;
    max_glyph = txf->tgi[0].c;
    for (i = 1; i < txf->num_glyphs; i++) {
        if (txf->tgi[i].c < min_glyph) {
            min_glyph = txf->tgi[i].c;
        }
        if (txf->tgi[i].c > max_glyph) {
            max_glyph = txf->tgi[i].c;
        }
    }
    txf->min_glyph = min_glyph;
    txf->range = max_glyph - min_glyph + 1;

    txf->lut = (TexGlyphVertexInfo **)
        calloc(txf->range, sizeof(TexGlyphVertexInfo *));
    if (txf->lut == NULL) {
        lastError = "out of memory.";
        goto error;
    }
    for (i = 0; i < txf->num_glyphs; i++) {
        txf->lut[txf->tgi[i].c - txf->min_glyph] = &txf->tgvi[i];
    }

    switch (format) {
    case TXF_FORMAT_BYTE:
        if (useLuminanceAlpha) {
            unsigned char *orig;

            orig = (unsigned char *) malloc(txf->tex_width * txf->tex_height);
            if (orig == NULL) {
                lastError = "out of memory.";
                goto error;
            }
            got = static_cast<int>(fread(orig, 1, txf->tex_width * txf->tex_height, file));
            EXPECT(txf->tex_width * txf->tex_height);
            txf->teximage = (unsigned char *)
                malloc(2 * txf->tex_width * txf->tex_height);
            if (txf->teximage == NULL) {
                lastError = "out of memory.";
                goto error;
            }
            for (i = 0; i < txf->tex_width * txf->tex_height; i++) {
                txf->teximage[i * 2] = orig[i];
                txf->teximage[i * 2 + 1] = orig[i];
            }
            free(orig);
        } else {
            txf->teximage = (unsigned char *)
                malloc(txf->tex_width * txf->tex_height);
            if (txf->teximage == NULL) {
                lastError = "out of memory.";
                goto error;
            }
            got = static_cast<int>(fread(txf->teximage, 1, txf->tex_width * txf->tex_height, file));
            EXPECT(txf->tex_width * txf->tex_height);
        }
        break;
    case TXF_FORMAT_BITMAP:
        width = txf->tex_width;
        height = txf->tex_height;
        stride = (width + 7) >> 3;
        texbitmap = (unsigned char *) malloc(stride * height);
        if (texbitmap == NULL) {
            lastError = "out of memory.";
            goto error;
        }
        got = static_cast<int>(fread(texbitmap, 1, stride * height, file));
        EXPECT(stride * height);
        if (useLuminanceAlpha) {
            txf->teximage = (unsigned char *) calloc(width * height * 2, 1);
            if (txf->teximage == NULL) {
                lastError = "out of memory.";
                goto error;
            }
            for (i = 0; i < height; i++) {
                for (j = 0; j < width; j++) {
                    if (texbitmap[i * stride + (j >> 3)] & (1 << (j & 7))) {
                        txf->teximage[(i * width + j) * 2] = 255;
                        txf->teximage[(i * width + j) * 2 + 1] = 255;
                    }
                }
            }
        } else {
            txf->teximage = (unsigned char *) calloc(width * height, 1);
            if (txf->teximage == NULL) {
                lastError = "out of memory.";
                goto error;
            }
            for (i = 0; i < height; i++) {
                for (j = 0; j < width; j++) {
                    if (texbitmap[i * stride + (j >> 3)] & (1 << (j & 7))) {
                        txf->teximage[i * width + j] = 255;
                    }
                }
            }
        }
        free(texbitmap);
        break;
    }
    fclose(file);
    return txf;

error:
    cerr << "txfLoadFont ERROR: " << lastError << endl;

    if (txf) {
        if (txf->tgi)
            free(txf->tgi);
        if (txf->tgvi)
            free(txf->tgvi);
        if (txf->lut)
            free(txf->lut);
        if (txf->teximage)
            free(txf->teximage);
        free(txf);
    }
    if (file) fclose(file);
    return NULL;
}

GLuint txfEstablishTexture( TexFont * txf, GLuint texobj, GLboolean setupMipmaps) {
    if (txf->texobj == 0) {
        if (texobj == 0) glGenTextures(1, &txf->texobj);
        else txf->texobj = texobj;
    }
    glBindTexture(GL_TEXTURE_2D, txf->texobj);

#ifndef WIN32
    /* XXX Indigo2 IMPACT in IRIX 5.3 and 6.2 does not support the GL_INTENSITY
     internal texture format. Sigh. Win32 non-GLX users should disable this
     code. */
    if (useLuminanceAlpha == 0) {
        char *vendor, *renderer, *version;

        renderer = (char *) glGetString(GL_RENDERER);
        vendor = (char *) glGetString(GL_VENDOR);
        if (!strcmp(vendor, "SGI") && !strncmp(renderer, "IMPACT", 6)) {
            version = (char *) glGetString(GL_VERSION);
            if (!strcmp(version, "1.0 Irix 6.2") ||
                !strcmp(version, "1.0 Irix 5.3")) {
                unsigned char *latex;
                int width = txf->tex_width;
                int height = txf->tex_height;
                int i;

                useLuminanceAlpha = 1;
                latex = (unsigned char *) calloc(width * height * 2, 1);
                /* XXX unprotected alloc. */
                for (i = 0; i < height * width; i++) {
                    latex[i * 2] = txf->teximage[i];
                    latex[i * 2 + 1] = txf->teximage[i];
                }
                free(txf->teximage);
                txf->teximage = latex;
            }
        }
    }
#endif
    if (useLuminanceAlpha)
    {
        if (setupMipmaps)
        {
            gluBuild2DMipmaps(GL_TEXTURE_2D, GL_LUMINANCE_ALPHA,
                              txf->tex_width, txf->tex_height,
                              GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, txf->teximage);
        }
        else
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA,
                         txf->tex_width, txf->tex_height, 0,
                         GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, txf->teximage);
        }
    }
    else
    {
        if (setupMipmaps) {
            gluBuild2DMipmaps(GL_TEXTURE_2D, GL_INTENSITY4,
                              txf->tex_width, txf->tex_height,
                              GL_LUMINANCE, GL_UNSIGNED_BYTE, txf->teximage);
        } else {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_INTENSITY4,
                         txf->tex_width, txf->tex_height, 0,
                         GL_LUMINANCE, GL_UNSIGNED_BYTE, txf->teximage);
        }
    }
    return txf->texobj;
}


void txfUnloadFont( TexFont * txf) {
    if (txf->teximage) {
        free(txf->teximage);
    }
    free(txf->tgi);
    free(txf->tgvi);
    free(txf->lut);
    free(txf);
}

static TexGlyphVertexInfo * getTCVI(TexFont * txf, int c) {
    TexGlyphVertexInfo *tgvi;

    /* Automatically substitute uppercase letters with lowercase if not
     uppercase available (and vice versa). */
    if ((c >= txf->min_glyph) && (c < txf->min_glyph + txf->range)) {
        tgvi = txf->lut[c - txf->min_glyph];
        if (tgvi) {
            return tgvi;
        }
        if (islower(c)) {
            c = toupper(c);
            if ((c >= txf->min_glyph) && (c < txf->min_glyph + txf->range)) {
                return txf->lut[c - txf->min_glyph];
            }
        }
        if (isupper(c)) {
            c = tolower(c);
            if ((c >= txf->min_glyph) && (c < txf->min_glyph + txf->range)) {
                return txf->lut[c - txf->min_glyph];
            }
        }
    }
    c=(int)' ';  // by gf: replace unprintable chars
    return txf->lut[c - txf->min_glyph];
}

void txfGetStringMetrics(TexFont * txf, const char *string, unsigned int len,
                         int *width, int *max_ascent, int *max_descent) {
    TexGlyphVertexInfo *tgvi;

    int w = 0;
    for (unsigned int i = 0; i < len; i++) {
        switch (string[i]) {
            case '�':
                tgvi = getTCVI(txf, 'a');
                break;
            case '�':
                tgvi = getTCVI(txf, 'o');
                break;
            case '�':
                tgvi = getTCVI(txf, 'u');
                break;
            case '�':
                tgvi = getTCVI(txf, 'A');
                break;
            case '�':
                tgvi = getTCVI(txf, 'O');
                break;
            case '�':
                tgvi = getTCVI(txf, 'U');
                break;
            case '�':
                tgvi = getTCVI(txf, 's');
                break;
        default:
            tgvi = getTCVI(txf, string[i]);
        }
        w += (string[i]=='�')? 2*(int)(tgvi->advance):(int)(tgvi->advance);
    }
    *width = w;
    *max_ascent = txf->max_ascent;
    *max_descent = txf->max_descent;
}

void txfRenderGlyph(TexFont * txf, int c) {
    TexGlyphVertexInfo *tgvi;

    tgvi = getTCVI(txf, c);
    glBegin(GL_QUADS);
    glTexCoord2fv(tgvi->t0);
    glVertex2sv(tgvi->v0);
    glTexCoord2fv(tgvi->t1);
    glVertex2sv(tgvi->v1);
    glTexCoord2fv(tgvi->t2);
    glVertex2sv(tgvi->v2);
    glTexCoord2fv(tgvi->t3);
    glVertex2sv(tgvi->v3);
    glEnd();
    glTranslatef(tgvi->advance, 0.0, 0.0);
}

void txfRenderString( TexFont * txf, const char *string, int len) {
    glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); // by gf
    glBindTexture(GL_TEXTURE_2D, txf->texobj);                    // by gf

    int width;  // for umlaut replacement, by gf
    int maxAsc;
    int maxDesc;

    for (int i = 0; i < len; i++) {
        switch(string[i]) { // render umlauts by gf
        case '�':
            txfRenderGlyph(txf, 'a');
            txfGetStringMetrics(txf, "a",1,&width, &maxAsc, &maxDesc);
            glTranslatef(static_cast<float>(-width), static_cast<float>(maxAsc)*0.7f, 0.0f);
            txfRenderString(txf, "..",2);
            glTranslatef(0.0f, -(float)maxAsc*0.7f, 0.0f);
            break;
        case '�':
            txfRenderGlyph(txf, 'o');
            txfGetStringMetrics(txf, "o",1,&width, &maxAsc, &maxDesc);
            glTranslatef(static_cast<float>(-width), (float)maxAsc*0.7f, 0.0f);
            txfRenderString(txf, "..",2);
            glTranslatef(0.0f, -(float)maxAsc*0.7f, 0.0f);
            break;
        case '�':
            txfRenderGlyph(txf, 'u');
            txfGetStringMetrics(txf, "u",1,&width, &maxAsc, &maxDesc);
            glTranslatef(static_cast<float>(-width), (float)maxAsc*0.7f, 0.0f);
            txfRenderString(txf, "..",2);
            glTranslatef(0.0f, -(float)maxAsc*0.7f, 0.0f);
            break;
        case '�':
            txfRenderGlyph(txf, 'A');
            txfGetStringMetrics(txf, "A",1,&width, &maxAsc, &maxDesc);
            glTranslatef(-0.95f*(float)width, (float)maxAsc*0.9f, 0.0);
            txfRenderString(txf, "..",2);
            glTranslatef(0.05f*(float)width, -(float)maxAsc*0.9f, 0.0);
            break;
        case '�':
            txfRenderGlyph(txf, 'O');
            txfGetStringMetrics(txf, "O",1,&width, &maxAsc, &maxDesc);
            glTranslatef(-0.9f*(float)width, (float)maxAsc*0.9f, 0.0);
            txfRenderString(txf, "..",2);
            glTranslatef(0.1f*(float)width, -(float)maxAsc*0.9f, 0.0);
            break;
        case '�':
            txfRenderGlyph(txf, 'U');
            txfGetStringMetrics(txf, "U",1,&width, &maxAsc, &maxDesc);
            glTranslatef(-0.95f*(float)width, (float)maxAsc*0.9f, 0.0);
            txfRenderString(txf, "..",2);
            glTranslatef(0.05f*(float)width, -(float)maxAsc*0.9f, 0.0);
            break;
        case '�':
            txfRenderGlyph(txf, 's');
            txfRenderGlyph(txf, 's');
            break;
        default:
            txfRenderGlyph(txf, string[i]);
        }
    }
}


//--- class glText ------------------------------------------------- /*fold00*/
glText::glText(const string & , float fontSize) {
    fntSize=fontSize;
    maxAscent=0;
    maxDescent=0;
}

//--- class glTextTxf ---------------------------------------------- /*fold00*/
glTextTxf::glTextTxf(const string & fontName, float fontSize) : glText(fontName,fontSize) {
    txf=txfLoadFont(fontName.c_str());
    if (txf == NULL) {
        cerr << "glTextTxf ERROR: cannot load " << fontName << endl;
        return;
    }
    txfEstablishTexture(txf, 0, GL_TRUE);

    int maxAsc, maxDesc, width;
    txfGetStringMetrics(txf, "A",1,&width, &maxAsc, &maxDesc);
    maxAscent=(float)maxAsc * (fntSize/24.0f);
    maxDescent=0.25f*(float)maxAsc * (fntSize/24.0f);
}

glTextTxf::~glTextTxf() {
    if(!txf) return;
    txfUnloadFont(txf);
}

void glTextTxf::draw(const string & s, float x, float y, float z) {
    if(!txf) return;
    glPushMatrix();
    glTranslatef(x, y, z);
    float fScale = fntSize/24.0f;
    glScalef(fScale, fScale, fScale);
    txfRenderString(txf, s.c_str(), static_cast<int>(s.size()));
    glPopMatrix();
}

void glTextTxf::multiLineDraw(const string & s, float x, float y, float z, align_t align) {
    if(!txf) return;
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(fntSize/24.0f,fntSize/24.0f,fntSize/24.0f);
    int maxAsc, maxDesc, width;
    float dAlign;

    vector<string> lines;
    split(s,lines,"\n");
    for(int i = (static_cast<int>(lines.size())-1); i >= 0; i--) {
        txfGetStringMetrics(txf, lines[i].c_str(), static_cast<int>(lines[i].length()), &width, &maxAsc, &maxDesc);
        switch(align) {
        case ALIGN_RIGHT:
            dAlign = static_cast<float>(-width);
            break;
        case ALIGN_CENTER:
            dAlign = static_cast<float>(-width)/2.0f;
            break;
        default:
            dAlign = 0.0f;
        }
        glPushMatrix();
        glTranslatef(dAlign, static_cast<float>((maxAsc+maxDesc)*((lines.size()-1) - i)), 0);
        txfRenderString(txf, lines[i].c_str(), static_cast<int>(lines[i].size()));
        glPopMatrix();
    }
    glPopMatrix();
}

float glTextTxf::w(const std::string & str) const {
    if(!txf) return 0;
    int maxAsc, maxDesc, width;
    txfGetStringMetrics(txf, str.c_str(), static_cast<unsigned int>(str.size()),&width, &maxAsc, &maxDesc);
    return (float)width*fntSize/24.0f;
}


//--- class ovlPlane ----------------------------------------------- /*fold00*/

ovlPlane::ovlPlane(ve::xmlIni & ini, unsigned int iniSectionId) {
    ini.focusOn("deviceWindow", iniSectionId);
    ini.read(m_winSizeX,"winSizeX",1024);
    ini.read(m_winSizeY,"winSizeY",768);

    ini.focusOn("overlay");
    ini.read(x0,"minX",-1.0f);
    ini.read(y0,"minY",-1.0f);
    ini.read(x1,"maxX", 1.0f);
    ini.read(y1,"maxY", 1.0f);
    //set default values for overlay colors, then overwrite if specified in iniFile
    fgNormalColor(1.0f, 1.0f, 1.0f, 1.0f); //white
    ini.read(fgNormalCol,4,"fgNormalColor");
    bgNormalColor(0.0f, 0.0f, 0.0f, 1.0f); //black
    ini.read(bgNormalCol,4,"bgNormalColor");
    fgSelectColor(0.8f, 0.8f, 0.8f, 1.0f); //grey
    ini.read(fgSelectCol,4,"fgSelectColor");
    bgSelectColor(0.0f, 0.0f, 0.0f, 1.0f); //black
    ini.read(bgSelectCol,4,"bgSelectColor");

    string basePath=ini.getAttribute("basePath");
    if(basePath.size()) if((basePath[basePath.size()-1]!='/') && (basePath[basePath.size()-1]!='\\')) basePath+='/';

    ini.focusOff();
    // read resource definitions:
    _ovlResource resource;
    resource.mime=MIME_NONE;
    if (ini.subTag("resources")) {
        ini.focusOn("resources");
        string sceneBasePath=ini.getAttribute("basePath");
        if(sceneBasePath.size()) if((sceneBasePath[sceneBasePath.size()-1]!='/') && (sceneBasePath[sceneBasePath.size()-1]!='\\'))
            sceneBasePath+='/';
        glTexture::addSearchPath(sceneBasePath);

        for(unsigned int i=0; i<ini.nChildren(); i++) {
            ve::xml & xs=*(ini.child(i));
            if(xs.tag()=="resource") {
                if((xs.getAttribute("mime")=="font/txf")) {
                    string fontName=xs.getAttribute("url","default.txf");
                    float fontSize=s2f(xs.getAttribute("size","24"));
                    unsigned int id=s2ui(xs.getAttribute("id","0"));
                    if(!fileIo::fileExist(basePath+fontName)) {
                        cerr << "ovlPlane::constructor WARNING: requested font " << basePath+fontName << " not found.\n";
                        continue;
                    }
                    glText * pTxtRenderer=new glTextTxf(basePath+fontName, fontSize);
                    vTxtRenderer.push_back(pTxtRenderer);
                    vTxtRendererId.push_back(id);
                }
                else if(xs.getAttribute("mime")=="text/plain") {
                    resource.mime=MIME_TEXT_PLAIN;
                    resource.str= xs.getAttribute("string");
                    resource.id=s2ui(xs.getAttribute("id"));
                }
                else if ((xs.getAttribute("mime")=="image/svg+xml")||(xs.getAttribute("mime")=="geom/rect")) {
                    resource.mime=MIME_GEOM_RECT;
                    resource.id=s2ui(xs.getAttribute("id"));
                }
                else if (xs.getAttribute("mime").find("image")<xs.getAttribute("mime").size()) {
                    resource.mime=MIME_IMAGE_PNG; // placeholder for all pixel images
                    resource.str= xs.getAttribute("url");
                    resource.id=s2ui(xs.getAttribute("id"));
                }
                if(resource.mime==MIME_NONE) continue;
                vResource.push_back(resource);
            }
        }
        ini.focusOff();
        ini.focusOn("deviceWindow", iniSectionId);
    }
    ini.focusOn("overlay");

    for(unsigned int i=0; i<ini.nChildren(); i++) {
      ve::xml & xs=*(ini.child(i));

      if(xs.tag()=="object") {
        unsigned int objectId=s2ui(xs.getAttribute("id"));
        if(xs.getAttribute("resource").size()) {
            unsigned int resourceId=s2ui(xs.getAttribute("resource"));
            unsigned int font=s2ui(xs.getAttribute("font","0"));
            for(unsigned int i = 0; i < vResource.size(); i++) {
                if(vResource[i].id == resourceId) {
                    vector<float> vPos;
                    s2f(xs.getAttribute("position", "0.0 0.0"),vPos);
                    while(vPos.size()<2) vPos.push_back(0.0f);
                    vector<float> vSize;
                    s2f(xs.getAttribute("size", "1.0 1.0"),vSize);
                    while(vSize.size()<2) vSize.push_back(1.0f);
                    vector<float> vColor;
                    s2f(xs.getAttribute("color", "0 0 0 0"),vColor);
                    while(vColor.size()<4) vColor.push_back(1.0f);
                    unsigned int hAlign = ALIGN_CENTER;
                    if(toLower(xs.getAttribute("hAlign"))=="left") hAlign=ALIGN_LEFT;
                    else if(toLower(xs.getAttribute("hAlign"))=="right") hAlign=ALIGN_RIGHT;
                    unsigned int vAlign = ALIGN_CENTER;
                    if(toLower(xs.getAttribute("vAlign"))=="top") vAlign=ALIGN_TOP;
                    else if(toLower(xs.getAttribute("vAlign"))=="bottom") vAlign=ALIGN_BOTTOM;
                    unsigned int fontId = s2ui(xs.getAttribute("font", "0"));
                    addObject(resourceId, objectId, vPos[0], vPos[1],
                              vSize[0], vSize[1], (align_t)hAlign, (align_t)vAlign,
                              vColor[0], vColor[1], vColor[2], vColor[3],
                              fontId);
                    break;
                }
            }
        }
      }
    }
    // have the right blend function (gf approved ;-) :
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

    mouseXPos=(x0+x1)*0.5f;
    mouseYPos=(y0+y1)*0.5f;

    //restore xml focus
    ini.focusOff();
    ini.focusOn("deviceWindow", iniSectionId);
}

ovlPlane::~ovlPlane() {
    for(vector<ovlObj*>::iterator i=vObject.begin(); i<vObject.end(); i++)
        (*i)->overlay()=0;
    for(unsigned int i=0; i<vTxtRenderer.size(); i++)
        delete vTxtRenderer[i];
    // destructors resources missing!
}

int ovlPlane::setOutput(const vec6f & inputAxes, const flag128 & inputState) {
    mouseXPos=ovlX(((-inputAxes[H]+1.0f)/2.0f)*m_winSizeX);
    mouseYPos=ovlY(((inputAxes[P]+1.0f)/2.0f)*m_winSizeY);
    inputStatus=inputState;
    return 0;
}

void ovlPlane::draw() {
    if(vObject.size()==0) return;
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();  // set up a new projection for the overlay plane
    glOrtho(0,m_winSizeX,0,m_winSizeY,-1.0,1.0);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // todo: status storing and restoring
    glDisable(GL_DEPTH_TEST);
    glEnable (GL_BLEND);

    for(unsigned int i=0; i<vObject.size(); i++) {
        vObject[i]->update();
        vObject[i]->draw();
    }

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glDisable (GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}

int ovlPlane::addObject(unsigned int resourceId, unsigned int objectId, float
                        xPos, float yPos, float width, float height, align_t alH, align_t alV,
                        float r, float g, float b, float a,
                        unsigned int uiParam0, unsigned int uiParam1,
                        float lifespan, float fParam1) {
    for(unsigned int i=0; i<vResource.size(); i++) if(vResource[i].id==resourceId) {
        ovlObj * pOvlObj = 0;
        switch(vResource[i].mime) {
        case MIME_TEXT_PLAIN:
            if(!vTxtRenderer.size()) return 1;
            pOvlObj = new ovlLabel(this, vResource[i].str, xPos, yPos, width, height, alH, alV, uiParam0);
            if(a != 0.0f) ((ovlLabel*)pOvlObj)->fgNormalColor(r, g, b, a);
            break;
        case MIME_GEOM_RECT:
        case MIME_IMAGE_SVG:
            pOvlObj = new ovlRect(this, xPos, yPos, width, height, alH,alV, r,g,b,a);
            break;
        case MIME_IMAGE_PNG:
        case MIME_IMAGE_JPEG:
        case MIME_IMAGE_BMP:
            if(!width||!height) pOvlObj = new ovlImage(this, vResource[i].str, xPos, yPos, alH, alV);
            else pOvlObj = new ovlImage(this, vResource[i].str, xPos, yPos, width, height, alH, alV);
            break;
        default:
            return 1;
        }
        if(!pOvlObj) return 1;
        pOvlObj->activate(); // includes adding to vObject vector
        vObjectId.push_back(objectId);
        vObjectResourceId.push_back(resourceId);
        vExpire.push_back(lifespan);
        return 0;
    }
    return 1;
}

int ovlPlane::dropObject(unsigned int objectId)
{
  for(unsigned int i=0; i<vObjectId.size(); i++) if(vObjectId[i]==objectId) {
    vObjectId.erase((vector<unsigned int>::iterator)&vObjectId[i]);
    vObjectResourceId.erase((vector<unsigned int>::iterator)&vObjectResourceId[i]);
    vObject[i]->deactivate(); // includes erase from vObject vector
    vExpire.erase((vector<double>::iterator)&vExpire[i]);
    return 0;
  }
  return 1;
}

int ovlPlane::updateObject(unsigned int objectId, float xPos, float yPos,
                           float width, float height, align_t alH, align_t alV,
                           float r, float g, float b, float a,
                           unsigned int, unsigned int, float, float) {
    for(unsigned int i=0; i<vObjectId.size(); i++) {
    if(vObjectId[i]==objectId) {
      const type_info & currType=typeid(*vObject[i]);
      static const type_info & TovlLabel=typeid(ovlLabel);
      static const type_info & TovlRect=typeid(ovlRect);
      if(currType==TovlLabel) {
        ovlLabel* object = (ovlLabel*)vObject[i];
        object->x(xPos);
        object->y(yPos);
        object->w(width);
        object->h(height);
        object->alH(alH);
        object->alV(alV);
        if(a != 0.0f) object->fgNormalColor(r, g, b, a);
      }
      else if (currType==TovlRect)
      {
        ovlRect* object = (ovlRect*)vObject[i];
        object->x(xPos);
        object->y(yPos);
        object->w(width);
        object->h(height);
        object->alH(alH);
        object->alV(alV);
        object->color(r, g, b, a);
      }
      else
      {
        ovlImage* object = (ovlImage*)vObject[i];
        object->x(xPos);
        object->y(yPos);
        object->w(width);
        object->h(height);
        object->alH(alH);
        object->alV(alV);
      }
      return 0;
    }
  }
  return 1;
}

int ovlPlane::addResource(unsigned int resourceId,
                          const std::string & str,
                          unsigned int mime, unsigned int uiParam1,
                          float fParam0, float fParam1) {
    _ovlResource resource;
    resource.mime=mime;
    resource.str=str;
    resource.id=resourceId;
    vResource.push_back(resource);
    return 0;
}

int ovlPlane::setResource(unsigned int resourceId, const string & newText) {
    for(unsigned int i=0; i<vResource.size(); i++) {
    if(vResource[i].id==resourceId) {
      if(vResource[i].mime==MIME_TEXT_PLAIN) {
          vResource[i].str=newText;
          for(unsigned int j=0; j<vObjectResourceId.size(); j++)
              if(vObjectResourceId[j]==resourceId)
                  ((ovlLabel*)vObject[j])->str(newText);
          return 0;
      }
    }
  }
  return 1;
}

void ovlPlane::addObj(ovlObj * ovlObject) {
    if(ovlObject!=NULL) vObject.push_back(ovlObject);
}

void ovlPlane::dropObj(ovlObj * ovlObject) {
    if(ovlObject==NULL) return;
    for(vector<ovlObj*>::iterator i=vObject.begin(); i<vObject.end(); i++)
        if((*i)==(ovlObject)) {
            vObject.erase(i);
            return;
        }
}

void ovlPlane::clear() {
    vObject.clear();
    vObjectId.clear();
    vObjectResourceId.clear();
}

void ovlPlane::fgNormalColor(float r, float g, float b, float a) {
    fgNormalCol[0] = r; fgNormalCol[1] = g;
    fgNormalCol[2] = b; fgNormalCol[3] = a;
}

void ovlPlane::bgNormalColor(float r, float g, float b, float a) {
    bgNormalCol[0] = r; bgNormalCol[1] = g;
    bgNormalCol[2] = b; bgNormalCol[3] = a;
}

void ovlPlane::bgSelectColor(float r, float g, float b, float a) {
    bgSelectCol[0] = r; bgSelectCol[1] = g;
    bgSelectCol[2] = b; bgSelectCol[3] = a;
}

void ovlPlane::fgSelectColor(float r, float g, float b, float a) {
    fgSelectCol[0] = r; fgSelectCol[1] = g;
    fgSelectCol[2] = b; fgSelectCol[3] = a;
}

ve::glText * ovlPlane::textRenderer(unsigned int id) {
    for(unsigned int i=0; i<vTxtRenderer.size(); i++)
        if(vTxtRendererId[i]==id) return vTxtRenderer[i];
    if(vTxtRenderer.size()) return vTxtRenderer[0];
    return 0;
}

//--- class ovlObj ------------------------------------------------- /*fold00*/
ovlObj::ovlObj(ovlPlane * plane, float xPos, float yPos, align_t alH, align_t alV)
: m_x(xPos), m_y(yPos), pOvl(plane) {
    isActive=false;
    m_w=0;
    m_h=0;
    alignH=alH;
    alignV=alV;
    dAlignH=0;
    dAlignV=0;
    if(!pOvl) cerr << "ovlObj FATAL ERROR: ovlPlane * is NULL."
        <<" Expect segmentation fault or even worse." << endl;
}

void ovlObj::init() {
    switch(alignH) {
    case ALIGN_RIGHT:
        dAlignH=-m_w;
        break;
    case ALIGN_CENTER:
        dAlignH=-m_w/2;
        break;
    default:
        dAlignH=0;
    }
    switch(alignV) {
    case ALIGN_TOP:
        dAlignV=-m_h;
        break;
    case ALIGN_CENTER:
        dAlignV=-m_h/2;
        break;
    default:
        dAlignV=0;
    }
}

void ovlObj::activate() {
    if(isActive) return;
    if(pOvl) pOvl->addObj(this);
    isActive=true;
}

void ovlObj::deactivate() {
    if(!isActive) return;
    if(pOvl) pOvl->dropObj(this);
    isActive=false;
}


//--- class ovlLabel ----------------------------------------------- /*fold00*/

ovlLabel::ovlLabel(ovlPlane * plane, const string & txt, float xPos, float yPos, float width, float height,
                   align_t alH, align_t alV, unsigned int textRendererId) : ovlObj(plane, xPos, yPos, alH, alV) {
    fgNormalCol[0] = plane->fgNormalColor()[0]; fgNormalCol[1] = plane->fgNormalColor()[1];
    fgNormalCol[2] = plane->fgNormalColor()[2]; fgNormalCol[3] = plane->fgNormalColor()[3];
    bgNormalCol[0] = 0.0f; bgNormalCol[1] = 0.0f;
    bgNormalCol[2] = 0.0f; bgNormalCol[3] = 0.0f;
    fgSelectCol[0] = plane->fgSelectColor()[0]; fgSelectCol[1] = plane->fgSelectColor()[1];
    fgSelectCol[2] = plane->fgSelectColor()[2]; fgSelectCol[3] = plane->fgSelectColor()[3];
    bgSelectCol[0] = plane->bgSelectColor()[0]; bgSelectCol[1] = plane->bgSelectColor()[1];
    bgSelectCol[2] = plane->bgSelectColor()[2]; bgSelectCol[3] = plane->bgSelectColor()[3];
    m_selected=false;
    m_pTextRenderer=plane->textRenderer(textRendererId);
    if(!m_pTextRenderer) {
        cerr<<"ve::ovlLabel::constructor WARNING: No text renderer found in overlay plane.\n";
        return;
    }
    m_w=width  ? width  : pOvl->ovlX(m_pTextRenderer->w(txt))-pOvl->ovlX(0);
    m_h=height ? height : pOvl->ovlY(m_pTextRenderer->ascent()+m_pTextRenderer->descent())-pOvl->ovlY(0);
    str(txt);
}

void ovlLabel::draw() {
    if(!pOvl||!isActive||!m_pTextRenderer) return;
    // draw text:
    glEnable (GL_TEXTURE_2D);
    m_selected ? glColor4fv(fgSelectCol) : glColor4fv(fgNormalCol);
    switch(alignH) {
    case ALIGN_RIGHT:
        m_pTextRenderer->draw(text, -2.0f*m_pTextRenderer->descent()+pOvl->screenX(m_x)-m_pTextRenderer->w(text),
                              -0.55f*m_pTextRenderer->ascent()+pOvl->screenY(0.5f*m_h+m_y+dAlignV));
        break;
    case ALIGN_CENTER:
        m_pTextRenderer->draw(text, -m_pTextRenderer->descent()+pOvl->screenX(m_x)-0.5f*m_pTextRenderer->w(text),
                              -0.55f*m_pTextRenderer->ascent()+pOvl->screenY(0.5f*m_h+m_y+dAlignV));
        break;
    default:
        m_pTextRenderer->draw(text, pOvl->screenX(m_x),
                              -0.55f*m_pTextRenderer->ascent()+pOvl->screenY(0.5f*m_h+m_y+dAlignV));
    }
    glDisable (GL_TEXTURE_2D);
}

void ovlLabel::fgNormalColor(float r, float g, float b, float a) {
    fgNormalCol[0] = r; fgNormalCol[1] = g;
    fgNormalCol[2] = b; fgNormalCol[3] = a;
}

void ovlLabel::bgNormalColor(float r, float g, float b, float a) {
    bgNormalCol[0] = r; bgNormalCol[1] = g;
    bgNormalCol[2] = b; bgNormalCol[3] = a;
}

void ovlLabel::bgSelectColor(float r, float g, float b, float a) {
    bgSelectCol[0] = r; bgSelectCol[1] = g;
    bgSelectCol[2] = b; bgSelectCol[3] = a;
}

void ovlLabel::fgSelectColor(float r, float g, float b, float a) {
    fgSelectCol[0] = r; fgSelectCol[1] = g;
    fgSelectCol[2] = b; fgSelectCol[3] = a;
}

void ovlLabel::str(const string & txt) {
    text=txt;
    if(!pOvl||!m_pTextRenderer) {
        cerr << "ovlLabel::str() WARNING: cannot compute label size without ovlPlane or textRenderer" << endl;
        return;
    }
    while((pOvl->ovlX(m_pTextRenderer->w(text))+pOvl->ovlX(m_pTextRenderer->descent()+1.0f)- 2.0f*pOvl->ovlX(0.0f) > m_w) && text.size())
        text=text.substr(1);
    init();
}

//--- class ovlRect ------------------------------------------------ /*fold00*/
ovlRect::ovlRect(ovlPlane * plane, float xPos, float yPos, float width, float height,
                 align_t alH, align_t alV, float r, float g, float b, float a) : ovlObj(plane, xPos,yPos, alH, alV) {
    m_w=width;
    m_h=height;
    sizeAbs=false;
    color( r, g, b, a );
    init();
}

void ovlRect::color(float r, float g, float b, float a) {
    col[0] = r; col[1] = g;
    col[2] = b; col[3] = a;
}

void ovlRect::draw() {
    if(!pOvl) return;
    if(!isActive) return;
    glColor4fv(col);
    float x0,y0, x1,y1;
    if(sizeAbs) {
        x0=pOvl->screenX(m_x)+dAlignH;
        y0=pOvl->screenY(m_y)+dAlignV;
        x1=x0+m_w;
        y1=y0+m_h;
    }
    else {
        x0=pOvl->screenX(m_x+dAlignH);
        y0=pOvl->screenY(m_y+dAlignV);
        x1=pOvl->screenX(m_x+m_w+dAlignH);
        y1=pOvl->screenY(m_y+m_h+dAlignV);
    }
    glBegin (GL_QUADS);
      glVertex2f (x0,y0);
      glVertex2f (x1,y0);
      glVertex2f (x1,y1);
      glVertex2f (x0,y1);
    glEnd ();
}


//--- class ovlImage ----------------------------------------------- /*fold00*/

ovlImage::ovlImage(ovlPlane * plane, const string & filename, float xPos, float yPos, float width, float height,
                     align_t alH, align_t alV, bool repeat ) : ovlRect(plane,xPos,yPos,width,height, alH, alV) {
    m_w=width;
    m_h=height;
    sizeAbs=false;
    color( 1.0, 1.0, 1.0, 1.0 );
    byteDepth=0;

    int texWidth;
    int texHeight;
    strFile = filename;
    if(glTexture::load(filename,texId,byteDepth,texWidth,texHeight,repeat)!=0)
        textured=0;
    else textured=1;
    init();
}

ovlImage::ovlImage(ovlPlane * plane, const string & filename, float xPos, float yPos,
                     align_t alH, align_t alV, bool repeat ) : ovlRect(plane,xPos,yPos) {
    color( 1.0, 1.0, 1.0, 1.0 );
    byteDepth=0;

    alignH=alH;
    alignV=alV;

    int texWidth;
    int texHeight;
    strFile = filename;
    if(glTexture::load(filename,texId,byteDepth,texWidth,texHeight,repeat)!=0) {
        textured=0;
        sizeAbs=false;
        m_w=0;
        m_h=0;
    }
    else {
        textured=1;
        sizeAbs=true;
        m_w=(float)texWidth;
        m_h=(float)texHeight;
    }
    init();
}

ovlImage::ovlImage(ovlPlane * plane, const image & img, float xPos, float yPos, float width, float height,
                     align_t alH, align_t alV, bool repeat ) : ovlRect(plane,xPos,yPos,width,height, alH, alV) {
    m_w=width;
    m_h=height;
    byteDepth=img.bytesPerPixel();
    sizeAbs=false;
    color( 1.0, 1.0, 1.0, 1.0 );

    static unsigned int texCounter=0;
    string texname="_ovlImage_"+i2s(texCounter++);
    if(glTexture::load(texname,texId,img, repeat)!=0) textured=0;
    else textured=1;
    init();
}

void ovlImage::draw() {
    if(!pOvl) return;
    if(!isActive) return;
    glColor4fv(col);
    if(textured) {
        glEnable (GL_TEXTURE_2D);
        glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glBindTexture (GL_TEXTURE_2D, texId);
    }
    float x0,y0, x1,y1;
    if(sizeAbs) {
        x0=pOvl->screenX(m_x)+dAlignH;
        y0=pOvl->screenY(m_y)+dAlignV;
        x1=x0+m_w;
        y1=y0+m_h;
    }
    else {
        x0=pOvl->screenX(m_x+dAlignH);
        y0=pOvl->screenY(m_y+dAlignV);
        x1=pOvl->screenX(m_x+m_w+dAlignH);
        y1=pOvl->screenY(m_y+m_h+dAlignV);
    }
    glBegin (GL_QUADS);
      glTexCoord2f (0.0f, 0.0f); glVertex2f (x0,y0);
      glTexCoord2f (1.0f, 0.0f); glVertex2f (x1,y0);
      glTexCoord2f (1.0f, 1.0f); glVertex2f (x1,y1);
      glTexCoord2f (0.0f, 1.0f); glVertex2f (x0,y1);
    glEnd ();
    if(textured) glDisable (GL_TEXTURE_2D);
}


//--- cvs history log ---------------------------------------------- /*FOLD00*/
/*
 * $Log: veGlUtils.cpp,v $
 * Revision 2.3  2005/01/17 09:28:07  gf
 * bug in text positioning solved
 *
 * Revision 2.2  2004/12/06 11:17:58  gf
 * potential crash avoided in case of absence of any text renderer
 *
 * Revision 2.1  2004/12/01 10:11:23  weyel
 * added load-time texture compression
 *
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.72  2004/11/01 10:50:23  gf
 * - cleanup dependencies
 * - ovlLabel now complete
 *
 * Revision 1.71  2004/10/27 09:24:47  gf
 * overlay alignment types are now explicit text
 *
 * Revision 1.70  2004/10/25 15:11:29  weyel
 * MSVC compiler warning fixed
 *
 * Revision 1.69  2004/10/20 12:14:08  gf
 * ovlLabels are now truncated to fit to the initially given width and height
 *
 * Revision 1.68  2004/10/19 12:47:20  gf
 * - individual device::id() added, old id is now called typeId()
 * - dataContainer now has a counter variable
 * - handling of multiple fonts in overlay completed
 *
 * Revision 1.67  2004/10/18 11:10:14  gf
 * - mime type for txf fonts added
 * - framework for handling multiple fonts added, not completely implemented
 * - dataContainer::type() now changeable after construction
 *
 * Revision 1.66  2004/10/14 14:56:57  gf
 * - nasty little bug in veGlUtils, ovl::dropObj() fixed
 * - some doxygen warnings removed
 *
 * Revision 1.65  2004/10/08 17:36:58  gf
 * cleanup of unused classes
 *
 * Revision 1.64  2004/10/04 09:38:11  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.63  2004/09/28 12:21:47  gf
 * ovlLabels are now rendered identically to ovlButtons (to come)
 *
 * Revision 1.62  2004/09/24 07:46:32  gf
 * unused methods of overlay plane removed
 *
 * Revision 1.61  2004/09/23 15:08:46  gf
 * - resourceIdMax and objectIdMax variables and methods added for devices
 * - dynamic overlay text now uses correct updateResource mechanism
 *
 * Revision 1.60  2004/09/13 08:32:46  gf
 * ovlObj alignment now reacts to resize
 *
 * Revision 1.59  2004/09/03 12:33:01  weyel
 * - UDP network device now uses BSD sockets
 * - small adaptations in veDataContainer
 * - fixed some minor bugs
 *
 * Revision 1.58  2004/08/25 12:50:51  gf
 * id attribute parsing removed for <overlay/>, <resources/>, <scene/>
 *
 * Revision 1.57  2004/08/20 08:48:10  gf
 * - VECERR replaced by std::cerr
 * - dynamic overlay text implemented, affecting veDeviceSDL, veGlUtils, veTypes, veDataContainer
 *
 * Revision 1.56  2004/08/03 12:56:08  weyel
 * - fileIo::unifyPath() added do deal with slashes in filepaths
 * - collisionTriangle::altitude() added, returns height over a surface
 * - slight adaptations in some other files
 *
 * Revision 1.55  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.53  2004/05/25 12:06:19  gf
 * some small overlay bugs fixed
 *
 * Revision 1.52  2004/04/13 11:37:29  weyel
 * - clock sync for network communication added
 * - motion prediction on base of synchronized clock
 * - font size for ovlText now read from ini-file
 *
 * Revision 1.51  2004/04/02 13:06:53  gf
 * unknown change
 *
 * Revision 1.50  2004/03/22 19:49:08  gf
 * overlay objects can now be shown using activate() method
 *
 * Revision 1.49  2004/03/12 18:37:42  weyel
 * new standard settings for alignment
 *
 * Revision 1.48  2004/03/12 15:37:46  weyel
 * - deviceWindow parses overlay with sectionId for different ovlPlanes for each window
 * - ovlRect now uses alignment
 *
 * Revision 1.47  2004/03/12 14:23:23  weyel
 * overlay textcolor is set to white opaque if alpha value is 0.0
 *
 * Revision 1.46  2004/03/12 12:20:57  weyel
 * -added ovlRect for single-color overlay rectangles
 * -changed network code, dataContainers now have a transfer flag (MANDATORY/REDUNDANT)
 * -overlays now dynamic, color, size and pos may be changed at runtime
 *
 * Revision 1.45  2004/03/11 12:06:48  gf
 * <typeinfo> included
 *
 * Revision 1.44  2004/03/10 11:19:19  weyel
 * -handling of overlay objects improved
 * -they can now be switched on and off using command ADD_ and DROP_OBJECT
 *
 * Revision 1.43  2004/03/01 10:05:25  gf
 * - MT_ constants renamed to MIME_
 * - overlay runs again like before
 *
 * Revision 1.42  2004/02/27 16:53:52  gf
 * - dataContainer completely remodeled
 * - xmlIni::subTag() methods added
 * - update() interface for devices unified
 * - deviceGraphicsX3D::followObject() bug fixed
 *
 * Revision 1.41  2004/02/26 20:03:25  weyel
 * some changes to overlay objects and plane
 *
 * Revision 1.40  2004/02/18 14:14:10  gf
 * ovlPlane now a little bit similar to a ve::device
 */
