#ifndef _INCLUDED_VEUTILS
#define _INCLUDED_VEUTILS
/** @file veUtils.h
 \brief A collection of utility functions and classes.

 It currently contains byte order related conversion functions,
 portable time function wrappers, file input/output functions,
 and a framework for command line argument parsing.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author mvdh / gf

 $Revision: 2.0 $

 */

#if defined __WIN32__ || defined WIN32
#  include <winsock2.h>
#  include <WS2tcpip.h>
#  define socklen_t int
#  include <cstdio>
#  define SHUT_RDWR SD_BOTH
#else
#  include <errno.h>
#  include <netdb.h>
#  include <netinet/in.h>
#  include <sys/socket.h>
#  include <unistd.h>
#  include <fcntl.h>
#endif

#ifdef _MSC_VER
# include <direct.h>
#else
# include <dirent.h>
#endif

#include "veStd.h"

//--- various functions and definitions ---------------------------- /*fold00*/

/// A simple but secure delete macro
#define veDelete(object) { if (NULL!= (object) ) { talk1(5,"veDelete object %x",(object)); delete ( (object) ); object = NULL; } }

namespace ve {

/** These functions take in data with swapped byte order and swap it back.
  WORKS ONLY IF data size between client and server match */
short  net2hosts (const char *buffer);
long   net2hostl (const char *buffer);
float  net2hostf (const char *buffer);
double net2hostd (const char *buffer);


/** These function take in data, change the byte order and store the result to the
    memory area pointed to by the buffer pointer. It returns the size of the data
    written out to the buffer, in bytes.
    WORKS ONLY IF data size between client and server match
*/
int host2nets (char *buffer, short number);
int host2netl (char *buffer, long number);
int host2netf (char *buffer, float number);
int host2netd (char *buffer, double number);

/** changes the byte order of a given value.
    \param *b pointer to the value
    \param n size of the value in bytes
*/
void byteSwap(char *b, int n);


//--- class time --------------------------------------------------- /*fold00*/
/// time / timer class
class time
{
public:
  /// constructor
  /** \param initTime (optional) sets the start time for the timer.  */
  time(double initTime = 0.0) { m_currentTime = m_lastUpdate = initTime; };
  /// sets the timer time to the given value
  void set(double time) {m_currentTime = time;};
  /// updates the timer time according to the system clock and returns the updated time
  double update(){ m_lastUpdate = m_currentTime; m_currentTime += stamp() - m_currentTime; return m_currentTime; };
  /// returns the current timer time (will always be the same between two update calls)
  double now() {return m_currentTime; };
  /// returns the time that passed between the last two consecutive update calls
  double deltaT() {return m_currentTime - m_lastUpdate;};

  /// returns a time stamp with double precision
  static double stamp();

  /// portable sleep function
  /** Lets the currently running process sleep for the given amount of time
   in seconds. For example a ve::sleep(0.010) would let the process
   sleep for about 10ms and allows a general update rate of 100Hz.
   \param     sec the timespan the process should sleep
   */
  static void sleep(double sec);

  /// returns the current date as string
  /** the date is returned at a precision of seconds. This is mainly useful
    for naming temporary files. */
  static std::string date();
protected:
  /// stores current time, time of latest update call
  double m_currentTime;
  /// stores time stamp of previous update
  double m_lastUpdate;
};


//--- struct fileInfo ---------------------------------------------- /*fold00*/
/// \internal helper struct storing information on zip archive member files
struct fileInfo {
    std::string name;
    unsigned int offset;
    unsigned int size;
    bool isCompressed;
};


/// constant identifying normal zip file members
const unsigned int ZIP_HEADER_ID=67324752;
/// constant identifying central zip directory
const unsigned int ZIP_DIR_ID=33639248;


//--- class ve::fileIo --------------------------------------------- /*fold00*/
/// class facilitating file input/output operations.
class fileIo {
public:
    /// opens a pipe from an executed external command and returns its standard output.
    static std::string exec(const std::string & cmdName,
                            const std::string & cmdArgs="",
                            const std::string & cmdPath="./");
    /// puts all directory entries of path in target string vector.
    /**
     this method is planned to become transparent for zip archives. Not yet implemented.
     \param target is filled with directory entries
     \param path (optional) defines directory path
     \param filter (optional) sets filter with * wildcards
     \return 0 if no errors occured, otherwise 1. */
    static int dir(std::vector<std::string> & target, const std::string & path=".", const std::string & filter="*");
    /// determines whether path points to a directory
    static bool isDir(const std::string & path);
    /// opens a zip archive for further reading.
    /** Currently only uncompressed archives are supported.
     Only one archive can be open at the same time. This is NOT thread safe! */
    static int openZip(const std::string & path);
    /// closes currently opened zip archive, if any.
    static int closeZip();
    /// reads information about files in a zip archive
    static int readZipDir(FILE * fp, std::vector<fileInfo> & vZip );
    /// opens a FILE stream
    /** This static method makes reading of zip archive member files "transparent" (i.e. hides them).
     It tests whether the requested file is member of a currently
     opened ZIP archive. If so, the read position is moved at the correct position.
     If it is no member of the current archive, or no archive is open at all,
     a normal fopen is performed. Only reading from zip is supported (i.e. "r" or "rb"). */
    static FILE* open(const std::string & path, const char *mode);
    /// closes a FILE stream
    /** This static method makes reading of zip archive member files "transparent" (i.e. hides them).
     It tests whether the requested file is member of a currently
     open ZIP archive. If so, the read position is resetted.
     If it is no member of the current archive, or no archive is open at all,
     a normal fclose is performed. */
    static int close(FILE* stream);
    /// tests a FILE stream for end of file
    /** This static method makes reading of zip archive member files "transparent" (i.e. hides them).
     It tests whether the requested file stream is readable.
     If it is no member of the current archive, or no archive is open at all,
     a normal feof is performed. */
    static int eof(FILE* stream);
    /// reads a line from a FILE* into a c++ string
    /** \return the number of read chars. */
    static unsigned int getline(FILE* fp, std::string & s);
    /// tests whether file filename exists and returns TRUE in case of existence.
    static bool fileExist(const std::string & filename);
    /// returns the file size in bytes.
    /** This function is transparent for files in zip archives. */
    static unsigned int fileSize(FILE* fp);
    /// tests whether a filename matches to a filename filter that may contain stars (*)
    static bool wildcardMatch(const std::string & fname, const std::string & filter);
    /// removes OS dependencies from a filepath string
    static std::string unifyPath(const std::string & source);
    /// returns the mime type of a file name if recognized
    static unsigned int mime(const std::string & filename);
    /// returns current working directory
    static std::string cwd();
protected:
    /// stores file handle to currently opened zip archive
    static FILE * zipFile;
    /// stores information about members of currently opened zip archive
    static std::vector<fileInfo> zipDir;
    /// stores id of current opened zipfile member
    static unsigned int zipFileId;
};

//--- class ve::cmdLine -------------------------------------------- /*fold00*/
/// a simple static class for preparsing command line arguments and options
class cmdLine {
public:
    /// parses command line and command line options.
    /** \param argc standard C main() number of arguments.
     \param argv standard C main() pointer to arguments char array.
     \param optsAsArgs optional parameter that causes all command line tokens to be interpreted as arguments.
     */
    static void interpret( int argc, char **argv, bool optsAsArgs=false );
    /// returns whether command line has already been parsed
    static bool parsed() { return isParsed; };
    /// returns command line option number i
    static char opt(unsigned int i) { return vOpt[i][0]; };
    /// returns true if a single char command line option exists
    static bool opt(const char c);
    /// returns optional argument of a single char command line option, or ""
    static std::string optArg(const char c);
    /// returns a reference of command line argument i
    static const std::string & arg(unsigned int i) { return vArg[i]; };
    /// returns number of command line arguments
    static unsigned int nArg() { return static_cast<unsigned int>(vArg.size()); };
    /// returns number of command line options
    static unsigned int nOpt() { return static_cast<unsigned int>(vOpt.size()); };
    /// returns path to main's directory
    static std::string dir() { return ownDir; };
    /// returns main's command name
    static std::string cmd() { return ownCmd; };
    /// sets program's name.
    static void name(const std::string & s) { name_=s; };
    /// returns program's name.
    static const std::string & name() { return name_; };
    /// sets program's author.
    static void author(const std::string & s) { author_=s; };
    /// returns program's author.
    static const std::string & author() { return author_; };
    /// sets program's version.
    static void version(const std::string & s) { version_=s; };
    /// returns program's version.
    static const std::string & version() { return version_; };
    /// sets program's date.
    static void date(const std::string & s) { date_=s; };
    /// returns program's date.
    static const std::string & date() { return date_; };
    /// sets program's short description.
    static void shortDescr(const std::string & s) { shortDescr_=s; };
    /// returns program's short description.
    static const std::string & shortDescr() { return shortDescr_; };
    /// sets program's long description.
    static void descr(const std::string & s) { descr_=s; };
    /// returns program's long description.
    static const std::string & descr() { return descr_; };
    /// sets program's long description.
    static void usage(const std::string & s) { usage_=s; };
    /// returns program's long description.
    static const std::string & usage() { return usage_; };

    /// returns a help string containing previously setted data.
    static const std::string help();
protected:
    /// stores command line arguments
    static std::vector<std::string> vArg;
    /// stores command line options
    static std::vector<std::string> vOpt;
    /// stores path to main's directory
    static std::string ownDir;
    /// stores main's command name
    static std::string ownCmd;
    /// stores whether class is already initialized
    static bool isParsed;

    /// stores program's name.
    /** If no name is provided by the user, the program's command line
     call is taken as default. */
    static std::string name_;
    /// stores program's author.
    static std::string author_;
    /// stores program's version.
    static std::string version_;
    /// stores program's date.
    static std::string date_;
    /// stores program's short description.
    static std::string shortDescr_;
    /// stores program's long description.
    static std::string descr_;
    /// stores program's usage.
    static std::string usage_;
};

} // namespace ve


//--- history ------------------------------------------------------ /*FOLD00*/
/*
 * $Log: veUtils.h,v $
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.55  2004/11/01 10:50:23  gf
 * - cleanup dependencies
 * - ovlLabel now complete
 *
 * Revision 1.54  2004/10/28 14:55:57  gf
 * small bugfix and renaming of ve::timer to ve::time
 *
 * Revision 1.53  2004/10/28 13:27:51  weyel
 * - timer class added
 *
 * Revision 1.52  2004/10/15 15:27:12  weyel
 * - documentation updated and improved
 * - removed some deprecated methods
 *
 * Revision 1.51  2004/10/14 14:56:57  gf
 * - nasty little bug in veGlUtils, ovl::dropObj() fixed
 * - some doxygen warnings removed
 *
 * Revision 1.50  2004/10/04 09:38:43  weyel
 * -resolved ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.49  2004/09/28 12:20:37  gf
 * fileIo::mime() method added
 *
 * Revision 1.48  2004/09/24 16:08:58  gf
 * - cleanup of unused and old methods
 * - small bugfixes in the network device
 * -> final adjustments to publish version 1.0.beta1
 *
 * Revision 1.47  2004/09/15 14:53:27  weyel
 * - network constants now in namespace ve
 * - fixed some VC compiler warnings
 * - Linux timestamp now always uses gettimeofday()
 *
 * Revision 1.46  2004/09/14 15:37:27  weyel
 * - network header files now included in veUtils.h
 *
 * Revision 1.45  2004/09/13 08:31:24  gf
 * fileIo::cwd() methods (get current working directory) added
 *
 * Revision 1.44  2004/09/10 09:56:11  gf
 * cross dependencies solved
 *
 * Revision 1.43  2004/08/09 09:30:16  gf
 * use of const reference instead of local copy
 *
 * Revision 1.42  2004/08/03 12:57:47  weyel
 * - fileIo::unifyPath() added do deal with slashes in filepaths
 * - collisionTriangle::altitude() added, returns height over a surface
 * - slight adaptations in some other files
 * - added deviceNetworkUDP, still based on SDLNet but will be
 *   changed to BSD sockets soon
 *
 * Revision 1.41  2004/07/26 16:25:18  gf
 * - veMath: some renamings similar to OpenGL: vec3 -> vec3f, vec2->vec2f, sixdof -> vec6f, mat4x4 -> matrix4f
 * - veUtils: ...UL timing functions dropped, timeStampD renamed to timeStamp, sleepD renamed to sleep
 *
 * Revision 1.40  2004/07/01 15:25:27  gf
 * handling of filename filters (e.g., *.cpp) for fileio::dir() improved
 *
 * Revision 1.39  2004/06/30 09:06:46  franck
 * All the ntohX and htonX functions have been rewritten. They now use the sizeof()
 * function instead of hardcoded data length, and they write to/read from the buffer
 * themselves rather than return values. Overall, this is more elegant, safier and
 * possibly faster. Conversion functions for double variables have been added so that
 * the new timeStamp format can be sent accross the network.
 *
 * Revision 1.38  2004/05/19 00:22:24  franck
 * Fixed warnings from DOxygen (first contribution to veLib, woohoo!!)
 *
 * Revision 1.37  2004/04/27 13:44:12  weyel
 * - fixed a bug in host2netf and net2hostf
 * - floats now coverted correctly for network transfer
 * - changed include order in some files (MS VC wants windows.h in front of
 *   any GL-includings)
 *
 * Revision 1.34  2004/03/22 19:45:25  gf
 * veIo and veUtils reunited in veUtils
 */
#endif // _INCLUDED_VEUTILS
