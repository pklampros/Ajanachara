#ifndef _VE_STRUTILS_H
#define _VE_STRUTILS_H

/** @file veStrUtils.h
 \brief string utility functions.

 These functions allow a convenient string processing, mainly for internal
 use in the veXml and xmlStatement classes.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 @author  gf
 $Revision: 2.1 $
 */

#include "veStd.h"

// veLib standard namespace - look into veStd.h for more documentation
namespace ve {

//--- string utility functions -------------------------------------- /*FOLD00*/
/// general tool for splitting strings into pieces.
unsigned int split(const std::string & input, std::vector<std::string> & output, const std::string & separators=" \t\n\015");
/// general tool for stripping definable characters from both ends
std::string trim(const std::string& s, const std::string & pattern=", \t\n\015");
/// returns true if char is whitespace otherwise false
bool isWhiteSpace(char ch);
/// replaces all occurences of search with repl in s
std::string replaceAll(std::string s, const std::string & search, const std::string & repl);
/// trims n characters from the end of string s
void operator-=(std::string & s, unsigned int n);

/// converts integer value to string
std::string i2s(long i);
/// converts float value to string
std::string f2s(double f);
/// converts float value to string, specify number of digits
std::string f2s(double f,unsigned short nDigits);
/// converts bool value b to string, optionally specify mode ( 0 1, true false)
std::string b2s(bool b, bool asText=false);
/// converts character to string
std::string c2s(char ch);
/// converts string to integer value
int s2i(const std::string & s);
/// converts string to unsigned integer value
unsigned int s2ui(const std::string & s);
/// converts string to float value
float s2f(const std::string & s);
/// converts string to bool value
bool s2b(const std::string & s);
/// converts string to float vector.
/** The string is splitted according to optional argument separators.
 \return the number of generated floats.*/
unsigned int s2f(const std::string & s, std::vector<float> & vFloat, const std::string & separators=", \t\n\015");
/// converts string to int vector.
/** The string is splitted according to optional argument separators.
 \return the number of generated ints.*/
unsigned int s2i(const std::string & s, std::vector<int> & vInt, const std::string & separators=", \t\n\015");
/// converts string to unsigned int vector.
/** The string is splitted according to optional argument separators.
 \return the number of generated unsigned ints.*/
unsigned int s2ui(const std::string & s, std::vector<unsigned int> & vUInt, const std::string & separators=", \t\n\015");
/// converts string to bool vector.
/** The string is splitted according to optional argument separators.
 \return the number of generated bools.*/
unsigned int s2b(const std::string & s, std::vector<bool> & vBool, const std::string & separators=", \t\n\015");
/// converts a string to upper case, if possible.
std::string toUpper(const std::string & s);
/// converts a string to lower case, if possible.
std::string toLower(const std::string & s);
/// converts a hexadecimal string into an unsigned int
unsigned int hex2ui(const std::string & s);

} // namespace ve

/// simple standard output of vectors
template <class T> std::ostream & operator<<(std::ostream & os, const std::vector<T> & v) {
    for (unsigned int i=0; i< v.size(); i++)
        os << v[i] << '\t';
    return os;
}
/// simple standard output of vectors of vectors
template <class T> std::ostream & operator<<(std::ostream & os, const std::vector< std::vector<T> > & vv) {
    for (unsigned int i=0; i< vv.size(); i++) {
        for (unsigned int j=0; j< vv[i].size(); j++)
            os << vv[i][j] << '\t';
        os << '\n';
    }
    return os;
}


//--- cvs history log ----------------------------------------------- /*FOLD00*/
/*
 * $Log: veStrUtils.h,v $
 * Revision 2.1  2005/01/03 09:41:42  gf
 * hex2ui conversion function added
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.28  2004/10/25 11:54:35  gf
 * toLower and toUpper functions added
 *
 * Revision 1.27  2004/10/04 09:38:43  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.26  2004/09/28 12:19:26  gf
 * string_npos constant removed
 *
 * Revision 1.25  2004/09/13 08:30:06  gf
 * function c2s() (char to string conversion) added
 *
 * Revision 1.24  2004/04/16 13:34:39  gf
 * - basic 3dsLoader for ve::geoMeshes added, some corresponding adaptations
 * - some VC6 trash undone
 *
 * Revision 1.21  2004/01/26 09:10:44  gf
 * - simple remapping mechanism implemented
 * - dynamic scenegraph objects have now a local coordinate system for speed
 *
 * Revision 1.20  2003/12/23 10:10:31  gf
 * stream output for vectors added
 *
 * Revision 1.19  2003/12/01 16:58:16  gf
 * string conversion functions: long instead of int, double instead of float
 *
 * Revision 1.18  2003/09/23 16:35:19  gf
 * operator-=(string & s, unsigned int n) added
 *
 * Revision 1.17  2003/07/29 10:38:45  gf
 * - veGlUtils: the bad cocnept of fontScale removed
 * - veStrUtils: function s2b(vector<bool>,...) added
 *
 * Revision 1.16  2003/07/25 10:59:26  gf
 * copyright update
 *
 * Revision 1.13  2003/03/31 16:19:52  gf
 * namespace ve added. Should be consequently used instead of VE_ etc.
 *
 * Revision 1.11  2003/03/25 17:29:00  mvdh
 * major changes in most files - cebit version from MvdH now in action - please watch out for eventual errors and conflicts - now windows and linux support
 *
 * Revision 1.10  2003/03/21 16:33:03  gf
 * - s2f, s2i for vectors added
 * - documentation update
 * - split() slightly optimized
 *
 * Revision 1.9  2003/03/03 12:52:23  gf
 * updated doxygen documentation
 *
 * Revision 1.8  2003/02/26 12:54:42  gf
 * documentation now conform to doxygen
 *
 * Revision 1.7  2002/12/17 15:47:02  gf
 * function f2s(float,precision) added
 */

#endif // _VE_STRUTILS_H
