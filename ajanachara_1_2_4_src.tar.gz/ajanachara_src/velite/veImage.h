#ifndef _VE_IMG_H
#define _VE_IMG_H

#include "veStd.h"

/** @file veImage.h
 \brief contains the classes veImage and veTexture.

 veLib Copyright 2003, 2004 by Reinhard Feiler
 for the Max Planck Institute of Biological Cybernetics, Tuebingen.

 Please report all bugs and problems to "weyel\@tuebingen.mpg.de".

 \author  gf
 $Revision: 2.2 $
 */

//--- class ve::image ---------------------------------------------- /*fold00*/

namespace ve {

/// ve::image is a class for basic image file input/output.
/**
 ve::image provides a unified interface for low level graphics
 loader libraries and a few image manipulating methods.
 JPEG and PNG images can be loaded via libjpeg or libpng and zlib.
 For this file format bindings, corresponding settings have to be
 defined in veConfig.h, the library headers have to be provided for
 compiling the veLib, and finally, the executables have to be linked
 with the low level loader libs.

 @author  gf
 $Revision: 2.2 $
*/
class image {
public:
    /// default constructor or constructor loading from file.
    image(const std::string & filename="");
    /// constructor from memory data.
    image(const unsigned char * pData, unsigned int w, unsigned int h, unsigned int byteDepth);
    /// constructor from XPM memory data.
    image(const char **ch);
    /// copy constructor.
    image(const ve::image & source) { Data=0; operator=(source); };
    /// destructor.
    ~image();
    /// copy operator.
    const ve::image & operator=(const ve::image & source);

    /// allows read access to raw data, const.
    const unsigned char * const data() const { return Data; };
    /// allows full access to raw data.
    unsigned char * & data() { return Data; };
    /// returns image width in pixels
    unsigned int w() const { return Width; };
    /// returns image height in pixels
    unsigned int h() const { return Height; };
    /// returns bytes per pixel
    unsigned int bytesPerPixel() const { return BytesPerPixel; };
    /// returns pixel value at x|y.
    /** If coordinate is out of range, 0 is returned.
     If it is a color image, return value encodes RGB values: byte0=R, byte1=G, byte2=B, byte3=A */
    unsigned int pixel(unsigned int x, unsigned int y) const;
    /// sets pixel value at x|y.
    /** If coordinate is out of range, nothing happens.
     If it is a color image, value has to encode the RGB values: byte0=R, byte1=G, byte2=B, byte3=A */
    void pixel(unsigned int x, unsigned int y, unsigned int value);
    /// returns linearly interpolated value at x|y.
    /** The image's limits are treated as 0|0 and 1|1.
     If coordinate is out of this range, the next border value is returned.
     If it is a color image, return value encodes RGB values: byte0=R, byte1=G, byte2=B, byte3=A */
    unsigned int valueAt(float x, float y) const;
    /// converts color image int grayscale image
    void rgb2gray();
    /// resizes image using bilinear filtering.
    void resize(unsigned int sizeX, unsigned int sizeY);
    /// saves image data as tga file. under devolopment, experimental!
    int save(const std::string & filename) const;

    /// tries to detect file type and reads image
    int read(const std::string & filename);
    /// reads a PNG image via libpng and zlib.
    /** veImage must be compiled with _HAVE_LIBPNG anv _HAVE_LIBZ defined in veConfig.h. */
    int readPng(FILE * fp);
    /// reads a JPEG image via libjpeg.
    /** veImage must be compiled with _HAVE_LIBJPEG defined in veConfig.h. */
    int readJpg(FILE * fp);
    /// reads a BMP image via libSDL.
    /** veImage must be compiled with _HAVE_SDL defined in veConfig.h. */
    int readBmp(const std::string & fileName);

    /// operator for output in streams
    friend std::ostream & operator<<(std::ostream & os, const ve::image & img);
protected:
    /// internal pointer to texture memory
    unsigned char *Data;
    /// stores image width and height
    unsigned int Width, Height;
    /// stores bytes per pixel
    unsigned int BytesPerPixel;
};
} // namespace ve

namespace std {
/// operator for output in streams
    std::ostream & operator<<(std::ostream & os, const ve::image & img);
}

//--- class ve::glTexture ------------------------------------------ /*fold00*/

namespace ve {
/// a class for OpenGL image and texture operations.
/**
 This class simplifies the loading of OpenGL textures and internally
 manages multiple instances of the same texture. For file input/output
 ve::image is used.

 @author  gf
 @version $Revision: 2.2 $
*/
class glTexture {
public:
    /// loads up an image file into texture memory.
    /** Supported are all ve::image types that can be loaded by ve::image.
     \param name is the filename, it is also used as identifier for checking whether the texture is already loaded.
     \param id is the OpenGL texture id, necessary for binding. 
     \param bytesPerPixel as defined by OpenGL
     \param width of the image
     \param height of the image
     \param isRepeated (optional) defines whether the texture is repeated or clamped.
     \return 0, if all is ok, otherwise an error code.
     */
    static int load(const std::string & name, unsigned int & id, int & bytesPerPixel,
                    int & width, int & height, bool isRepeated=true);
    /// loads up an image file into texture memory, simplified form.
    /** Supported are all ve::image types that can be loaded by ve::image.
     \return the texture id if all is ok, otherwise -1
     */
    static int load(const std::string & name);
    /// loads up a image object into texture memory.
    /** 
     \param name is used as identifier for checking whether the texture is already loaded.
     \param id is the OpenGL texture id, necessary for binding. 
     \param img the actual image
     \param isRepeated (optional) defines whether the texture is repeated or clamped.
     \return 0, if all is ok, otherwise an error code.
     */
    static int load(const std::string &name, unsigned int & id, const ve::image & img, bool isRepeated=true);
    /// deletes a previously defined texture.
    /** The texture is deleted in the veTexture table and glDeleteTextures is called
     for freeing the OpenGL texture memory.
     \param id is the OpenGL texture id for identifying the texture.
     */
    static void del(unsigned int id);
    /// deletes all previously defined textures
    /** calls del() for all textures in the texture table. */
    static void clear();
    /// grabs screen content and saves it as a TGA file named fileName
    static int grabScreen(const std::string & fileName, unsigned int screenW, unsigned int screenH);
    /// adds a texture search path
    static void addSearchPath(const std::string & path);
    /// returns a pointer to texture defined by name or NULL
    static ve::glTexture * get(const std::string & name);
    /// returns the number of bytes per pixel
    int byteDepth() const { return bytesPerPixel; };
    /// enables/disables load time texture compression
    static void enableTextureCompression(bool enable);
protected:
    /// stores filename
    std::string url;
    /// stores OpenGL texture id
    unsigned int id;
    /// stores number of references
    int nRefs;
    /// stores number of bytes of texture
    int bytesPerPixel;
    /// stores texture's width in pixels
    int width;
    /// stores texture's height in pixels
    int height;
    /// stores texture's OpenGL wrap mode.
    /** true means GL_REPEAT, false GL_CLAMP. */
    bool repeat;
    /// stores references for checking which texture is already in memory
    static std::vector<ve::glTexture> table;
    /// stores texture search paths
    static std::vector<std::string> texPath;
    /// compress textures at load time?
    static bool m_bCompressTextures;
};

} // namespace ve

//--- cvs history log : -------------------------------------------- /*FOLD00*/
/*
 * $Log: veImage.h,v $
 * Revision 2.2  2005/01/03 09:42:25  gf
 * XPM interpreter abilities added
 *
 * Revision 2.1  2004/12/01 10:11:37  weyel
 * added load-time texture compression
 *
 * Revision 2.0  2004/11/01 12:40:12  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 */
#endif //_VE_IMG_H
