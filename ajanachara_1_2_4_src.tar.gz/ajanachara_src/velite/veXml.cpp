/** @file veXml.cpp
 \brief veXml - xml ini file loader for the veLib

 started 2002-01-07 by Gerald.Franz\@tuebingen.mpg.de
                    && Jan.Wiener\@tuebingen.mpg.de
 */
//@{

#include "veStd.h"
#include "veXml.h"
#include "veStrUtils.h"
#include "veUtils.h"
#include "veTypes.h"

using namespace std;
using namespace ve;

//--- class ve::xmlIni --------------------------------------------- /*fold00*/

xmlIni::xmlIni(const xmlIni &source)  // copy constructor
     : xml((xml &)source) {
    focus=(xml*)this;
}

xmlIni::xmlIni(const xml &source) : xml(source) {
    focus=(xml*)this;
}

xmlIni::xmlIni(const string & id, int content):xml("int",id,i2s(content)) {
    focus=(xml*)this;
}

xmlIni::xmlIni(const string & id, float content):xml("float",id,f2s(content)) {
    focus=(xml*)this;
}

xmlIni::xmlIni(const string & id, const string & content):xml("string",id,content) {
    focus=(xml*)this;
}

xmlIni::xmlIni(const string & id, vector<float> vContent) : xml() {
    focus=(xml*)this;
    tagStr = "floatArray";
    setAttribute("id",id);
    for(unsigned int i=0;i<vContent.size();i++)
        contentStr += f2s(vContent[i])+" ";
}

xmlIni::xmlIni(const string & id, vector<int> vContent) : xml() {
    focus=(xml*)this;
    tagStr = "intArray";
    setAttribute("id",id);
    for(unsigned int i=0;i<vContent.size();i++)
        contentStr += i2s(vContent[i])+" ";
}

xmlIni::xmlIni(const string &id, vector< std::vector< int > > vvContent) : xml() {
    focus=(xml*)this;
    tagStr = "intArray";
    setAttribute("id",id);
    for(unsigned int i=0;i<vvContent.size();i++) {
        for(unsigned int j=0;j<vvContent[i].size();j++)
            contentStr += i2s(vvContent[i][j])+' ';
        contentStr+='\n';
        xml br("br");  // add line brake marker
        addChild(&br,1);
    }
}

xmlIni::xmlIni(const string & id, vector< std::vector <float> > vvContent) : xml() {
    focus=(xml*)this;
    tagStr = "floatArray";
    setAttribute("id",id);
    for(unsigned int i=0;i<vvContent.size();i++) {
        for(unsigned int j=0;j<vvContent[i].size();j++)
            contentStr += f2s(vvContent[i][j])+' ';
        contentStr+='\n';
        xml br("br");  // add line brake marker
        addChild(&br,1);
    }
}

int xmlIni::load(const string & filename) {
    int ret=xml::load(filename);
    // resolve include statements:
    while(subTag("include")) {
        xml & includeStatement=*subTag("include");
        string includeName=includeStatement.getAttribute("url");
        if(includeName==filename) {
            cerr << "xmlIni WARNING: recursive inclusion detected, resolving aborted.\n";
            ret+=1;
            break;
        }
        xmlIni includeIni;
        ret+=includeIni.load(includeName);
        dropChild(&includeStatement);
        for(unsigned int i=0; i<includeIni.nChildren(); i++)
            addChild(includeIni.child(i),1);
    }
    return ret;
}

xmlIni & xmlIni::operator=(const xmlIni & source) {
    if (this==&source) {
        cerr << "xml WARNING: operator= self reference occured." << endl;
        return *this;
    }
    xml::operator=((xml&)source);
    focus=(xml*)this;
    return *this;
}

int xmlIni::focusOn(const string & tagName, const string & id) {
    focus=focus->xml::subTag(tagName,id);
    if(focus!=NULL) return 0;
    focus=(xml*)this;
    cerr << "ve::xml WARNING: focus " << tagName.c_str() << " id=\"" << id.c_str() << "\" not found!"<< endl;
    return ERR_ERROR;
};

int xmlIni::focusOn(const string & tagName, unsigned int id) {
    return focusOn(tagName,i2s(id));
};

int xmlIni::read(int & pInt, const string & id, int defValue ) const {
    pInt=defValue;
    xml *pSubStat=focus->subTag("int",id);
    if(pSubStat) {
        pInt=s2i(pSubStat->content());
        return 0;
    }
    cerr << "ve::xml WARNING: " << id.c_str() << " not found!"<< endl;
    return ERR_ERROR;
}

int xmlIni::read(unsigned int & uInt, const string & id, unsigned int defValue ) const {
    uInt=defValue;
    xml *pSubStat=focus->subTag("int",id);
    if(pSubStat) {
        int i=s2i(pSubStat->content());
        if(i<0) {
            cerr << "ve::xml WARNING: " << id.c_str() << " assignes negative value to unsigned int!"<< endl;
            i=-i;
        }
        uInt=(unsigned int)i;
        return 0;
    }
    cerr << "ve::xml WARNING: " << id.c_str() << " not found!"<< endl;
    return ERR_ERROR;
}

int xmlIni::read(float & fl, const string & id, float defValue ) const {
    fl=defValue;
    xml *pSubStat=focus->subTag("float",id);
    if(pSubStat) {
        fl=s2f(pSubStat->content());
        return 0;
    }
    cerr << "ve::xml WARNING: " << id.c_str() << " not found!"<< endl;
    return ERR_ERROR;
}

int xmlIni::read(bool & yesno, const string & id, bool defValue ) const {
    yesno=defValue;
    xml *pSubStat=focus->subTag("bool",id);
    if(pSubStat) {
        yesno=s2b(pSubStat->content());
        return 0;
    }
    cerr << "ve::xml WARNING: " << id.c_str() << " not found!"<< endl;
    return ERR_ERROR;
}


int xmlIni::read(string & str, const string & id, string defValue ) const {
    str=defValue;
    xml *pSubStat=focus->subTag("string",id);
    if(pSubStat) {
        str=pSubStat->content();
        return 0;
    }
    cerr << "ve::xml WARNING: " << id.c_str() << " not found!"<< endl;
    return ERR_ERROR;
}


int xmlIni::read(char * & pChar, const string & id, char *defValue ) const {
    string s;
    int status=read(s,id);
    if(status==ERR_OK) {
        pChar = new char[s.length()+1];
        strcpy(pChar,s.c_str());
    }
    else {
        pChar = new char[strlen(defValue)+1];
        strcpy(pChar,defValue);
    }
    return status;
}


int xmlIni::read(vector< vector<int> > & vvInt, const string & id ) const {
    xml *pSubStat=focus->subTag("intArray",id);
    if(pSubStat) {
        vector<string> lines;
        string s=pSubStat->content();
        split(s,lines,"\n");
        for(unsigned int i=0; i<lines.size(); i++) {
            vector<string> words;
            vector<int>  vInt;
            split(lines[i],words);
            for(unsigned int j=0; j<words.size(); j++)
                vInt.push_back(s2i(words[j]));
            if(vInt.size()>0) vvInt.push_back(vInt);
        }
        return 0;
    }
    return ERR_ERROR;
}

int xmlIni::read(vector<int> & vInt, const string & id ) const {
    xml *pSubStat=focus->subTag("intArray",id);
    if(pSubStat) {
        string s(pSubStat->content());
        vector<string> words;
        split(s,words);
        for(unsigned int j=0; j<words.size(); j++)
            vInt.push_back(s2i(words[j]));
        return 0;
    }
    return ERR_ERROR;
}

int xmlIni::read(int * pInt, unsigned int n, const string & id, int defValue ) const {
    vector<int> vInt;
    int result=read(vInt,id);
    unsigned int i;
    for(i=0; (i<n)&&(i<vInt.size()); i++) pInt[i]=vInt[i];
    for( ; i<n; i++) pInt[i]=defValue;
    return result;
}

int xmlIni::read(vector< vector<float> > & vvFloat, const string & id ) const {
    xml *pSubStat=focus->subTag("floatArray",id);
    if(pSubStat) {
        vector<string> lines;
        string s=pSubStat->content();
        split(s,lines,"\n");
        for(unsigned int i=0; i<lines.size(); i++) {
            vector<float>  vFloat;
            if(s2f(lines[i],vFloat)>0) vvFloat.push_back(vFloat);
        }

        return 0;
    }
    return ERR_ERROR;
}

int xmlIni::read(vector<float> & vFloat, const string & id ) const {
    xml *pSubStat=focus->subTag("floatArray",id);
    if(pSubStat) {
        string s(pSubStat->content());
        vector<string> words;
        split(s,words);
        for(unsigned int j=0; j<words.size(); j++)
            vFloat.push_back(s2f(words[j]));
        return 0;
    }
    return ERR_ERROR;
}

int xmlIni::read(float * pFloat, unsigned int n, const string & id, float defValue ) const {
    vector<float> vFloat;
    int result=read(vFloat,id);
    unsigned int i;
    for(i=0; (i<n)&&(i<vFloat.size()); i++) pFloat[i]=vFloat[i];
    for( ; i<n; i++) pFloat[i]=defValue;
    return result;
}

int xmlIni::read(vector<char *> & vStr, const string & id ) const {
    xml *pSubStat=focus->subTag("stringArray",id);
    if(pSubStat){
        vector<string> lines;
        string s=pSubStat->content();
        split(s,lines,"\n");
        if(lines.size()>0)
            for(unsigned int i=0; i<lines.size(); i++)
                if(lines[i].size()>0) {
                    char *pStr = new char[lines[i].size()+1];;
                    strcpy(pStr,lines[i].c_str());
                    vStr.push_back(pStr);
                }
        return 0;
    }
    return ERR_ERROR;
}


int xmlIni::read(vector<string> & vStr, const string & id ) const {
    xml *pSubStat=focus->subTag("stringArray",id);
    if(pSubStat) {
        vector<string> lines;
        string s=pSubStat->content();
        split(s,lines,"\n");
        if(lines.size()>0)
            for(unsigned int i=0; i<lines.size(); i++)
                if(lines[i].size()>0) vStr.push_back(lines[i]);
        return 0;
    }
    return ERR_ERROR;
}


//--- class ve::xml ------------------------------------------------ /*FOLD00*/

//--- constructors, destructors, copying, initialization etc...----- /*fold00*/
xml::xml() { // constructor
    pParent=0;
    delByParent=0;
    tagStr="tag";
    contentStr="";
}

xml::xml(const string & tag, const string & id, const string & content) { // initializing  constructor
    pParent=0;
    delByParent=0;
    tagStr=tag;
    contentStr=content;
    if(id!="") setAttribute("id",id);
}

xml::xml(const xml &source) { // copy constructor
    delByParent=0;
    pParent=0;
    tagStr=source.tagStr;
    contentStr=source.contentStr;

    unsigned int i;
    for (i=0; i<source.attr.size();i++)
        attr.push_back(source.attr[i]);
    for (i=0; i<source.vChildren.size();i++)
        addChild(source.vChildren[i],1);
}

xml::~xml() { // destructor
    for(vector< xml *>::iterator iter=vChildren.begin(); iter<vChildren.end(); iter++) {
        (*iter)->pParent=0; // otherwise somehow recursive...
        if((*iter)->delByParent) delete *iter;
    }
    delByParent=0;  // otherwise somehow recursive...
    if(pParent!=NULL) pParent->dropChild(this);
}

xml & xml::operator=(const xml & source) {
    if (this==&source) return *this; // first test for self reference
    clear();                         // then cleanup memory
    tagStr=source.tagStr;            // finally copy source
    contentStr=source.contentStr;

    unsigned int i;
    for (i=0; i<source.attr.size();i++)
        attr.push_back(source.attr[i]);
    for (i=0; i<source.vChildren.size();i++)
        addChild(source.vChildren[i],1);

    return *this;
}

void xml::clear() {
    tagStr="tag";
    contentStr="";
    attr.clear();
    for(vector< xml *>::iterator iter=vChildren.begin(); iter<vChildren.end(); iter++)
    {
        (*iter)->pParent=0;  // otherwise somehow recursive...
        if((*iter)->delByParent) delete *iter;
    }
    vChildren.clear();
    delByParent=0;  // otherwise somehow recursive...
    if(pParent!=NULL) pParent->dropChild(this);
}

//--- changing content, attributes and links to other statements --- /*fold00*/

void xml::addChild(xml * xmlSt, int asCopy ) { // add child statement
    if(asCopy) {
        xml *pXmlSt=new xml(*xmlSt);
        pXmlSt->pParent=this;
        pXmlSt->delByParent=1;
        vChildren.push_back(pXmlSt);
        return;
    }
    else if(xmlSt->pParent) {
            xmlSt->delByParent=0;
            xmlSt->pParent->dropChild(xmlSt);
        }
    xmlSt->pParent=this;
    xmlSt->delByParent=0;
    vChildren.push_back(xmlSt);
}

void xml::addChild(const xml & xmlSt) { // add child statement
    xml *pXmlSt=new xml(xmlSt);
    pXmlSt->pParent=this;
    pXmlSt->delByParent=1;
    vChildren.push_back(pXmlSt);
}

int xml::dropChild(xml * xmlSt) { // drop child statement
    xmlSt->pParent=0;
    for(vector< xml *>::iterator iter=vChildren.begin(); iter<vChildren.end(); iter++)
        if(*iter==xmlSt)
        {
            vChildren.erase(iter);
            if(xmlSt->delByParent) delete xmlSt;
            return 0;
        }
    return ERR_ERROR;
}

const string & xml::getAttribute(const string & name, const string & defStr) const {
    for(unsigned int i=0; i<attr.size(); i+=2)
        if(attr[i]==name) return attr[i+1];
    return defStr;
}

const string & xml::getAttribute(unsigned int n, const string & defStr) const {
    if(n*2+1>attr.size()) return defStr;
    return attr[n*2+1];
}

string xml::attributeName(unsigned int n) const {
    if(n*2>attr.size()) return "";
    return attr[n*2];
}

void xml::setAttribute(const string & name, const string & value) {
    for(vector<string>::iterator iter=attr.begin(); iter<attr.end(); iter+=2)
        if(*iter==name)
        {
            *(iter+1)=value;
            return;
        }
    attr.push_back(name);
    attr.push_back(value);
}

int xml::dropAttribute(const string & name) {
    for(vector<string>::iterator iter=attr.begin(); iter<attr.end(); iter+=2)
        if(*iter==name)
        {
            attr.erase(iter);                      // erase name
            if(iter!=attr.end()) attr.erase(iter); // erase value
            return 0;
        }
    return ERR_ERROR;
}


xml * xml::child(unsigned int number) {
    if(number>=vChildren.size())
        return NULL;
    return vChildren[number];
}

const xml * xml::child(unsigned int number) const {
    if(number>=vChildren.size())
        return NULL;
    return vChildren[number];
}

xml * xml::child(const string & tagName, const string & id) {
    for(vector< xml *>::iterator iter=vChildren.begin(); iter<vChildren.end(); iter++)
        if(((*iter)->tagStr==tagName)&&(((*iter)->getAttribute("id")==id)||(id=="")))
            return *iter;
    return NULL;
}

xml * xml::subTag(const string & tagName, const string & id) {
    if((tagStr==tagName)&&((getAttribute("id")==id)||(id=="")))
        return this;
    for(unsigned int i=0; i<vChildren.size(); i++) {
        xml *ret=vChildren[i]->subTag(tagName,id);
        if(ret) return ret;
    }
    return NULL;
}

xml * xml::subTag(const string & tagName, unsigned int id) {
    return subTag(tagName,i2s(id));
}

const xml * xml::subTag(const string & tagName, const string & id) const {
    if((tagStr==tagName)&&((getAttribute("id")==id)||(id=="")))
        return this;
    for(unsigned int i=0; i<vChildren.size(); i++) {
        xml *ret=vChildren[i]->subTag(tagName,id);
        if(ret) return ret;
    }
    return NULL;
}

const xml * xml::subTag(const string & tagName, unsigned int id) const {
    return subTag(tagName,i2s(id));
}

xml * xml::subTagAttribute(const std::string & attribute, const std::string & value) {
    if(getAttribute(attribute)==value)  return this;
    for(unsigned int i=0; i<vChildren.size(); i++) {
        xml *ret=vChildren[i]->subTagAttribute(attribute,value);
        if(ret) return ret;
    }
    return NULL;
}


//--- file input output -------------------------------------------- /*fold00*/

int xml::load(const string & filename) {
    FILE *fp=0;
    fp=fileIo::open(filename,"r");
    if (!fp) {
        cerr << "xml error: " << filename << " file error or file not found!"<< endl;
        return ERR_IO;
    }
    unsigned int size=fileIo::fileSize(fp);
    char * buffer = new char[size+1];
    fread(buffer,1,size,fp);
    buffer[size]=0;
    fileIo::close(fp);
    interpret(buffer);
    delete [] buffer;
    return 0;
}

int xml::save(const string filename) const {
    // now the data gets actually written to disk:
    ofstream file(filename.c_str(), std::ios::out );
    if (!file.good()) {
        cerr << "xml error: " << filename.c_str() << " write file error!"<< endl;
        return ERR_IO;
    }
    file << *this << endl;
    file.close();
    return 0;
}

void xml::interpret(const string & xmlString) {
    // strip comments from xml string and preformat:
    const string commentStart="<!--";
    const string commentEnd="-->";
    unsigned int commentStartPos=static_cast<unsigned int>(xmlString.find(commentStart));
    unsigned int commentEndPos=0;
    vector<string> rawToken;
    string nakedS=xmlString.substr(commentEndPos,commentStartPos-commentEndPos);
    nakedS=replaceAll(nakedS,"/>"," / ");
    nakedS=replaceAll(nakedS,"<"," <");
    nakedS=replaceAll(nakedS,">"," > ");
    split(nakedS,rawToken);
    while(commentStartPos<xmlString.size()) {
        commentEndPos=static_cast<unsigned int>(xmlString.find(commentEnd,commentStartPos));
        commentStartPos=static_cast<unsigned int>(xmlString.find(commentStart,commentEndPos));
        nakedS=xmlString.substr(commentEndPos+commentEnd.size(),
                        commentStartPos-commentEndPos-commentEnd.size());
        // preformat output: // BUG: they do not take care of quotation marks, that's bad!
        nakedS=replaceAll(nakedS,"/>"," / ");
        nakedS=replaceAll(nakedS,"<"," <");
        nakedS=replaceAll(nakedS,">"," > ");
        split(nakedS,rawToken);
    }
    vector<string> token;
    // join again tokens within quotation marks:
    for(unsigned int i=0; i<rawToken.size(); i++)
        if((rawToken[i].find('"')<rawToken[i].size())
           && (rawToken[i].find('"')==rawToken[i].rfind('"'))) { // only 1 quotation mark
            string s(rawToken[i]);
            do {
                i++;
                s+=" "+rawToken[i];
            } while((i<rawToken.size())&&(rawToken[i].find('"')>=rawToken[i].size()));
            token.push_back(s);
        }
        else token.push_back(rawToken[i]);

    parse(token);
}

void xml::parse(const vector<string> & token) {
    clear();
    unsigned int i=0;
    xml *currSt = NULL;
    while(i<token.size()) {
        if(currSt) {
            if(token[i]==("</"+currSt->tag())) { // previous tag is over
                i++; // ignore following >
                currSt->content(decode(trim(currSt->content())));
                currSt=currSt->parent();
            }
            else if(token[i][0]=='<') currSt->content(trim(currSt->content())+'\n');
            else currSt->content(currSt->content()+ token[i] +" ");
        }

        //cout << "mainLoop: "; P(token[i]);
        if(token[i].size()>1) if((token[i][0]=='<')&&(token[i][1]!='?')
                                 &&(token[i][1]!='!')&&(token[i][1]!='/')) { // new tag found, no start comment
            //cout << "new Tag..." << flush;
            xml * newSt = new xml;
            //cout << "memory allocated." << endl;
            newSt->tag(token[i].substr(1));
            if(currSt) {
                //cout << "subStatement from " << currSt->tag() << endl;
                currSt->addChild(newSt,1);
                delete newSt;
                newSt=currSt->child(currSt->nChildren()-1);
            }
            else {
                //cout << "no current statement." << endl;
                *this=*newSt;
                delete newSt;
                newSt=this;
            }

            currSt=newSt;

            while((token[i]!=">")&&(token[i]!="/")&&(++i<token.size())) { // parse tag header
                //cout << currSt->tag() <<" header: " << token[i] << endl;
                unsigned int sepPos=static_cast<unsigned int>(token[i].find("=")); // regular attribute
                if(sepPos<token[i].size()) {
                    string aName(token[i],0,sepPos);
                    string aValue(token[i],
                                  token[i].find_first_of("\"")+1,
                                  token[i].find_last_of("\"")-token[i].find_first_of("\"")-1);
                    if(aName == "url" || aName == "basePath")
                      currSt->setAttribute(aName, decode(aValue));
                    else
                      currSt->setAttribute(aName, decode(aValue));
                }
            }
            
            if(token[i]=="/") // this tag has no content, only attributes
                currSt=currSt->parent();
            else { // parse tag body
                string tmpStr("");
                while((token[i+1][0]!='<')&&(i<token.size()-1)) { // read tag body
                    i++;
                    tmpStr.append(token[i]+" ");
                }
                tmpStr=trim(tmpStr);
                if(tmpStr!="") {
                    currSt->content(currSt->content()+tmpStr);
                    //cout << currSt->tag() << " body: " << currSt->content() << endl;
                }
            }
        }
        i++;
    }
}

string xml::str(unsigned int nTabs) const {
    string s("");
    unsigned int i;
    string tabStr;
    for(i=0; i<nTabs; i++) tabStr+='\t';
    s+=tabStr+"<"+tagStr;
    if(attr.size()>0) for(i=0; i< attr.size(); i+=2) {
        s+= " ";
        s+= attr[i];
        s+= "=\"";
        s+= encode(attr[i+1]);
        s+= "\"";
    }
    if((contentStr.size()==0)&&(vChildren.size()==0)) s+="/>\n";
    else {
        s+=">";
        if((vChildren.size()>0)&&(contentStr.size()>0))
        {
            s+='\n';
            for(unsigned int j=0; j<nTabs+1; j++) s+='\t';
            unsigned int currChild=0;
            for(i=0; i<contentStr.size(); i++)
                if(contentStr[i]=='\n') {
                    if(currChild<vChildren.size()) s+=('\t'+trim(vChildren[currChild]->str(nTabs+1))+'\n');
                    else s+='\n';
                    currChild++;
                    if(i<contentStr.size()) for(unsigned int j=0; j<nTabs+1; j++) s+='\t';
                }
                else s+=encode(contentStr.substr(i,1));
            for( ; currChild < vChildren.size(); currChild++) s+=vChildren[currChild]->str(nTabs+1);
            s+='\n'+tabStr;
            s+=("</"+tagStr+">\n");
        }
        else {
            string contentCopy=replaceAll(contentStr,"\n","\n\t"+tabStr);
            s+="\n\t"+tabStr+contentCopy;
            if(vChildren.size()>0)  s+='\n';
            if(vChildren.size()==0) s+='\n'+tabStr+"</"+tagStr+">\n";
            else {
                for(i=0; i<vChildren.size();i++)
                    s+=vChildren[i]->str(nTabs+1);
                s+=tabStr+"</"+tagStr+">\n";
            }
        }
    }
    return s;
}

// encodes special characters in xml
string xml::encode(string source) {
    string s(source);
    s = replaceAll(s, "&", "&amp;");
    s = replaceAll(s, "<", "&lt;");
    s = replaceAll(s, ">", "&gt;");
    s = replaceAll(s, "\"","&quot;");
    s = replaceAll(s, "'", "&apos;");
    s = replaceAll(s, "�","&#223;");
    s = replaceAll(s, "�","&#228;");
    s = replaceAll(s, "�","&#246;");
    s = replaceAll(s, "�","&#252;");
    s = replaceAll(s, "�","&#196;");
    s = replaceAll(s, "�","&#214;");
    s = replaceAll(s, "�","&#220;");
    return s;
}

// decodes xml encoded special characters to ascii
string xml::decode(string source) {
    string s(source);
    s = replaceAll(s,"&lt;",   "<");
    s = replaceAll(s,"&gt;",   ">");
    s = replaceAll(s,"&quot;", "\"");
    s = replaceAll(s,"&apos;", "'");
    s = replaceAll(s,"&amp;" , "&");
    s = replaceAll(s,"&#160;", " ");
    s = replaceAll(s,"&#223;", "�");
    s = replaceAll(s,"&#228;", "�");
    s = replaceAll(s,"&#246;", "�");
    s = replaceAll(s,"&#252;", "�");
    s = replaceAll(s,"&#196;", "�");
    s = replaceAll(s,"&#214;", "�");
    s = replaceAll(s,"&#220;", "�");
    return s;
}

// just a good friend of xml, performs output in a C++ standard stream.
std::ostream & operator<<(std::ostream & os, const xml & xs) {
    return os << "<?xml version=\"1.0\"?>\n<!-- generated by ve::xml -->\n\n" << xs.str();
}

//@}

//--- history : ---------------------------------------------------- /*FOLD00*/
/*
 * $Log: veXml.cpp,v $
 * Revision 2.0  2004/11/01 12:40:13  gf
 * due to the lucky release of version 1.0 cvs tag is switched to 2.x
 *
 * Revision 1.109  2004/10/25 11:55:21  gf
 * error codes cleaned up
 *
 * Revision 1.108  2004/10/04 09:38:11  weyel
 * -resovled ALL msvc compiler warnings
 * -removed #ident macros
 *
 * Revision 1.107  2004/08/25 12:50:51  gf
 * id attribute parsing removed for <overlay/>, <resources/>, <scene/>
 *
 * Revision 1.106  2004/08/24 16:26:41  gf
 * - deviceContainer access methods (device,size) added
 * - xmlIni include file parsing bug fixed
 *
 * Revision 1.105  2004/08/22 20:06:32  gf
 * very crappy include implementation improved. Please take mare care on
 * potential security/bug issues next time!
 *
 * Revision 1.104  2004/08/20 08:48:10  gf
 * - VECERR replaced by std::cerr
 * - dynamic overlay text implemented, affecting veDeviceSDL, veGlUtils, veTypes, veDataContainer
 *
 * Revision 1.97  2004/03/22 19:48:02  gf
 * adaptations to unification of veUtils and veIo
 *
 * Revision 1.96  2004/03/15 18:49:24  gf
 * read (vector<vector<float> >) a little bit optimized
 *
 * Revision 1.95  2004/02/24 13:33:33  gf
 * - ve::vec (veMath.h) renamed to ve::vec3f
 * - VEEC_XYZ (veTypes.h) error codes renamed to ve::ERR_XYZ
 *
 * Revision 1.94  2004/02/03 10:57:07  gf
 * better indentation for xml output
 *
 * Revision 1.93  2004/01/23 11:20:24  gf
 * - inifile xml syntax unified
 * - veDeviceGraphics3dPf temporarily moved to modules
 *
 * Revision 1.92  2004/01/20 16:40:52  gf
 * ve::xml renamed to ve::xmlIni, ve::xmlStatement renamed to ve::xml
 *
 * Revision 1.91  2004/01/19 10:21:57  gf
 * - namespace ve now consequently used in more classes
 * - veImg.h/.cpp renamed to veImage.h/.cpp
 *
 * Revision 1.90  2004/01/11 21:39:20  gf
 * - talk.h renamed to veDebug.h
 * - veDevice moved to namespace ve and renamed to ve::device
 *
 * Revision 1.89  2003/12/09 09:22:23  gf
 * small C99 incompatibility solved
 *
 * Revision 1.88  2003/11/17 15:12:45  gf
 * adaptions to novel veIo
 *
 * Revision 1.87  2003/07/25 11:08:54  gf
 * bug "comment before the first tag is needed" removed
 *
 * Revision 1.86  2003/06/03 07:33:50  gf
 * documented parsing bug xmlStatement::interpret function
 */
